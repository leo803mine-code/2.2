package dev.flr.visuals;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.gui.ModListScreen;

/**
 * Главное меню FLR 2.2: плавный анимированный фон, крупный заголовок выбранного пункта и «жидкий» док внизу
 * (подсветка растягивается при переходе), быстрый выбор серверов и карточка медиаплеера.
 */
public class FlrTitleScreen extends Screen {
    private record Item(String label, String desc, int icon, String btn, Supplier<Screen> target) {}

    private final List<Item> items = new ArrayList<>();
    private int sel;
    private long last;
    private float headX = -1, tailX = -1, openAnim, swap = 1f, textAnim = 1f;
    private float[] hov = new float[0];
    private ServerList servers;
    private int shownServers;
    private int dockX, dockY, tile = 46, tileGap = 8;
    private boolean mediaDrag;

    public FlrTitleScreen() {
        super(Component.literal("FLR Visuals"));
    }

    @Override
    protected void init() {
        Minecraft mc = Minecraft.getInstance();
        items.clear();
        items.add(new Item("Singleplayer", "Your worlds. A quiet corner of an endless world.", 0, "Play", () -> new SelectWorldScreen(this)));
        items.add(new Item("Multiplayer", "Servers, friends and quick join", 1, "Join", () -> new ServerScreen(this)));
        items.add(new Item("Mods", "Installed mods", 2, "Browse", () -> new ModListScreen(this)));
        items.add(new Item("Media", "Play your own music right here", -2, "Open", () -> new CosmeticsScreen(7)));
        items.add(new Item("Options", "Game settings", 3, "Open", () -> new OptionsScreen(this, mc.options)));
        items.add(new Item("FLR Visuals", "Cosmetics, pets, sky and weather", -1, "Open", CosmeticsScreen::new));
        items.add(new Item("Quit game", "See you soon", 4, "Quit", () -> null));
        if (hov.length != items.size()) hov = new float[items.size()];
        sel = Math.min(sel, items.size() - 1);
        servers = new ServerList(mc);
        servers.load();
        shownServers = Math.min(3, servers.size());
        for (int i = 0; i < shownServers; i++) ServerPing.ping(servers.get(i).ip, false);
        MediaPlayer.init();
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
    }

    /** Для геймпада и клавиатуры. */
    void move(int d) {
        select(Math.floorMod(sel + d, items.size()));
    }

    private void select(int i) {
        if (i == sel) return;
        sel = i;
        textAnim = 0f;
    }

    void activate() {
        Item it = items.get(sel);
        Minecraft mc = Minecraft.getInstance();
        if (it.icon() == 4) mc.stop();
        else mc.setScreen(it.target().get());
    }

    private float dockW() {
        return items.size() * tile + (items.size() - 1) * tileGap + 24;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openAnim += (1f - openAnim) * Gfx.k(dt, 6f);
        textAnim = Math.min(1f, textAnim + dt * 4.5f);
        float e = Gfx.ease(openAnim), t = Backdrop.time();
        int acc = Config.color() | 0xFF000000;
        Backdrop.draw(g, width, height);
        Gfx.use(g);

        // верх: логотип слева, часы справа
        Ui.logo(g, 18f, 14f, 30f, e);
        Gfx.use(g);
        Gfx.text("FLR Visuals", 56, 14, 15f, Gfx.rgba(0xFFFFFF, e), true);
        Gfx.text("2.2", 57, 32, Ui.BODY - 1f, Gfx.rgba(0xFFFFFF, 0.5f * e), false);
        String clock = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        Gfx.textR(clock, width - 18, 24, 17f, Gfx.rgba(0xFFFFFF, e), true);
        String nick = Minecraft.getInstance().getUser().getName();
        float nw = Gfx.textW(nick, Ui.BODY, false) + 38;
        boolean ah = Ui.in(mx, my, width - 18 - nw, 40, nw, 20);
        Gfx.rr(width - 18 - nw, 40, nw, 20, 10, Gfx.rgba(0xFFFFFF, (ah ? 0.2f : 0.1f) * e));
        Gfx.icon(Gfx.USER, width - 18 - nw + 13, 50, 10, Gfx.rgba(0xFFFFFF, 0.85f * e));
        Gfx.textMid(nick, width - 18 - nw + 24, 50, Ui.BODY, Gfx.rgba(0xFFFFFF, 0.9f * e), false);

        // крупный заголовок выбранного пункта
        Item it = items.get(sel);
        float ta = Gfx.ease(textAnim), lx = Math.max(28, width * 0.08f), ly = height * 0.26f;
        float big = Math.min(40f, Math.max(24f, width / 18f));
        Gfx.orb(lx + 60, ly + 24, 130, Gfx.a(acc, 0.10f * e));
        String label = Tr.tr(it.label());
        Gfx.text(label, lx + (1f - ta) * -14, ly, big, Gfx.rgba(0xFFFFFF, ta * e), true);
        Gfx.text(Gfx.fit(Tr.tr(it.desc()), width * 0.5f, 11f, false), lx + 2 + (1f - ta) * -10, ly + big + 6, 11f, Gfx.rgba(0xFFFFFF, 0.62f * ta * e), false);
        int bw = 120, by = (int) (ly + big + 34);
        boolean bh = Ui.in(mx, my, lx, by, bw, 28);
        Ui.pill(g, (int) lx, by, bw, 28, Tr.tr(it.btn()), bh, true, acc & 0xFFFFFF);
        Gfx.use(g);

        // быстрые серверы
        if (width >= 640 && shownServers > 0) {
            float sy = height - 160;
            Gfx.text(Tr.tr("Quick join"), lx, sy - 16, Ui.BODY - 0.4f, Gfx.rgba(0xFFFFFF, 0.5f * e), true);
            float sx = lx;
            for (int i = 0; i < shownServers; i++) {
                ServerData d = servers.get(i);
                ServerPing.Info in = ServerPing.get(d.ip);
                float cw = 150, ch = 40;
                boolean hv = Ui.in(mx, my, sx, sy, cw, ch);
                Gfx.glow(sx, sy + 2, cw, ch, 12, 8, Gfx.rgba(0x000000, 0.25f * e));
                Gfx.rr4(sx, sy, cw, ch, 12, Gfx.rgba(0xFFFFFF, (hv ? 0.2f : 0.1f) * e), Gfx.rgba(0xFFFFFF, (hv ? 0.1f : 0.05f) * e), Gfx.rgba(0xFFFFFF, 0.06f * e), Gfx.rgba(0xFFFFFF, 0.03f * e));
                Gfx.ring(sx, sy, cw, ch, 12, 1f, hv ? Gfx.a(acc, 0.8f * e) : Gfx.rgba(0xFFFFFF, 0.14f * e));
                float hue = (Math.abs(d.name.hashCode()) % 360) / 360f;
                Gfx.rr4(sx + 7, sy + 7, 26, 26, 8, Gfx.hsb(hue, 0.55f, 0.95f), Gfx.hsb(hue + 0.1f, 0.6f, 0.7f), Gfx.hsb(hue, 0.7f, 0.6f), Gfx.hsb(hue + 0.1f, 0.6f, 0.45f));
                Gfx.textC(d.name.isEmpty() ? "?" : d.name.substring(0, 1).toUpperCase(), sx + 20, sy + 20, 12f, 0xFFFFFFFF, true);
                Gfx.text(Gfx.fit(d.name, cw - 46, Ui.BODY, true), sx + 40, sy + 8, Ui.BODY, Gfx.rgba(0xFFFFFF, e), true);
                boolean ok = in != null && in.state == 1;
                Gfx.circle(sx + 43, sy + 28, 2.4f, ok ? 0xFF4CE08A : in == null || in.state == 0 ? 0xFFFFC94D : 0xFFFF6B6B);
                String st = ok ? (in.online >= 0 ? in.online + "/" + in.max : "online") + (in.ms >= 0 ? "  " + in.ms + " ms" : "") : in == null || in.state == 0 ? "..." : "offline";
                Gfx.textMid(st, sx + 50, sy + 28, Ui.BODY - 1.2f, Gfx.rgba(0xFFFFFF, 0.65f * e), false);
                sx += cw + 10;
            }
        }

        // медиа-карточка
        if (width >= 560) {
            float mw = Math.min(230, width * 0.3f), mh = 62;
            MediaUi.compact(g, width - mw - 18, height - mh - 18, mw, mh, mx, my, dt);
        }
        Gfx.use(g);

        dock(g, mx, my, dt, e, acc);
        Gfx.textC(Tr.tr("Arrows to choose  ·  Enter to open"), width / 2f, height - 10, Ui.BODY - 1.2f, Gfx.rgba(0xFFFFFF, 0.28f * e), false);
        Gfx.end();
    }

    /** «Жидкий» док: подсветка тянется за выбором, как капля. */
    private void dock(GuiGraphics g, int mx, int my, float dt, float e, int acc) {
        int n = items.size();
        float dw = dockW(), dh = tile + 20;
        dockX = (int) ((width - dw) / 2f);
        dockY = (int) (height - dh - 34 + (1f - e) * 24);
        Gfx.glow(dockX, dockY + 6, dw, dh, dh / 2f, 26, Gfx.rgba(0x000000, 0.45f * e));
        Gfx.rr4(dockX, dockY, dw, dh, dh / 2f, Gfx.rgba(0xFFFFFF, 0.16f * e), Gfx.rgba(0xFFFFFF, 0.09f * e), Gfx.rgba(0xFFFFFF, 0.07f * e), Gfx.rgba(0xFFFFFF, 0.04f * e));
        Gfx.ring(dockX, dockY, dw, dh, dh / 2f, 1f, Gfx.rgba(0xFFFFFF, 0.2f * e));
        float ty = dockY + 10;
        float tgt = dockX + 12 + sel * (tile + tileGap);
        if (headX < 0) { headX = tgt; tailX = tgt; }
        headX += (tgt - headX) * Gfx.k(dt, 22f);
        tailX += (tgt - tailX) * Gfx.k(dt, 8f);
        float left = Math.min(headX, tailX), right = Math.max(headX, tailX) + tile;
        float stretch = Gfx.clamp01((right - left - tile) / 90f), inset = stretch * 5f;
        Gfx.glow(left, ty + inset, right - left, tile - inset * 2, 16, 16, Gfx.a(acc, 0.35f * e));
        Gfx.rr4(left, ty + inset, right - left, tile - inset * 2, 17, Gfx.a(Gfx.mix(acc, 0xFFFFFFFF, 0.3f), 0.7f * e), Gfx.a(acc, 0.5f * e), Gfx.a(acc, 0.32f * e), Gfx.a(Gfx.shift(acc, 0.06f, 0f, -0.1f), 0.4f * e));
        Gfx.rr(left + 5, ty + inset + 2, right - left - 10, 10, 5, Gfx.rgba(0xFFFFFF, 0.22f * e));
        Gfx.ring(left, ty + inset, right - left, tile - inset * 2, 17, 1f, Gfx.rgba(0xFFFFFF, 0.42f * e));
        for (int i = 0; i < n; i++) {
            float x = dockX + 12 + i * (tile + tileGap);
            boolean h = Ui.in(mx, my, x, ty, tile, tile);
            hov[i] += ((h ? 1f : 0f) - hov[i]) * Gfx.k(dt, 16f);
            float lift = -3f * hov[i] - (i == sel ? 2f : 0f);
            float cx = x + tile / 2f, cy = ty + tile / 2f + lift;
            float sc = 1f + 0.1f * hov[i] + (i == sel ? 0.08f : 0f);
            float a = (i == sel ? 1f : 0.7f + 0.2f * hov[i]) * e;
            Item it = items.get(i);
            float is = 24 * sc;
            if (it.icon() >= 0) Ui.icon(g, it.icon(), cx - is / 2f, cy - is / 2f, is, 0xFFFFFF, a);
            else if (it.icon() == -1) Ui.logo(g, cx - is / 2f - 2, cy - is / 2f - 2, is + 4, a);
            Gfx.use(g);
            if (it.icon() == -2) Gfx.icon(Gfx.NOTE, cx, cy, is, Gfx.rgba(0xFFFFFF, a));
        }
        float lw = 0;
        Item cur = items.get(sel);
        String name = Tr.tr(cur.label());
        lw = Gfx.textW(name, Ui.BODY - 0.6f, true);
        Gfx.textC(name, dockX + dw / 2f, dockY - 11, Ui.BODY - 0.6f, Gfx.rgba(0xFFFFFF, 0.8f * e), true);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        Item it = items.get(sel);
        float lx = Math.max(28, width * 0.08f), ly = height * 0.26f, big = Math.min(40f, Math.max(24f, width / 18f));
        if (b == 0) {
            for (int i = 0; i < items.size(); i++) {
                float x = dockX + 12 + i * (tile + tileGap);
                if (Ui.in(mx, my, x, dockY + 10, tile, tile)) {
                    if (i == sel) activate();
                    else select(i);
                    return true;
                }
            }
            if (Ui.in(mx, my, lx, ly + big + 34, 120, 28)) { activate(); return true; }
            if (width >= 640) {
                float sy = height - 160, sx = lx;
                for (int i = 0; i < shownServers; i++) {
                    if (Ui.in(mx, my, sx, sy, 150, 40)) {
                        ServerSelect.join(this, servers.get(i));
                        return true;
                    }
                    sx += 160;
                }
            }
            if (width >= 560 && MediaUi.mouseDown(mx, my, b)) { mediaDrag = true; return true; }
        }
        return super.mouseClicked(mx, my, b);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        if (mediaDrag) { MediaUi.mouseDrag(mx); return true; }
        return super.mouseDragged(mx, my, b, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int b) {
        mediaDrag = false;
        MediaUi.mouseUp();
        return super.mouseReleased(mx, my, b);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        move(sy > 0 ? -1 : 1);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 263 || key == 265) { move(-1); return true; }
        if (key == 262 || key == 264) { move(1); return true; }
        if (key == 257 || key == 335 || key == 32) { activate(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
