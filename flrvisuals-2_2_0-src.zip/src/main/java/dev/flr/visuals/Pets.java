package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;

/** Процедурные модели из кубиков (координаты в пикселях 1/16, y вверх, перед = -z): шапки и питомцы с анимацией. */
final class Pets {
    private static final float U = 1f / 16f;
    static PoseStack ps;
    static VertexConsumer vc;
    static int light;
    private static final int BLK = 0xFF16161C, VIOLET = 0xFF7B3FD6, LILAC = 0xFFA879FF;

    private static float lookYaw, lookPitch;
    static boolean lod;

    private Pets() {}

    private static float blink(float t) {
        return (t + 17f) % 95f < 4f ? 0.15f : 1f;
    }

    /** Поворот головы: смотрит туда же, куда игрок, плюс сам иногда оглядывается. */
    private static float headYaw(float t) {
        float scan = Mth.sin(t * 0.031f) * 18f * (0.5f + 0.5f * Mth.sin(t * 0.0113f));
        return Mth.clamp(-lookYaw, -45f, 45f) * 0.8f + scan;
    }

    private static float headPitch(float t) {
        return Mth.clamp(-lookPitch, -25f, 25f) * 0.6f + Mth.sin(t * 0.06f) * 2f;
    }

    private static float earFlick(float t) {
        return Mth.sin(t * 0.017f) > 0.85f ? Mth.sin(t * 0.9f) * 10f : 0f;
    }

    /** Сердечко над головой раз в ~18 секунд. */
    private static void heart(float t, float y) {
        float q = (t % 360f) / 360f / 0.22f;
        if (q > 1f) return;
        float s = Mth.sin(q * Mth.PI);
        if (s < 0.05f) return;
        ps.pushPose();
        ps.translate(0, (y + q * 8f) * U, 0);
        ps.scale(s, s, s);
        int c = 0xFFFF4F7B;
        box(-2, 3, -0.5f, -0.5f, 4, 0.5f, c); box(0.5f, 3, -0.5f, 2, 4, 0.5f, c);
        box(-2.5f, 2, -0.5f, 2.5f, 3, 0.5f, c);
        box(-1.5f, 1, -0.5f, 1.5f, 2, 0.5f, c);
        box(-0.5f, 0, -0.5f, 0.5f, 1, 0.5f, c);
        ps.popPose();
    }

    static void begin(PoseStack p, VertexConsumer v, int l) {
        ps = p; vc = v; light = l;
    }

    static int shade(int c, float k) {
        return (c & 0xFF000000) | (int) ((c >> 16 & 255) * k) << 16 | (int) ((c >> 8 & 255) * k) << 8 | (int) ((c & 255) * k);
    }

    private static void face(PoseStack.Pose pp, int c, float k, float nx, float ny, float nz, float[] v) {
        int col = shade(c, k);
        for (int i = 0; i < 4; i++) {
            vc.addVertex(pp.pose(), v[i * 3], v[i * 3 + 1], v[i * 3 + 2]).setColor(col).setUv(0f, 0f)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pp, nx, ny, nz);
        }
    }

    static void box(float x0, float y0, float z0, float x1, float y1, float z1, int c) {
        x0 *= U; y0 *= U; z0 *= U; x1 *= U; y1 *= U; z1 *= U;
        PoseStack.Pose p = ps.last();
        face(p, c, 1.0f, 0, 1, 0, new float[]{x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1});
        face(p, c, 0.5f, 0, -1, 0, new float[]{x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1});
        face(p, c, 0.8f, 0, 0, -1, new float[]{x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0});
        face(p, c, 0.8f, 0, 0, 1, new float[]{x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1});
        face(p, c, 0.65f, -1, 0, 0, new float[]{x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0});
        face(p, c, 0.65f, 1, 0, 0, new float[]{x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0});
    }

    static void part(float px, float py, float pz, float rx, float ry, float rz, Runnable r) {
        ps.pushPose();
        ps.translate(px * U, py * U, pz * U);
        if (ry != 0) ps.mulPose(Axis.YP.rotationDegrees(ry));
        if (rx != 0) ps.mulPose(Axis.XP.rotationDegrees(rx));
        if (rz != 0) ps.mulPose(Axis.ZP.rotationDegrees(rz));
        r.run();
        ps.popPose();
    }

    // ---------------- шапки (в пространстве головы, верх головы y = 8) ----------------
    static void hat(int type, float t) {
        ps.pushPose();
        ps.scale(1, -1, 1);
        if (type == 1) {
            final int RED = 0xFFD92B3A, WHITE = 0xFFF6F6FA;
            box(-4.8f, 8, -4.8f, 4.8f, 10.4f, 4.8f, WHITE);
            float[] w = {4.2f, 3.5f, 2.7f, 1.9f}, dz = {0, 0.8f, 2.2f, 4.0f};
            for (int i = 0; i < 4; i++) {
                float yb = 10.4f + 2.5f * i;
                box(-w[i], yb, -w[i] + dz[i], w[i], yb + 2.5f, w[i] + dz[i], RED);
            }
            float sw = Mth.sin(t * 0.1f) * 1.2f;
            box(-1.6f + sw, 17.7f, 4.4f, 1.6f + sw, 20.9f, 7.6f, WHITE);
        } else if (type == 2) {
            box(-4.5f, 8, -4.5f, 4.5f, 11.2f, 4.5f, BLK);
            box(-4.55f, 10.4f, -4.55f, 4.55f, 10.8f, 4.55f, VIOLET);
            box(-1.4f, 9, -4.6f, 1.4f, 10.2f, -4.5f, VIOLET);
            box(-4.2f, 8, -8.8f, 4.2f, 8.9f, -4.5f, BLK);
            box(-3.6f, 8.3f, -9.4f, 3.6f, 8.9f, -8.8f, BLK);
            box(-0.7f, 11.2f, -0.7f, 0.7f, 11.9f, 0.7f, VIOLET);
            box(-1.6f, 8, 4.5f, 1.6f, 9.4f, 5.1f, BLK);
        } else if (type == 3) {
            box(-4.7f, 8, -4.7f, 4.7f, 9.9f, 4.7f, 0xFF2A2A33);
            box(-4.55f, 9.9f, -4.55f, 4.55f, 12.4f, 4.55f, BLK);
            box(-4.6f, 10.5f, -4.6f, 4.6f, 10.9f, 4.6f, VIOLET);
            box(-3.4f, 12.4f, -3.4f, 3.4f, 13.4f, 3.4f, BLK);
            box(-1.2f, 13.4f, -1.2f, 1.2f, 14.4f, 1.2f, BLK);
        } else {
            final int G = 0xFF8F94A6, PK = 0xFFD79A8C;
            box(-4.4f, 8, -0.7f, 4.4f, 8.8f, 0.7f, BLK);
            box(-4.4f, 4.5f, -0.7f, -3.7f, 8, 0.7f, BLK);
            box(3.7f, 4.5f, -0.7f, 4.4f, 8, 0.7f, BLK);
            final float sw = Mth.sin(t * 0.07f) * 4f;
            part(-2.4f, 8.4f, 0, 0, 0, 12f + sw, () -> {
                box(-1.2f, 0, -0.8f, 1.2f, 7, 0.8f, G);
                box(-0.7f, 0.5f, -0.85f, 0.7f, 6.4f, -0.8f, PK);
                part(0, 7, 0, 0, 0, 55f, () -> { box(-1.2f, 0, -0.8f, 1.2f, 4.2f, 0.8f, G); box(-0.7f, 0, -0.85f, 0.7f, 3.4f, -0.8f, PK); });
            });
            part(2.4f, 8.4f, 0, 0, 0, -12f - sw, () -> {
                box(-1.2f, 0, -0.8f, 1.2f, 7, 0.8f, G);
                box(-0.7f, 0.5f, -0.85f, 0.7f, 6.4f, -0.8f, PK);
                part(0, 7, 0, 0, 0, -55f, () -> { box(-1.2f, 0, -0.8f, 1.2f, 4.2f, 0.8f, G); box(-0.7f, 0, -0.85f, 0.7f, 3.4f, -0.8f, PK); });
            });
        }
        ps.popPose();
    }

    /** Текстурированный прямоугольник (логотип) в системе координат тела; y вниз, вид сзади. */
    static void texQuad(PoseStack p, VertexConsumer v, int l, float x0, float y0, float x1, float y1, float z) {
        PoseStack.Pose pp = p.last();
        float a = x0 * U, b = y0 * U, c = x1 * U, d = y1 * U, zz = z * U;
        v.addVertex(pp.pose(), c, b, zz).setColor(255, 255, 255, 255).setUv(0f, 0f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(l).setNormal(pp, 0, 0, 1);
        v.addVertex(pp.pose(), a, b, zz).setColor(255, 255, 255, 255).setUv(1f, 0f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(l).setNormal(pp, 0, 0, 1);
        v.addVertex(pp.pose(), a, d, zz).setColor(255, 255, 255, 255).setUv(1f, 1f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(l).setNormal(pp, 0, 0, 1);
        v.addVertex(pp.pose(), c, d, zz).setColor(255, 255, 255, 255).setUv(0f, 1f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(l).setNormal(pp, 0, 0, 1);
    }

    // ---------------- предметы на спине ----------------
    static void back(int type, float t) {
        ps.pushPose();
        ps.scale(1, -1, 1);
        final int GOLD = 0xFFE3B23C, BROWN = 0xFF6B3F1D, BLADE = 0xFFDCE6F2, EDGE = 0xFFF8FBFF;
        final int RED = 0xFFD92B3A, WHT = 0xFFF6F6FA, GREEN = 0xFF2E9B55;
        if (type == 1) {
            part(0, -5.5f, 3.9f, 0, 0, 40f, () -> {
                box(-1.0f, -11f, -0.5f, 1.0f, -9.6f, 0.7f, GOLD);
                box(-0.7f, -9.6f, -0.4f, 0.7f, -6.6f, 0.6f, BROWN);
                box(-3f, -6.6f, -0.8f, 3f, -5.4f, 0.9f, GOLD);
                box(-1.4f, -5.4f, -0.5f, 1.4f, 10f, 0.6f, BLADE);
                box(-0.9f, 10f, -0.45f, 0.9f, 12f, 0.55f, BLADE);
                box(-0.4f, 12f, -0.4f, 0.4f, 13f, 0.5f, BLADE);
                box(-0.25f, -5.4f, 0.6f, 0.25f, 12.2f, 0.75f, EDGE);
            });
        } else if (type == 2) {
            part(0, -5.5f, 3.9f, 0, 0, 35f, () -> {
                for (int i = 0; i < 8; i++) box(-1.1f, -10f + i * 2.4f, -0.9f, 1.1f, -10f + (i + 1) * 2.4f, 0.9f, i % 2 == 0 ? RED : WHT);
                box(-1.1f, 9.2f, -0.9f, 1.1f, 11.6f, 0.9f, RED);
                box(-1.1f, 11.6f, -0.9f, 3.9f, 13.8f, 0.9f, WHT);
                box(2.0f, 9.2f, -0.9f, 4.2f, 11.6f, 0.9f, RED);
                box(-1.7f, -2.4f, -1.2f, 1.7f, 0.6f, 1.2f, GREEN);
                box(-0.6f, -1.4f, 1.1f, 0.6f, -0.4f, 1.5f, RED);
            });
        } else if (type == 3) {
            part(0, -6.2f, 3.8f, 0, 0, 0, () -> {
                final int PR = 0xFFB86B2B, PD = 0xFF8F4E1E;
                for (int side = -1; side <= 1; side += 2) {
                    for (int i = 0; i < 14; i++) {
                        double a = i * Math.PI * 2 / 14;
                        float cx = side * 3.5f + (float) Math.cos(a) * 3.3f, cy = -2.5f + (float) Math.sin(a) * 3.3f;
                        box(cx - 1.1f, cy - 1.1f, -0.7f, cx + 1.1f, cy + 1.1f, 0.7f, i % 3 == 0 ? PD : PR);
                    }
                }
                part(0, 1.5f, 0, 0, 0, 38f, () -> box(-0.9f, -4.5f, -0.9f, 0.9f, 4.5f, 0.9f, PR));
                part(0, 1.5f, 0, 0, 0, -38f, () -> box(-0.9f, -4.5f, -1.2f, 0.9f, 4.5f, 0.6f, PD));
                box(-1.9f, 5.0f, -0.9f, 1.9f, 7.2f, 0.9f, PR);
                box(-4.5f, -1.2f, 0.7f, -3.5f, -0.4f, 1.1f, WHT); box(3.5f, -3.4f, 0.7f, 4.5f, -2.6f, 1.1f, WHT);
                box(-0.4f, 2.2f, 0.7f, 0.6f, 3.0f, 1.1f, WHT);
                box(-2.4f, 6.4f, -1.0f, -0.6f, 8.4f, 1.0f, RED); box(0.6f, 6.4f, -1.0f, 2.4f, 8.4f, 1.0f, RED);
            });
        } else {
            backpack(type, t);
        }
        ps.popPose();
    }

    private static void backpack(int type, float t) {
        final int STRAP = 0xFF23232B, GOLD = 0xFFE3B23C;
        box(-3.4f, -9.6f, -2.58f, -2.2f, 0.5f, -2.46f, STRAP); box(2.2f, -9.6f, -2.58f, 3.4f, 0.5f, -2.46f, STRAP);
        box(-3.4f, 0.2f, -2.58f, -2.2f, 1.1f, 2.5f, STRAP); box(2.2f, 0.2f, -2.58f, 3.4f, 1.1f, 2.5f, STRAP);
        box(-2.3f, -4.4f, -2.62f, 2.3f, -3.8f, -2.5f, STRAP); box(-0.5f, -4.5f, -2.68f, 0.5f, -3.7f, -2.58f, GOLD);
        if (type == 4) {
            final int BAG = 0xFF7A4B2A, DARK = 0xFF4A2D18, ROLL = 0xFF6F43C9, ROLLD = 0xFF4D2C96;
            box(-3.5f, -11.2f, 2.2f, 3.5f, -1.4f, 6.4f, BAG);
            box(-3.6f, -11.3f, 2.1f, 3.6f, -10.3f, 6.5f, DARK);
            box(-3.2f, -5.6f, 6.4f, 3.2f, -1.8f, 7.2f, BAG);
            box(-3.3f, -5.8f, 7.1f, 3.3f, -5.2f, 7.3f, DARK);
            box(-0.6f, -5.0f, 7.2f, 0.6f, -4.0f, 7.5f, GOLD);
            box(-4.7f, -10.0f, 2.9f, -3.5f, -6.0f, 5.7f, DARK); box(3.5f, -10.0f, 2.9f, 4.7f, -6.0f, 5.7f, DARK);
            box(-4.4f, -1.4f, 3.0f, 4.4f, 1.4f, 6.0f, ROLL);
            box(-4.5f, -1.5f, 3.0f, -3.6f, 1.5f, 6.0f, ROLLD); box(3.6f, -1.5f, 3.0f, 4.5f, 1.5f, 6.0f, ROLLD);
            box(-2.5f, 0.9f, 2.9f, -2.0f, 1.6f, 6.1f, DARK); box(2.0f, 0.9f, 2.9f, 2.5f, 1.6f, 6.1f, DARK);
        } else if (type == 5) {
            final int BG = 0xFF17171D, VI = 0xFF7B3FD6, LI = 0xFFA879FF;
            box(-3.6f, -11.0f, 2.2f, 3.6f, -1.2f, 6.2f, BG);
            box(-3.7f, -11.1f, 2.1f, 3.7f, -10.0f, 6.3f, VI);
            box(-3.2f, -8.6f, 6.2f, 3.2f, -3.4f, 7.0f, BG);
            box(-3.3f, -3.6f, 6.1f, 3.3f, -3.3f, 7.1f, VI);
            box(-3.65f, -3.0f, 2.1f, 3.65f, -2.8f, 6.25f, LI);
            box(-0.5f, -1.2f, 3.4f, 0.5f, 1.4f, 4.0f, VI);
            float sw = Mth.sin(t * 0.08f) * 6f;
            part(3.7f, -9.5f, 4.2f, 0, 0, sw, () -> { box(-0.3f, -3.2f, -0.3f, 0.3f, 0, 0.3f, LI); box(-0.9f, -4.6f, -0.9f, 0.9f, -3.2f, 0.9f, 0xFFF6F6FA); });
        } else {
            final int RED = 0xFFC2303B, RED2 = 0xFFA02330, FUR = 0xFFF6F6FA, GREEN = 0xFF2E9B55;
            box(-3.8f, -11.2f, 2.4f, 3.8f, -4.6f, 6.6f, RED);
            box(-3.2f, -4.6f, 2.6f, 3.2f, -1.2f, 6.2f, RED);
            box(-2.6f, -1.2f, 2.9f, 2.6f, 1.4f, 5.9f, RED2);
            box(-4.0f, -11.4f, 2.3f, 4.0f, -10.3f, 6.7f, FUR);
            box(-2.8f, -1.4f, 2.8f, 2.8f, -0.4f, 6.0f, GREEN);
            box(-2.4f, -0.4f, 3.2f, -0.4f, 1.6f, 5.6f, GREEN); box(0.4f, -0.4f, 3.2f, 2.4f, 1.6f, 5.6f, GREEN);
            box(-1.5f, -7.5f, 6.62f, 1.5f, -6.9f, 6.72f, GOLD); box(-0.3f, -8.2f, 6.62f, 0.3f, -6.2f, 6.72f, GOLD);
            box(1.8f, -9.6f, 6.62f, 3.0f, -9.2f, 6.72f, GOLD); box(2.2f, -10.0f, 6.62f, 2.6f, -8.8f, 6.72f, GOLD);
            box(-1.4f, 1.4f, 3.4f, 1.4f, 3.6f, 5.4f, 0xFF2F6FD0); box(-0.3f, 1.4f, 3.4f, 0.3f, 3.7f, 5.4f, 0xFFD92B3A);
        }
    }

    // ---------------- питомцы (начало координат — у ног, y вверх) ----------------
    static void pet(int type, float t, float ph, float walk, float netYaw, float pitch) {
        lookYaw = netYaw;
        lookPitch = pitch;
        if (type == 5) door(t);
        else if (type > 0) PetModels.pet(type, t, ph, walk, netYaw, pitch, Pets.lod);
    }

    private static void door(float t) {
        final int WH = 0xFFF4F4F8, WS = 0xFFDADCE6, FR = 0xFFC9CBD6, GD = 0xFFE3C15A, CR = 0xFF55586A;
        float bob = Mth.sin(t * 0.05f) * 0.6f, swing = Mth.sin(t * 0.035f) * 12f - 6f;
        ps.pushPose();
        ps.translate(0, bob * U, 0);
        box(-6, 0, -1, -5, 21, 1, FR);
        box(5, 0, -1, 6, 13, 1, FR); box(5, 16.5f, -1, 6, 21, 1, FR);
        box(-6, 20, -1, 2, 21, 1, FR);
        part(-5, 0, 0, 0, swing, 0, () -> {
            box(0, 0, -0.7f, 10, 15, 0.7f, WH);
            box(0, 15, -0.7f, 6.5f, 20, 0.7f, WH);
            box(6.5f, 15, -0.7f, 8.5f, 17.5f, 0.7f, WH);
            box(1.2f, 1.5f, -0.8f, 8.8f, 8.5f, -0.7f, WS); box(1.2f, 10.5f, -0.8f, 5.8f, 18.5f, -0.7f, WS);
            box(8.1f, 9.2f, -1.5f, 9.4f, 10.6f, -0.7f, GD);
            box(5.8f, 10.5f, -0.85f, 6.2f, 13f, -0.8f, CR); box(6.2f, 13f, -0.85f, 7.4f, 13.4f, -0.8f, CR);
            box(2.4f, 3f, -0.85f, 2.8f, 6.5f, -0.8f, CR); box(2.8f, 6.5f, -0.85f, 4f, 6.9f, -0.8f, CR);
        });
        box(2, 0, -3, 3.4f, 0.6f, -2.2f, WH); box(-2, 0, 2, -0.8f, 0.5f, 3.2f, WS); box(6, 0, -2, 7, 0.8f, -1.2f, WH);
        ps.popPose();
    }
}
