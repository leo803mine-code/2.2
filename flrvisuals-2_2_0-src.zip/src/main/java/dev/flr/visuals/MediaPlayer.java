package dev.flr.visuals;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.stream.Stream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import net.neoforged.fml.loading.FMLPaths;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.stb.STBVorbisInfo;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

/**
 * Встроенный медиаплеер FLR. Играет .ogg и .wav из папки flrvisuals/music (и встроенный трек) через Java Sound
 * в собственном потоке, не трогая звуковой движок Minecraft. Есть перемотка, громкость, повтор, перемешивание,
 * спектр для визуализации и текст песен из .lrc.
 */
final class MediaPlayer {
    static final class Track {
        final String name, artist, title;
        final Path path;
        final boolean builtin;
        final float hue;
        List<Integer> lrcTime = new ArrayList<>();
        List<String> lrcText = new ArrayList<>();

        Track(String name, Path path, boolean builtin) {
            this.name = name;
            this.path = path;
            this.builtin = builtin;
            int i = name.indexOf(" - ");
            if (i > 0) {
                artist = name.substring(0, i).trim();
                title = name.substring(i + 3).trim();
            } else {
                artist = "";
                title = name;
            }
            hue = (Math.abs(name.hashCode()) % 1000) / 1000f;
        }
    }

    static final List<Track> LIST = new ArrayList<>();
    static volatile int index = -1;
    static volatile boolean playing, loading;
    static volatile String error = "";
    static int skippedMp3;

    private static volatile short[] pcm;
    private static int channels = 2, rate = 44100, bufBytes = 16384;
    private static volatile int total, readIdx;
    private static volatile int seekReq = -1;
    private static volatile boolean endHandled;
    private static SourceDataLine line;
    private static AudioFormat lineFmt;
    private static Thread thread;
    private static Track pending;
    private static final Object LOCK = new Object();
    private static boolean inited;
    private static final float[] BARS = new float[32];
    private static final float[] RE = new float[1024], IM = new float[1024], WIN = new float[1024];
    private static final Random RND = new Random();

    private MediaPlayer() {}

    static Path folder() {
        return FMLPaths.GAMEDIR.get().resolve("flrvisuals").resolve("music");
    }

    static void init() {
        if (inited) return;
        inited = true;
        for (int i = 0; i < 1024; i++) WIN[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / 1023));
        scan();
    }

    static void scan() {
        Track cur = current();
        String curName = cur == null ? null : cur.name;
        List<Track> n = new ArrayList<>();
        if (MediaPlayer.class.getResource("/assets/flrvisuals/sounds/flr_track.ogg") != null) n.add(new Track("FLR Theme", null, true));
        skippedMp3 = 0;
        try {
            Files.createDirectories(folder());
            try (Stream<Path> st = Files.list(folder())) {
                st.sorted().forEach(p -> {
                    String f = p.getFileName().toString(), l = f.toLowerCase(Locale.ROOT);
                    if (l.endsWith(".ogg") || l.endsWith(".wav")) n.add(new Track(f.substring(0, f.lastIndexOf('.')), p, false));
                    else if (l.endsWith(".mp3") || l.endsWith(".flac") || l.endsWith(".m4a")) skippedMp3++;
                });
            }
        } catch (Exception ignored) {
        }
        LIST.clear();
        LIST.addAll(n);
        index = -1;
        if (curName != null) for (int i = 0; i < LIST.size(); i++) if (LIST.get(i).name.equals(curName)) index = i;
    }

    static Track current() {
        int i = index;
        return i >= 0 && i < LIST.size() ? LIST.get(i) : null;
    }

    static void openFolder() {
        try {
            Files.createDirectories(folder());
            net.minecraft.Util.getPlatform().openFile(folder().toFile());
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- управление
    static void play(int i) {
        init();
        if (LIST.isEmpty()) return;
        i = Math.floorMod(i, LIST.size());
        index = i;
        playing = true;
        synchronized (LOCK) {
            pending = LIST.get(i);
        }
        start();
    }

    static void toggle() {
        init();
        if (current() == null) {
            play(0);
            return;
        }
        if (pcm == null && !loading) {
            play(index);
            return;
        }
        playing = !playing;
    }

    static void next() {
        init();
        if (LIST.isEmpty()) return;
        if (Config.mediaShuffle && LIST.size() > 1) {
            int n;
            do { n = RND.nextInt(LIST.size()); } while (n == index);
            play(n);
        } else {
            play(index + 1);
        }
    }

    static void prev() {
        init();
        if (LIST.isEmpty()) return;
        if (positionSec() > 3f) seek(0f);
        else play(index - 1);
    }

    static void seek(float frac) {
        if (pcm == null) return;
        seekReq = (int) (Gfx.clamp01(frac) * total);
        endHandled = false;
    }

    static float positionSec() {
        SourceDataLine l = line;
        if (pcm == null || l == null || rate == 0) return 0f;
        int frame = channels * 2;
        int buffered = (bufBytes - l.available()) / frame;
        return Math.max(0, readIdx - buffered) / (float) rate;
    }

    static float lengthSec() {
        return pcm == null || rate == 0 ? 0f : total / (float) rate;
    }

    static float progress() {
        float len = lengthSec();
        return len <= 0f ? 0f : Gfx.clamp01(positionSec() / len);
    }

    private static void start() {
        if (thread != null && thread.isAlive()) return;
        thread = new Thread(MediaPlayer::run, "FLR-Media");
        thread.setDaemon(true);
        thread.start();
    }

    // ---------------------------------------------------------------- поток воспроизведения
    private static void run() {
        byte[] chunk = new byte[2048 * 4];
        while (true) {
            try {
                Track t;
                synchronized (LOCK) {
                    t = pending;
                    pending = null;
                }
                if (t != null) {
                    load(t);
                    continue;
                }
                short[] p = pcm;
                SourceDataLine l = line;
                if (p == null || l == null) {
                    Thread.sleep(40);
                    continue;
                }
                if (seekReq >= 0) {
                    l.flush();
                    readIdx = Math.min(total, seekReq);
                    seekReq = -1;
                }
                if (!playing) {
                    if (l.isRunning()) l.stop();
                    Thread.sleep(30);
                    continue;
                }
                if (!l.isRunning()) l.start();
                int frameSize = channels * 2;
                if (readIdx >= total) {
                    if (l.available() >= bufBytes - frameSize * 512) {
                        if (!endHandled) {
                            endHandled = true;
                            onEnd();
                        }
                    }
                    Thread.sleep(20);
                    continue;
                }
                int frames = Math.min(2048, total - readIdx);
                int bytes = frames * frameSize;
                if (l.available() < bytes) {
                    Thread.sleep(5);
                    continue;
                }
                float vol = (float) Config.mediaVolume, gain = vol * vol;
                int base = readIdx * channels, cnt = frames * channels;
                if (chunk.length < bytes) chunk = new byte[bytes];
                for (int i = 0; i < cnt; i++) {
                    int s = Math.round(p[base + i] * gain);
                    s = Math.max(-32768, Math.min(32767, s));
                    chunk[i * 2] = (byte) s;
                    chunk[i * 2 + 1] = (byte) (s >> 8);
                }
                l.write(chunk, 0, bytes);
                readIdx += frames;
            } catch (InterruptedException e) {
                return;
            } catch (Throwable e) {
                error = String.valueOf(e.getMessage());
                playing = false;
                try {
                    Thread.sleep(200);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
    }

    private static void onEnd() {
        if (Config.mediaRepeat == 2) {
            seekReq = 0;
            endHandled = false;
        } else if (Config.mediaShuffle && LIST.size() > 1) {
            next();
        } else if (index + 1 < LIST.size() || Config.mediaRepeat == 1) {
            play(index + 1);
        } else {
            playing = false;
            seekReq = 0;
            endHandled = false;
        }
    }

    private static void load(Track t) {
        loading = true;
        error = "";
        pcm = null;
        try {
            int[] meta = new int[2];
            short[] data;
            if (t.builtin) {
                try (InputStream in = MediaPlayer.class.getResourceAsStream("/assets/flrvisuals/sounds/flr_track.ogg")) {
                    data = decodeOgg(in.readAllBytes(), meta);
                }
            } else if (t.path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".ogg")) {
                if (Files.size(t.path) > 250_000_000L) throw new IOException("File is too large");
                data = decodeOgg(Files.readAllBytes(t.path), meta);
            } else {
                data = decodeWav(t.path, meta);
            }
            int ch = meta[0], sr = meta[1];
            AudioFormat fmt = new AudioFormat(sr, 16, ch, true, false);
            if (line == null || lineFmt == null || !lineFmt.matches(fmt)) {
                if (line != null) line.close();
                line = AudioSystem.getSourceDataLine(fmt);
                bufBytes = ch * 2 * Math.max(2048, (int) (sr * 0.35f));
                line.open(fmt, bufBytes);
                bufBytes = line.getBufferSize();
                lineFmt = fmt;
            } else {
                line.stop();
                line.flush();
            }
            loadLrc(t);
            channels = ch;
            rate = sr;
            total = data.length / ch;
            readIdx = 0;
            seekReq = -1;
            endHandled = false;
            pcm = data;
        } catch (Throwable e) {
            error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            playing = false;
            pcm = null;
        } finally {
            loading = false;
        }
    }

    private static short[] decodeOgg(byte[] data, int[] meta) throws IOException {
        ByteBuffer mem = MemoryUtil.memAlloc(data.length);
        mem.put(data).flip();
        long dec = 0L;
        ShortBuffer buf = null;
        try (MemoryStack st = MemoryStack.stackPush()) {
            IntBuffer err = st.mallocInt(1);
            dec = STBVorbis.stb_vorbis_open_memory(mem, err, null);
            if (dec == 0L) throw new IOException("Cannot read OGG (" + err.get(0) + ")");
            STBVorbisInfo info = STBVorbisInfo.malloc(st);
            STBVorbis.stb_vorbis_get_info(dec, info);
            int ch = info.channels(), sr = info.sample_rate();
            int len = STBVorbis.stb_vorbis_stream_length_in_samples(dec);
            if (len <= 0) throw new IOException("Empty OGG");
            buf = MemoryUtil.memAllocShort(len * ch);
            int got = STBVorbis.stb_vorbis_get_samples_short_interleaved(dec, ch, buf);
            int oc = Math.min(2, ch);
            short[] out = new short[got * oc];
            if (ch == oc) {
                for (int i = 0; i < out.length; i++) out[i] = buf.get(i);
            } else {
                for (int i = 0; i < got; i++) {
                    out[i * 2] = buf.get(i * ch);
                    out[i * 2 + 1] = buf.get(i * ch + 1);
                }
            }
            meta[0] = oc;
            meta[1] = sr;
            return out;
        } finally {
            if (dec != 0L) STBVorbis.stb_vorbis_close(dec);
            if (buf != null) MemoryUtil.memFree(buf);
            MemoryUtil.memFree(mem);
        }
    }

    private static short[] decodeWav(Path p, int[] meta) throws Exception {
        try (AudioInputStream in = AudioSystem.getAudioInputStream(p.toFile())) {
            AudioFormat f = in.getFormat();
            int ch = f.getChannels();
            if (ch > 2) throw new IOException("Only mono and stereo are supported");
            AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, f.getSampleRate(), 16, ch, ch * 2, f.getSampleRate(), false);
            try (AudioInputStream conv = AudioSystem.getAudioInputStream(target, in)) {
                byte[] all = conv.readAllBytes();
                short[] out = new short[all.length / 2];
                ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(out);
                meta[0] = ch;
                meta[1] = (int) f.getSampleRate();
                return out;
            }
        }
    }

    private static void loadLrc(Track t) {
        t.lrcTime = new ArrayList<>();
        t.lrcText = new ArrayList<>();
        if (t.path == null) return;
        String f = t.path.getFileName().toString();
        Path lrc = t.path.resolveSibling(f.substring(0, f.lastIndexOf('.')) + ".lrc");
        if (!Files.exists(lrc)) return;
        try {
            List<int[]> tmp = new ArrayList<>();
            List<String> txt = new ArrayList<>();
            for (String ln : Files.readAllLines(lrc, StandardCharsets.UTF_8)) {
                int end = 0;
                List<Integer> times = new ArrayList<>();
                while (end < ln.length() && ln.charAt(end) == '[') {
                    int c = ln.indexOf(']', end);
                    if (c < 0) break;
                    String tag = ln.substring(end + 1, c);
                    int col = tag.indexOf(':');
                    if (col > 0 && Character.isDigit(tag.charAt(0))) {
                        try {
                            int mm = Integer.parseInt(tag.substring(0, col));
                            double ss = Double.parseDouble(tag.substring(col + 1));
                            times.add((int) (mm * 60000 + ss * 1000));
                        } catch (NumberFormatException ignored) {
                        }
                    }
                    end = c + 1;
                }
                String text = ln.substring(end).trim();
                for (int tm : times) {
                    tmp.add(new int[]{tm, txt.size()});
                    txt.add(text);
                }
            }
            tmp.sort((a, b) -> Integer.compare(a[0], b[0]));
            for (int[] e : tmp) {
                t.lrcTime.add(e[0]);
                t.lrcText.add(txt.get(e[1]));
            }
        } catch (Exception ignored) {
        }
    }

    /** Индекс текущей строки текста песни или -1. */
    static int lyricIndex() {
        Track t = current();
        if (t == null || t.lrcTime.isEmpty()) return -1;
        int ms = (int) (positionSec() * 1000f), r = -1;
        for (int i = 0; i < t.lrcTime.size(); i++) {
            if (t.lrcTime.get(i) <= ms) r = i;
            else break;
        }
        return r;
    }

    // ---------------------------------------------------------------- спектр для визуализации
    /** 32 полосы 0..1, сглаженные; вызывать раз в кадр. */
    static float[] spectrum(float dt) {
        short[] p = pcm;
        boolean live = p != null && playing && !loading && line != null;
        if (live) {
            int start = (int) (positionSec() * rate);
            int ch = channels;
            for (int i = 0; i < 1024; i++) {
                int f = start + i;
                float s = 0f;
                if (f >= 0 && f < total) {
                    s = p[f * ch] / 32768f;
                    if (ch == 2) s = (s + p[f * ch + 1] / 32768f) * 0.5f;
                }
                RE[i] = s * WIN[i];
                IM[i] = 0f;
            }
            fft();
            for (int b = 0; b < BARS.length; b++) {
                float lo = 2f + (float) Math.pow(380.0 / 2.0, b / (double) BARS.length) * 2f - 2f;
                float hi = 2f + (float) Math.pow(380.0 / 2.0, (b + 1) / (double) BARS.length) * 2f - 2f;
                int i0 = Math.max(1, (int) lo), i1 = Math.max(i0 + 1, (int) hi);
                float m = 0f;
                for (int i = i0; i < i1 && i < 512; i++) m = Math.max(m, (float) Math.sqrt(RE[i] * RE[i] + IM[i] * IM[i]));
                float v = Gfx.clamp01((float) Math.pow(m / 60f * (1f + b * 0.12f), 0.55));
                BARS[b] = v > BARS[b] ? Gfx.lerp(BARS[b], v, 0.6f) : BARS[b] - dt * 1.6f;
                if (BARS[b] < 0f) BARS[b] = 0f;
            }
        } else {
            for (int b = 0; b < BARS.length; b++) BARS[b] = Math.max(0f, BARS[b] - dt * 1.2f);
        }
        return BARS;
    }

    private static void fft() {
        int n = 1024;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                float tr = RE[i]; RE[i] = RE[j]; RE[j] = tr;
                float ti = IM[i]; IM[i] = IM[j]; IM[j] = ti;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2 * Math.PI / len;
            float wr = (float) Math.cos(ang), wi = (float) Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                float cr = 1f, ci = 0f;
                for (int k = 0; k < len / 2; k++) {
                    int a = i + k, b = i + k + len / 2;
                    float xr = RE[b] * cr - IM[b] * ci, xi = RE[b] * ci + IM[b] * cr;
                    RE[b] = RE[a] - xr; IM[b] = IM[a] - xi;
                    RE[a] += xr; IM[a] += xi;
                    float nr = cr * wr - ci * wi;
                    ci = cr * wi + ci * wr;
                    cr = nr;
                }
            }
        }
    }

    static String time(float sec) {
        int s = Math.max(0, (int) sec);
        return (s / 60) + ":" + String.format(Locale.ROOT, "%02d", s % 60);
    }
}
