package dev.flr.visuals;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.joml.Vector3f;

public final class GameEvents {
    private static double acc;
    private static boolean swapped, armorWarn;
    private static int cooldown, armorTick, allowTick;
    /** Ближайшие игроки (до Config.maxPlayers), которым рисуется косметика. Обновляется 2 раза в секунду. */
    public static final Set<UUID> ALLOWED = new HashSet<>();

    public static void tick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        Gamepad.tick(mc);
        TargetEsp.tick(mc);
        while (FlrKeys.MASTER.consumeClick()) {
            Config.master = !Config.master;
            Config.save();
            if (mc.player != null) mc.player.displayClientMessage(Component.literal(Tr.fmt("FLR Visuals: %s", Tr.tr(Config.master ? "ON" : "OFF"))), true);
        }
        while (FlrKeys.AUTOSWAP.consumeClick()) {
            Config.autoSwap = !Config.autoSwap;
            Config.save();
            if (mc.player != null) say(mc.player, Tr.fmt("Auto Swap: %s", Tr.tr(Config.autoSwap ? "ON" : "OFF")), Config.autoSwap ? ChatFormatting.GREEN : ChatFormatting.RED);
        }
        while (FlrKeys.MENU.consumeClick()) mc.setScreen(new CosmeticsScreen());
        while (FlrKeys.SOUND.consumeClick()) MediaPlayer.toggle();

        LocalPlayer self = mc.player;
        if (self == null || mc.level == null) return;
        autoSwap(mc, self);
        armorAlert(self);
        if (!Config.master || mc.isPaused()) return;
        updateAllowed(mc, self);
        effects(mc, self);
    }

    /** Сообщение функции: над хотбаром, в чате или выключено (Config.msgMode). */
    private static void say(LocalPlayer p, String text, ChatFormatting color) {
        if (Config.msgMode == 2) return;
        if (Config.msgMode == 0) {
            Integer c = color.getColor();
            Notify.show(text, c == null ? 0xFFFFFF : c);
            return;
        }
        p.displayClientMessage(Component.literal("[FLR] " + text).withStyle(color), false);
    }

    private static void updateAllowed(Minecraft mc, LocalPlayer self) {
        if (++allowTick < 10) return;
        allowTick = 0;
        ALLOWED.clear();
        if (!Config.others) return;
        double maxD2 = (double) Config.maxDistance * Config.maxDistance;
        List<Player> list = new ArrayList<>();
        for (Player pl : mc.level.players()) {
            if (pl != self && pl.distanceToSqr(self) <= maxD2) list.add(pl);
        }
        list.sort(Comparator.comparingDouble((Player pl) -> pl.distanceToSqr(self)));
        for (int i = 0; i < list.size() && i < Config.maxPlayers; i++) ALLOWED.add(list.get(i).getUUID());
    }

    /** Броня вот-вот сломается: функция включается, пока прочность любой детали ниже порога; после починки выключается. */
    private static void armorAlert(LocalPlayer p) {
        if (!Config.armorAlert) {
            armorWarn = false;
            return;
        }
        if (++armorTick < 10) return;
        armorTick = 0;
        boolean low = false;
        boolean recovered = true;
        String piece = "";
        for (ItemStack s : p.getInventory().armor) {
            if (s.isEmpty() || !s.isDamageableItem()) continue;
            int max = s.getMaxDamage();
            if (max <= 0) continue;
            double left = (max - s.getDamageValue()) * 100.0 / max;
            if (left <= Config.armorPercent) {
                low = true;
                piece = s.getHoverName().getString();
            }
            if (left <= Config.armorPercent + 3) recovered = false;
        }
        if (low && !armorWarn) {
            armorWarn = true;
            say(p, Tr.fmt("Armor is about to break (%s)! Armor Alert activated", piece), ChatFormatting.RED);
        } else if (armorWarn && recovered) {
            armorWarn = false;
            say(p, Tr.tr("Armor is OK. Armor Alert deactivated"), ChatFormatting.GREEN);
        }
    }

    /** Падение выше Config.swapHeight блоков: достаём тотем бессмертия в offhand (если он есть в инвентаре). */
    private static void autoSwap(Minecraft mc, LocalPlayer p) {
        if (cooldown > 0) cooldown--;
        if (p.onGround() || p.isInWater()) {
            if (swapped) {
                swapped = false;
            }
            return;
        }
        if (!Config.autoSwap || swapped || cooldown > 0 || p.isSpectator() || p.isFallFlying() || p.getAbilities().flying) return;
        if (p.fallDistance <= Config.swapHeight) return;
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            swapped = true;
            return;
        }
        if (mc.gameMode == null || p.containerMenu != p.inventoryMenu) return;
        Inventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            if (!inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) continue;
            int slot = i < 9 ? i + 36 : i; // hotbar -> 36..44 в меню инвентаря
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
            swapped = true;
            cooldown = 10;
            return;
        }
    }

    private static ParticleOptions option() {
        int c = Config.color();
        return switch (Config.particleType) {
            case 0 -> ParticleTypes.END_ROD;
            case 1 -> ParticleTypes.HEART;
            case 2 -> ParticleTypes.GLOW;
            case 3 -> ParticleTypes.SNOWFLAKE;
            case 4 -> ParticleTypes.ELECTRIC_SPARK;
            default -> new DustParticleOptions(new Vector3f((c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f), 1f);
        };
    }

    private static void effects(Minecraft mc, LocalPlayer self) {
        int budget = Config.effectiveBudget();
        RandomSource r = mc.level.random;

        // искры при ударе
        if (Config.hitSparks && self.swinging && self.swingTime == 0) {
            HitResult hr = mc.hitResult;
            if (hr instanceof EntityHitResult) {
                Vec3 l = hr.getLocation();
                for (int i = 0; i < 6; i++)
                    mc.level.addParticle(ParticleTypes.ELECTRIC_SPARK, l.x, l.y, l.z,
                            (r.nextDouble() - 0.5) * 0.4, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.4);
            }
        }
        if (budget <= 0 || !(Config.aura || Config.trail || Config.halo || Config.ambient)) return;
        acc += budget * 0.02;
        int n = (int) acc;
        acc -= n;
        if (n <= 0) return;

        double maxD2 = (double) Config.maxDistance * Config.maxDistance;
        ParticleOptions o = option();
        double s = Config.scale;
        for (Player pl : mc.level.players()) {
            boolean me = pl == self;
            if ((pl.isInvisible() && !Config.showInvisible) || pl.isSpectator()) continue;
            if (!me && (!Config.others || pl.distanceToSqr(self) > maxD2 || !ALLOWED.contains(pl.getUUID()))) continue;
            double h = pl.getBbHeight();
            boolean moving = pl.getDeltaMovement().horizontalDistanceSqr() > 0.002;
            for (int i = 0; i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2;
                if (Config.aura)
                    mc.level.addParticle(o, pl.getX() + Math.cos(a) * 0.6 * s, pl.getY() + r.nextDouble() * h, pl.getZ() + Math.sin(a) * 0.6 * s, 0, 0.02, 0);
                if (Config.halo && i == 0)
                    mc.level.addParticle(o, pl.getX() + Math.cos(a) * 0.25 * s, pl.getY() + h + 0.25 * s, pl.getZ() + Math.sin(a) * 0.25 * s, 0, 0, 0);
                if (Config.trail && moving)
                    mc.level.addParticle(o, pl.getX() + (r.nextDouble() - 0.5) * 0.4, pl.getY() + 0.1, pl.getZ() + (r.nextDouble() - 0.5) * 0.4, 0, 0.01, 0);
                if (Config.ambient && me)
                    mc.level.addParticle(ParticleTypes.GLOW, pl.getX() + (r.nextDouble() - 0.5) * 8, pl.getY() + r.nextDouble() * 3, pl.getZ() + (r.nextDouble() - 0.5) * 8,
                            (r.nextDouble() - 0.5) * 0.01, (r.nextDouble() - 0.5) * 0.01, (r.nextDouble() - 0.5) * 0.01);
            }
        }
    }
}
