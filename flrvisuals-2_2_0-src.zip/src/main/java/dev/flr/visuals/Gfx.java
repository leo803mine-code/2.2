package dev.flr.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * Собственный 2D-рендер FLR: сглаженные скруглённые фигуры, мягкие свечения, градиенты, гладкий текст и иконки.
 * Рисует треугольниками напрямую, без ванильных fill/drawString, поэтому ничего не «квадратится» при любом масштабе GUI.
 * Координаты — в единицах GUI (дробные), края сглаживаются перьями шириной в 1 физический пиксель.
 */
final class Gfx {
    // иконки
    static final int PLAY = 0, PAUSE = 1, NEXT = 2, PREV = 3, SHUFFLE = 4, REPEAT = 5, REPEAT1 = 6, VOLUME = 7, MUTE = 8, NOTE = 9,
            SEARCH = 10, CLOSE = 11, PLUS = 12, CHECK = 13, GEAR = 14, CHEV_R = 15, CHEV_L = 16, CHEV_D = 17, CHEV_U = 18,
            SPARK = 19, BOLT = 20, CLOUD = 21, DROP = 22, CHIP = 23, FRAME = 24, SLIDERS = 25, REFRESH = 26, STAR = 27,
            FOLDER = 28, USER = 29, KEY = 30;

    private static GuiGraphics g;
    private static final Matrix4f M = new Matrix4f();
    static float S = 2f, E = 0.25f;
    private static BufferBuilder bb;
    private static int mode;
    private static Object texKey;

    private static final float[] PX = new float[160], PY = new float[160], QX = new float[160], QY = new float[160];
    private static float gx, gy, gw, gh;
    private static int g00, g10, g01, g11;
    private static boolean solid = true;

    private Gfx() {}

    // ---------------------------------------------------------------- состояние
    static void use(GuiGraphics gg) {
        Matrix4f cur = gg.pose().last().pose();
        if (g != gg || !M.equals(cur)) {
            flush();
            g = gg;
            M.set(cur);
        }
        if (bb == null) gg.flush();
        S = (float) Minecraft.getInstance().getWindow().getGuiScale();
        E = 0.5f / S;
    }

    static void begin(GuiGraphics gg) {
        use(gg);
    }

    static void end() {
        flush();
    }

    static void flush() {
        if (bb == null) return;
        MeshData md = bb.build();
        bb = null;
        if (md == null) return;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        if (mode == 1) {
            RenderSystem.setShader(GameRenderer::getPositionColorShader);
        } else {
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            if (texKey instanceof ResourceLocation rl) RenderSystem.setShaderTexture(0, rl);
            else RenderSystem.setShaderTexture(0, (Integer) texKey);
        }
        BufferUploader.drawWithShader(md);
        RenderSystem.enableCull();
    }

    private static void ensure(int m, Object key) {
        if (bb != null && (mode != m || (m == 2 && !key.equals(texKey)))) flush();
        if (bb == null) {
            mode = m;
            texKey = key;
            bb = Tesselator.getInstance().begin(VertexFormat.Mode.TRIANGLES,
                    m == 1 ? DefaultVertexFormat.POSITION_COLOR : DefaultVertexFormat.POSITION_TEX_COLOR);
        }
    }

    private static void v(float x, float y, int c) {
        bb.addVertex(M, x, y, 0f).setColor(c);
    }

    private static void vt(float x, float y, float u, float w, int c) {
        bb.addVertex(M, x, y, 0f).setUv(u, w).setColor(c);
    }

    private static void tri(float x1, float y1, int c1, float x2, float y2, int c2, float x3, float y3, int c3) {
        v(x1, y1, c1);
        v(x2, y2, c2);
        v(x3, y3, c3);
    }

    // ---------------------------------------------------------------- цвет
    static int a(int c, float m) {
        int al = (int) (((c >>> 24) & 255) * m);
        return (Math.max(0, Math.min(255, al)) << 24) | (c & 0xFFFFFF);
    }

    static int rgba(int rgb, float alpha) {
        return (Math.max(0, Math.min(255, (int) (alpha * 255f))) << 24) | (rgb & 0xFFFFFF);
    }

    static int mix(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int al = (int) (((c1 >>> 24) & 255) * (1 - t) + ((c2 >>> 24) & 255) * t);
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int gg = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return al << 24 | r << 16 | gg << 8 | b;
    }

    static int hsb(float h, float s, float b) {
        return 0xFF000000 | (Color.HSBtoRGB(h, s, b) & 0xFFFFFF);
    }

    static int bright(int c, float k) {
        int r = Math.min(255, (int) (((c >> 16) & 255) * k)), gg = Math.min(255, (int) (((c >> 8) & 255) * k)), b = Math.min(255, (int) ((c & 255) * k));
        return (c & 0xFF000000) | r << 16 | gg << 8 | b;
    }

    /** Сдвигает оттенок цвета (для второго и третьего цвета фона). */
    static int shift(int c, float dh, float ds, float db) {
        float[] hsb = Color.RGBtoHSB((c >> 16) & 255, (c >> 8) & 255, c & 255, null);
        float h = (hsb[0] + dh + 1f) % 1f;
        return 0xFF000000 | (Color.HSBtoRGB(h, Math.max(0f, Math.min(1f, hsb[1] + ds)), Math.max(0f, Math.min(1f, hsb[2] + db))) & 0xFFFFFF);
    }

    static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : Math.min(v, hi);
    }

    static float clamp01(float v) {
        return clamp(v, 0f, 1f);
    }

    static float ease(float t) {
        t = clamp01(t);
        return t * t * (3f - 2f * t);
    }

    static float outBack(float t) {
        t = clamp01(t);
        float c1 = 1.5f, c3 = c1 + 1f, u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    static float k(float dt, float rate) {
        return 1f - (float) Math.exp(-rate * dt);
    }

    static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    // ---------------------------------------------------------------- градиентная заливка
    private static void grad(float x, float y, float w, float h, int c00, int c10, int c01, int c11) {
        gx = x; gy = y; gw = w; gh = h;
        g00 = c00; g10 = c10; g01 = c01; g11 = c11;
        solid = c00 == c10 && c00 == c01 && c00 == c11;
    }

    private static int ch(int c1, int c2, float t, int sh) {
        return (int) (((c1 >> sh) & 255) * (1 - t) + ((c2 >> sh) & 255) * t);
    }

    private static int cc(float px, float py, float mul) {
        int c;
        if (solid) {
            c = g00;
        } else {
            float u = gw <= 0 ? 0 : clamp01((px - gx) / gw), w = gh <= 0 ? 0 : clamp01((py - gy) / gh);
            int res = 0;
            for (int sh = 0; sh <= 24; sh += 8) {
                int t1 = ch(g00, g10, u, sh), b1 = ch(g01, g11, u, sh);
                res |= (t1 + (int) ((b1 - t1) * w)) << sh;
            }
            c = res;
        }
        return mul >= 0.999f ? c : a(c, mul);
    }

    // ---------------------------------------------------------------- контуры скруглённого прямоугольника
    private static int segs(float r) {
        if (r <= 0.05f) return 1;
        return Math.max(2, Math.min(18, (int) Math.ceil(r * S * 0.55f) + 1));
    }

    private static int outline(float[] ox, float[] oy, float x, float y, float w, float h, float r, int n, float off) {
        float bx = x - off, by = y - off, bw = w + 2 * off, bh = h + 2 * off;
        float rr = Math.max(0f, Math.min(r + off, Math.min(bw, bh) / 2f));
        int k = 0;
        for (int c = 0; c < 4; c++) {
            float cx = (c == 0 || c == 3) ? bx + rr : bx + bw - rr;
            float cy = c < 2 ? by + rr : by + bh - rr;
            for (int i = 0; i <= n; i++) {
                double an = Math.PI / 2 * i / n;
                float ca = (float) Math.cos(an), sa = (float) Math.sin(an), dx, dy;
                switch (c) {
                    case 0 -> { dx = -ca; dy = -sa; }
                    case 1 -> { dx = sa; dy = -ca; }
                    case 2 -> { dx = ca; dy = sa; }
                    default -> { dx = -sa; dy = ca; }
                }
                ox[k] = cx + rr * dx;
                oy[k] = cy + rr * dy;
                k++;
            }
        }
        return k;
    }

    private static void fan(float x, float y, float w, float h, float r, int n, float off, float mul) {
        int cnt = outline(PX, PY, x, y, w, h, r, n, off);
        float mx = x + w / 2f, my = y + h / 2f;
        int cm = cc(mx, my, mul);
        int cp = cc(PX[0], PY[0], mul);
        for (int i = 0; i < cnt; i++) {
            int j = (i + 1) % cnt;
            int cn = solid ? cp : cc(PX[j], PY[j], mul);
            tri(mx, my, cm, PX[i], PY[i], cp, PX[j], PY[j], cn);
            cp = cn;
        }
    }

    private static void band(float x, float y, float w, float h, float r, int n, float offA, float mA, float offB, float mB) {
        int cnt = outline(PX, PY, x, y, w, h, r, n, offA);
        outline(QX, QY, x, y, w, h, r, n, offB);
        for (int i = 0; i < cnt; i++) {
            int j = (i + 1) % cnt;
            int a0 = cc(PX[i], PY[i], mA), b0 = cc(QX[i], QY[i], mB), a1 = cc(PX[j], PY[j], mA), b1 = cc(QX[j], QY[j], mB);
            tri(PX[i], PY[i], a0, QX[i], QY[i], b0, QX[j], QY[j], b1);
            tri(PX[i], PY[i], a0, QX[j], QY[j], b1, PX[j], PY[j], a1);
        }
    }

    // ---------------------------------------------------------------- фигуры
    /** Сглаженный скруглённый прямоугольник. */
    static void rr(float x, float y, float w, float h, float r, int c) {
        if ((c >>> 24) == 0 || w <= 0 || h <= 0) return;
        ensure(1, null);
        grad(x, y, w, h, c, c, c, c);
        r = Math.min(r, Math.min(w, h) / 2f);
        int n = segs(r);
        fan(x, y, w, h, r, n, -E, 1f);
        band(x, y, w, h, r, n, -E, 1f, E, 0f);
    }

    /** Градиент по четырём углам: левый-верх, правый-верх, левый-низ, правый-низ. */
    static void rr4(float x, float y, float w, float h, float r, int c00, int c10, int c01, int c11) {
        if (w <= 0 || h <= 0) return;
        ensure(1, null);
        grad(x, y, w, h, c00, c10, c01, c11);
        r = Math.min(r, Math.min(w, h) / 2f);
        int n = segs(r);
        fan(x, y, w, h, r, n, -E, 1f);
        band(x, y, w, h, r, n, -E, 1f, E, 0f);
    }

    static void rrV(float x, float y, float w, float h, float r, int top, int bot) {
        rr4(x, y, w, h, r, top, top, bot, bot);
    }

    static void rrH(float x, float y, float w, float h, float r, int left, int right) {
        rr4(x, y, w, h, r, left, right, left, right);
    }

    /** Контур толщиной t внутрь от границы. */
    static void ring(float x, float y, float w, float h, float r, float t, int c) {
        if ((c >>> 24) == 0 || w <= 0 || h <= 0) return;
        ensure(1, null);
        float mul = 1f;
        if (t < 4 * E) {
            mul = t / (4 * E);
            t = 4 * E;
        }
        grad(x, y, w, h, c, c, c, c);
        r = Math.min(r, Math.min(w, h) / 2f);
        int n = segs(r);
        band(x, y, w, h, r, n, E, 0f, -E, mul);
        band(x, y, w, h, r, n, -E, mul, -t + E, mul);
        band(x, y, w, h, r, n, -t + E, mul, -t - E, 0f);
    }

    /** Мягкая тень/свечение вокруг прямоугольника (альфа цвета — сила у границы). */
    static void glow(float x, float y, float w, float h, float r, float spread, int c) {
        if ((c >>> 24) == 0 || spread <= 0) return;
        ensure(1, null);
        grad(x, y, w, h, c, c, c, c);
        r = Math.min(r, Math.min(w, h) / 2f);
        int n = segs(r + spread * 0.4f);
        fan(x, y, w, h, r, n, 0f, 1f);
        float[] off = {0f, 0.25f, 0.5f, 0.75f, 1f}, al = {1f, 0.6f, 0.27f, 0.08f, 0f};
        for (int i = 0; i < 4; i++) band(x, y, w, h, r, n, off[i] * spread, al[i], off[i + 1] * spread, al[i + 1]);
    }

    static void circle(float cx, float cy, float rad, int c) {
        rr(cx - rad, cy - rad, rad * 2, rad * 2, rad, c);
    }

    static void circleRing(float cx, float cy, float rad, float t, int c) {
        ring(cx - rad, cy - rad, rad * 2, rad * 2, rad, t, c);
    }

    /** Круглое свечение с плавным спадом от центра (для фоновых «шаров» и бликов). */
    static void orb(float cx, float cy, float rad, int c) {
        if ((c >>> 24) == 0 || rad <= 0) return;
        ensure(1, null);
        int n = Math.max(16, Math.min(64, (int) (rad * S * 0.35f)));
        int rings = 9;
        float[] cs = new float[n + 1], sn = new float[n + 1];
        for (int i = 0; i <= n; i++) {
            cs[i] = (float) Math.cos(Math.PI * 2 * i / n);
            sn[i] = (float) Math.sin(Math.PI * 2 * i / n);
        }
        for (int r = 0; r < rings; r++) {
            float t0 = r / (float) rings, t1 = (r + 1) / (float) rings;
            float a0 = (1f - t0) * (1f - t0), a1 = (1f - t1) * (1f - t1);
            int c0 = a(c, a0), c1 = a(c, a1);
            float r0 = rad * t0, r1 = rad * t1;
            for (int i = 0; i < n; i++) {
                if (r == 0) {
                    tri(cx, cy, c0, cx + cs[i] * r1, cy + sn[i] * r1, c1, cx + cs[i + 1] * r1, cy + sn[i + 1] * r1, c1);
                } else {
                    tri(cx + cs[i] * r0, cy + sn[i] * r0, c0, cx + cs[i] * r1, cy + sn[i] * r1, c1, cx + cs[i + 1] * r1, cy + sn[i + 1] * r1, c1);
                    tri(cx + cs[i] * r0, cy + sn[i] * r0, c0, cx + cs[i + 1] * r1, cy + sn[i + 1] * r1, c1, cx + cs[i + 1] * r0, cy + sn[i + 1] * r0, c0);
                }
            }
        }
    }

    /** Простой прямоугольник без сглаживания (для линий-разделителей и фонов во весь экран). */
    static void rect(float x, float y, float w, float h, int c) {
        if ((c >>> 24) == 0) return;
        ensure(1, null);
        tri(x, y, c, x + w, y, c, x + w, y + h, c);
        tri(x, y, c, x + w, y + h, c, x, y + h, c);
    }

    static void rect4(float x, float y, float w, float h, int c00, int c10, int c01, int c11) {
        ensure(1, null);
        tri(x, y, c00, x + w, y, c10, x + w, y + h, c11);
        tri(x, y, c00, x + w, y + h, c11, x, y + h, c01);
    }

    static void quad(float x1, float y1, int c1, float x2, float y2, int c2, float x3, float y3, int c3, float x4, float y4, int c4) {
        ensure(1, null);
        tri(x1, y1, c1, x2, y2, c2, x3, y3, c3);
        tri(x1, y1, c1, x3, y3, c3, x4, y4, c4);
    }

    /** Линия со скруглёнными концами. */
    static void line(float x1, float y1, float x2, float y2, float w, int c) {
        if ((c >>> 24) == 0) return;
        float r = Math.max(w / 2f, E * 1.2f);
        float dx = x2 - x1, dy = y2 - y1;
        if (dx * dx + dy * dy < 1e-6f) {
            circle(x1, y1, r, c);
            return;
        }
        ensure(1, null);
        float ang = (float) Math.atan2(dy, dx);
        int n = Math.max(3, segs(r));
        int cnt = 0;
        float ri = Math.max(0.01f, r - E), ro = r + E;
        for (int i = 0; i <= n; i++) {
            double an = ang - Math.PI / 2 + Math.PI * i / n;
            float ca = (float) Math.cos(an), sa = (float) Math.sin(an);
            PX[cnt] = x2 + ca * ri; PY[cnt] = y2 + sa * ri; QX[cnt] = x2 + ca * ro; QY[cnt] = y2 + sa * ro; cnt++;
        }
        for (int i = 0; i <= n; i++) {
            double an = ang + Math.PI / 2 + Math.PI * i / n;
            float ca = (float) Math.cos(an), sa = (float) Math.sin(an);
            PX[cnt] = x1 + ca * ri; PY[cnt] = y1 + sa * ri; QX[cnt] = x1 + ca * ro; QY[cnt] = y1 + sa * ro; cnt++;
        }
        float mx = (x1 + x2) / 2f, my = (y1 + y2) / 2f;
        int tr = a(c, 0f);
        for (int i = 0; i < cnt; i++) {
            int j = (i + 1) % cnt;
            tri(mx, my, c, PX[i], PY[i], c, PX[j], PY[j], c);
            tri(PX[i], PY[i], c, QX[i], QY[i], tr, QX[j], QY[j], tr);
            tri(PX[i], PY[i], c, QX[j], QY[j], tr, PX[j], PY[j], c);
        }
    }

    /** Дуга-обводка (для круговых индикаторов). Углы в радианах, 0 — вправо, по часовой стрелке. */
    static void arc(float cx, float cy, float rad, float thick, float a0, float a1, int c) {
        if ((c >>> 24) == 0 || a1 <= a0) return;
        ensure(1, null);
        int m = Math.max(4, Math.min(120, (int) Math.ceil((a1 - a0) * rad * S * 0.3f)));
        float h = thick / 2f;
        float[] rs = {rad - h - E, rad - h + E, rad + h - E, rad + h + E};
        float[] al = {0f, 1f, 1f, 0f};
        for (int b = 0; b < 3; b++) {
            float rA = Math.max(0f, rs[b]), rB = Math.max(0f, rs[b + 1]);
            int cA = a(c, al[b]), cB = a(c, al[b + 1]);
            for (int i = 0; i < m; i++) {
                float t0 = a0 + (a1 - a0) * i / m, t1 = a0 + (a1 - a0) * (i + 1) / m;
                float c0 = (float) Math.cos(t0), s0 = (float) Math.sin(t0), c1 = (float) Math.cos(t1), s1 = (float) Math.sin(t1);
                tri(cx + c0 * rA, cy + s0 * rA, cA, cx + c0 * rB, cy + s0 * rB, cB, cx + c1 * rB, cy + s1 * rB, cB);
                tri(cx + c0 * rA, cy + s0 * rA, cA, cx + c1 * rB, cy + s1 * rB, cB, cx + c1 * rA, cy + s1 * rA, cA);
            }
        }
    }

    /** Заполненный многоугольник, «звёздчатый» относительно центра (треугольники, звёзды, стрелки). */
    static void poly(float[] xs, float[] ys, int n, int c) {
        if ((c >>> 24) == 0) return;
        ensure(1, null);
        float cx = 0, cy = 0;
        for (int i = 0; i < n; i++) { cx += xs[i]; cy += ys[i]; }
        cx /= n; cy /= n;
        int tr = a(c, 0f);
        for (int i = 0; i < n; i++) {
            PX[i] = xs[i]; PY[i] = ys[i];
            float dx = xs[i] - cx, dy = ys[i] - cy, len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1e-4f) { dx = 0; dy = 0; len = 1; }
            dx /= len; dy /= len;
            PX[i] = xs[i] - dx * E; PY[i] = ys[i] - dy * E;
            QX[i] = xs[i] + dx * E; QY[i] = ys[i] + dy * E;
        }
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            tri(cx, cy, c, PX[i], PY[i], c, PX[j], PY[j], c);
            tri(PX[i], PY[i], c, QX[i], QY[i], tr, QX[j], QY[j], tr);
            tri(PX[i], PY[i], c, QX[j], QY[j], tr, PX[j], PY[j], c);
        }
    }

    private static final float[] T3X = new float[3], T3Y = new float[3];

    static void tri3(float x1, float y1, float x2, float y2, float x3, float y3, int c) {
        T3X[0] = x1; T3X[1] = x2; T3X[2] = x3;
        T3Y[0] = y1; T3Y[1] = y2; T3Y[2] = y3;
        poly(T3X, T3Y, 3, c);
    }

    // ---------------------------------------------------------------- текстуры
    static void tex(ResourceLocation rl, float x, float y, float w, float h, float u0, float v0, float u1, float v1, int c) {
        ensure(2, rl);
        vt(x, y, u0, v0, c);
        vt(x + w, y, u1, v0, c);
        vt(x + w, y + h, u1, v1, c);
        vt(x, y, u0, v0, c);
        vt(x + w, y + h, u1, v1, c);
        vt(x, y + h, u0, v1, c);
    }

    // ---------------------------------------------------------------- текст
    static float textW(String s, float size, boolean bold) {
        if (s == null || s.isEmpty()) return 0f;
        Fonts.Atlas at = Fonts.get(bold, 40f);
        float f = size / at.px, w = 0f;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            Fonts.Glyph gl = at.get(cp);
            if (gl != null) w += gl.adv * f;
        }
        return w;
    }

    /** Текст; (x, y) — левый верх строки высотой size. */
    static void text(String s, float x, float y, float size, int color, boolean bold) {
        if (s == null || s.isEmpty() || (color >>> 24) == 0) return;
        Fonts.Atlas at = Fonts.get(bold, size * S);
        float f = size / at.px;
        float pen = Math.round(x * S) / S;
        float base = Math.round((y + at.ascent * f) * S) / S;
        ensure(2, at.tex);
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            Fonts.Glyph gl = at.get(cp);
            if (gl == null) continue;
            if (gl.vis) {
                float x0 = pen + gl.x0 * f, y0 = base + gl.y0 * f, x1 = pen + gl.x1 * f, y1 = base + gl.y1 * f;
                vt(x0, y0, gl.s0, gl.t0, color);
                vt(x1, y0, gl.s1, gl.t0, color);
                vt(x1, y1, gl.s1, gl.t1, color);
                vt(x0, y0, gl.s0, gl.t0, color);
                vt(x1, y1, gl.s1, gl.t1, color);
                vt(x0, y1, gl.s0, gl.t1, color);
            }
            pen += gl.adv * f;
        }
    }

    /** Текст, центрированный по вертикали относительно cy (по высоте заглавных). */
    static void textMid(String s, float x, float cy, float size, int color, boolean bold) {
        Fonts.Atlas at = Fonts.get(bold, size * S);
        float f = size / at.px;
        text(s, x, cy - (at.ascent - at.cap * 0.5f) * f, size, color, bold);
    }

    static void textC(String s, float cx, float cy, float size, int color, boolean bold) {
        textMid(s, cx - textW(s, size, bold) / 2f, cy, size, color, bold);
    }

    static void textR(String s, float rx, float cy, float size, int color, boolean bold) {
        textMid(s, rx - textW(s, size, bold), cy, size, color, bold);
    }

    static String fit(String s, float maxW, float size, boolean bold) {
        if (textW(s, size, bold) <= maxW) return s;
        String t = s;
        while (t.length() > 1 && textW(t + "…", size, bold) > maxW) t = t.substring(0, t.length() - 1);
        return t + "…";
    }

    // ---------------------------------------------------------------- обрезка
    static void scissor(float x, float y, float w, float h) {
        flush();
        g.enableScissor((int) Math.floor(x), (int) Math.floor(y), (int) Math.ceil(x + w), (int) Math.ceil(y + h));
    }

    static void unscissor() {
        flush();
        g.disableScissor();
    }

    // ---------------------------------------------------------------- иконки
    private static final float[] IX = new float[12], IY = new float[12];

    static void icon(int id, float cx, float cy, float s, int c) {
        float h = s * 0.5f, lw = Math.max(1.2f, s * 0.1f);
        switch (id) {
            case PLAY -> tri3(cx - h * 0.5f, cy - h * 0.75f, cx + h * 0.8f, cy, cx - h * 0.5f, cy + h * 0.75f, c);
            case PAUSE -> {
                rr(cx - h * 0.62f, cy - h * 0.7f, h * 0.42f, h * 1.4f, h * 0.14f, c);
                rr(cx + h * 0.2f, cy - h * 0.7f, h * 0.42f, h * 1.4f, h * 0.14f, c);
            }
            case NEXT -> {
                tri3(cx - h * 0.75f, cy - h * 0.7f, cx + h * 0.3f, cy, cx - h * 0.75f, cy + h * 0.7f, c);
                rr(cx + h * 0.42f, cy - h * 0.7f, h * 0.3f, h * 1.4f, h * 0.12f, c);
            }
            case PREV -> {
                tri3(cx + h * 0.75f, cy - h * 0.7f, cx - h * 0.3f, cy, cx + h * 0.75f, cy + h * 0.7f, c);
                rr(cx - h * 0.72f, cy - h * 0.7f, h * 0.3f, h * 1.4f, h * 0.12f, c);
            }
            case SHUFFLE -> {
                line(cx - h * 0.8f, cy - h * 0.5f, cx - h * 0.1f, cy - h * 0.5f, lw, c);
                line(cx - h * 0.1f, cy - h * 0.5f, cx + h * 0.4f, cy + h * 0.5f, lw, c);
                line(cx - h * 0.8f, cy + h * 0.5f, cx - h * 0.1f, cy + h * 0.5f, lw, c);
                line(cx - h * 0.1f, cy + h * 0.5f, cx + h * 0.4f, cy - h * 0.5f, lw, c);
                tri3(cx + h * 0.35f, cy - h * 0.85f, cx + h * 0.9f, cy - h * 0.5f, cx + h * 0.35f, cy - h * 0.15f, c);
                tri3(cx + h * 0.35f, cy + h * 0.15f, cx + h * 0.9f, cy + h * 0.5f, cx + h * 0.35f, cy + h * 0.85f, c);
            }
            case REPEAT, REPEAT1 -> {
                ring(cx - h * 0.8f, cy - h * 0.5f, h * 1.6f, h * 1.0f, h * 0.45f, lw, c);
                tri3(cx + h * 0.35f, cy - h * 0.95f, cx + h * 0.95f, cy - h * 0.5f, cx + h * 0.35f, cy - h * 0.05f, c);
                if (id == REPEAT1) textC("1", cx, cy + h * 0.02f, s * 0.5f, c, true);
            }
            case VOLUME, MUTE -> {
                rr(cx - h * 0.85f, cy - h * 0.3f, h * 0.5f, h * 0.6f, h * 0.1f, c);
                IX[0] = cx - h * 0.45f; IY[0] = cy - h * 0.3f; IX[1] = cx + h * 0.15f; IY[1] = cy - h * 0.8f;
                IX[2] = cx + h * 0.15f; IY[2] = cy + h * 0.8f; IX[3] = cx - h * 0.45f; IY[3] = cy + h * 0.3f;
                poly(IX, IY, 4, c);
                if (id == VOLUME) {
                    arc(cx + h * 0.1f, cy, h * 0.55f, lw, -0.8f, 0.8f, c);
                    arc(cx + h * 0.1f, cy, h * 0.95f, lw, -0.8f, 0.8f, a(c, 0.7f));
                } else {
                    line(cx + h * 0.4f, cy - h * 0.35f, cx + h * 0.95f, cy + h * 0.35f, lw, c);
                    line(cx + h * 0.4f, cy + h * 0.35f, cx + h * 0.95f, cy - h * 0.35f, lw, c);
                }
            }
            case NOTE -> {
                circle(cx - h * 0.3f, cy + h * 0.55f, h * 0.38f, c);
                line(cx + h * 0.06f, cy + h * 0.5f, cx + h * 0.06f, cy - h * 0.8f, lw, c);
                line(cx + h * 0.06f, cy - h * 0.8f, cx + h * 0.7f, cy - h * 0.4f, lw * 1.3f, c);
            }
            case SEARCH -> {
                circleRing(cx - h * 0.15f, cy - h * 0.15f, h * 0.6f, lw, c);
                line(cx + h * 0.3f, cy + h * 0.3f, cx + h * 0.85f, cy + h * 0.85f, lw * 1.2f, c);
            }
            case CLOSE -> {
                line(cx - h * 0.6f, cy - h * 0.6f, cx + h * 0.6f, cy + h * 0.6f, lw, c);
                line(cx - h * 0.6f, cy + h * 0.6f, cx + h * 0.6f, cy - h * 0.6f, lw, c);
            }
            case PLUS -> {
                line(cx - h * 0.7f, cy, cx + h * 0.7f, cy, lw, c);
                line(cx, cy - h * 0.7f, cx, cy + h * 0.7f, lw, c);
            }
            case CHECK -> {
                line(cx - h * 0.7f, cy + h * 0.05f, cx - h * 0.2f, cy + h * 0.55f, lw * 1.2f, c);
                line(cx - h * 0.2f, cy + h * 0.55f, cx + h * 0.75f, cy - h * 0.5f, lw * 1.2f, c);
            }
            case GEAR -> {
                circleRing(cx, cy, h * 0.55f, lw * 1.4f, c);
                for (int i = 0; i < 8; i++) {
                    float an = (float) (Math.PI / 4 * i), ca = (float) Math.cos(an), sa = (float) Math.sin(an);
                    line(cx + ca * h * 0.62f, cy + sa * h * 0.62f, cx + ca * h * 0.95f, cy + sa * h * 0.95f, lw * 1.25f, c);
                }
            }
            case CHEV_R -> {
                line(cx - h * 0.3f, cy - h * 0.6f, cx + h * 0.3f, cy, lw, c);
                line(cx + h * 0.3f, cy, cx - h * 0.3f, cy + h * 0.6f, lw, c);
            }
            case CHEV_L -> {
                line(cx + h * 0.3f, cy - h * 0.6f, cx - h * 0.3f, cy, lw, c);
                line(cx - h * 0.3f, cy, cx + h * 0.3f, cy + h * 0.6f, lw, c);
            }
            case CHEV_D -> {
                line(cx - h * 0.6f, cy - h * 0.3f, cx, cy + h * 0.3f, lw, c);
                line(cx, cy + h * 0.3f, cx + h * 0.6f, cy - h * 0.3f, lw, c);
            }
            case CHEV_U -> {
                line(cx - h * 0.6f, cy + h * 0.3f, cx, cy - h * 0.3f, lw, c);
                line(cx, cy - h * 0.3f, cx + h * 0.6f, cy + h * 0.3f, lw, c);
            }
            case SPARK -> {
                float[] r = {1f, 0.26f};
                for (int i = 0; i < 8; i++) {
                    float an = (float) (Math.PI / 4 * i - Math.PI / 2), rd = r[i % 2] * h;
                    IX[i] = cx + (float) Math.cos(an) * rd;
                    IY[i] = cy + (float) Math.sin(an) * rd;
                }
                poly(IX, IY, 8, c);
                circle(cx + h * 0.7f, cy - h * 0.7f, h * 0.14f, c);
            }
            case STAR -> {
                for (int i = 0; i < 10; i++) {
                    float an = (float) (Math.PI / 5 * i - Math.PI / 2), rd = (i % 2 == 0 ? 1f : 0.45f) * h;
                    IX[i] = cx + (float) Math.cos(an) * rd;
                    IY[i] = cy + (float) Math.sin(an) * rd;
                }
                poly(IX, IY, 10, c);
            }
            case BOLT -> {
                tri3(cx + h * 0.25f, cy - h, cx - h * 0.55f, cy + h * 0.15f, cx + h * 0.15f, cy + h * 0.15f, c);
                tri3(cx - h * 0.15f, cy - h * 0.15f, cx + h * 0.55f, cy - h * 0.15f, cx - h * 0.25f, cy + h, c);
            }
            case CLOUD -> {
                circle(cx - h * 0.4f, cy + h * 0.1f, h * 0.42f, c);
                circle(cx + h * 0.05f, cy - h * 0.2f, h * 0.55f, c);
                circle(cx + h * 0.5f, cy + h * 0.15f, h * 0.38f, c);
                rr(cx - h * 0.45f, cy + h * 0.1f, h * 0.95f, h * 0.45f, h * 0.2f, c);
            }
            case DROP -> {
                circle(cx, cy + h * 0.28f, h * 0.6f, c);
                tri3(cx, cy - h * 0.95f, cx - h * 0.55f, cy + h * 0.15f, cx + h * 0.55f, cy + h * 0.15f, c);
            }
            case CHIP -> {
                ring(cx - h * 0.55f, cy - h * 0.55f, h * 1.1f, h * 1.1f, h * 0.2f, lw, c);
                rr(cx - h * 0.2f, cy - h * 0.2f, h * 0.4f, h * 0.4f, h * 0.08f, c);
                for (int i = -1; i <= 1; i++) {
                    float o = i * h * 0.4f;
                    line(cx + o, cy - h * 0.62f, cx + o, cy - h * 0.95f, lw * 0.9f, c);
                    line(cx + o, cy + h * 0.62f, cx + o, cy + h * 0.95f, lw * 0.9f, c);
                    line(cx - h * 0.62f, cy + o, cx - h * 0.95f, cy + o, lw * 0.9f, c);
                    line(cx + h * 0.62f, cy + o, cx + h * 0.95f, cy + o, lw * 0.9f, c);
                }
            }
            case FRAME -> {
                ring(cx - h * 0.95f, cy - h * 0.7f, h * 1.9f, h * 1.4f, h * 0.28f, lw, c);
                rr(cx - h * 0.6f, cy - h * 0.3f, h * 0.75f, h * 0.35f, h * 0.1f, c);
                rr(cx - h * 0.6f, cy + h * 0.15f, h * 1.2f, h * 0.2f, h * 0.08f, a(c, 0.7f));
            }
            case SLIDERS -> {
                float[] yy = {-0.6f, 0f, 0.6f}, dx = {-0.35f, 0.4f, -0.1f};
                for (int i = 0; i < 3; i++) {
                    line(cx - h * 0.9f, cy + yy[i] * h, cx + h * 0.9f, cy + yy[i] * h, lw * 0.8f, a(c, 0.75f));
                    circle(cx + dx[i] * h, cy + yy[i] * h, h * 0.24f, c);
                }
            }
            case REFRESH -> {
                arc(cx, cy, h * 0.65f, lw * 1.2f, 0.3f, 5.2f, c);
                tri3(cx + h * 0.2f, cy - h * 1.0f, cx + h * 0.95f, cy - h * 0.55f, cx + h * 0.15f, cy - h * 0.2f, c);
            }
            case FOLDER -> {
                rr(cx - h * 0.9f, cy - h * 0.55f, h * 0.8f, h * 0.45f, h * 0.15f, c);
                rr(cx - h * 0.9f, cy - h * 0.3f, h * 1.8f, h * 1.0f, h * 0.2f, c);
            }
            case USER -> {
                circle(cx, cy - h * 0.35f, h * 0.42f, c);
                rr(cx - h * 0.8f, cy + h * 0.2f, h * 1.6f, h * 0.7f, h * 0.35f, c);
            }
            case KEY -> {
                circleRing(cx - h * 0.4f, cy, h * 0.4f, lw, c);
                line(cx - h * 0.05f, cy, cx + h * 0.9f, cy, lw, c);
                line(cx + h * 0.6f, cy, cx + h * 0.6f, cy + h * 0.35f, lw, c);
            }
            default -> { }
        }
    }
}
