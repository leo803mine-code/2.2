package dev.flr.visuals;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.platform.NativeImage;
import java.io.ByteArrayInputStream;
import java.util.Base64;

/** Свой выбор серверов: карточки с иконкой, цветным MOTD, онлайном и пингом, поиск, добавление, правка, прямое подключение. */
public class ServerScreen extends Screen {
    private final Screen parent;
    private ServerList list;
    private final List<Integer> shown = new ArrayList<>();
    private final TextInput search = new TextInput(40), fName = new TextInput(40), fAddr = new TextInput(80);
    private int sel = -1, dlg; // 0 нет, 1 добавить, 2 изменить, 3 прямое, 4 удалить
    private float scroll, scrollT, openAnim, dlgAnim;
    private long last, lastClick;
    private int lastClickIdx = -1;
    private int lx, lw, top, bottom;
    private final float[] hov = new float[256];
    private int editIdx = -1;

    public ServerScreen(Screen parent) {
        super(Component.literal("Multiplayer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        list = new ServerList(Minecraft.getInstance());
        list.load();
        refreshAll(false);
    }

    private void refreshAll(boolean force) {
        for (int i = 0; i < list.size(); i++) ServerPing.ping(list.get(i).ip, force);
    }

    private void rebuild() {
        shown.clear();
        String q = search.text.toLowerCase(java.util.Locale.ROOT).trim();
        for (int i = 0; i < list.size(); i++) {
            ServerData d = list.get(i);
            if (q.isEmpty() || d.name.toLowerCase(java.util.Locale.ROOT).contains(q) || d.ip.toLowerCase(java.util.Locale.ROOT).contains(q)) shown.add(i);
        }
    }

    static void connect(Screen back, ServerData data) {
        Minecraft mc = Minecraft.getInstance();
        try {
            ServerAddress addr = ServerAddress.parseString(data.ip);
            Method best = null;
            for (Method m : ConnectScreen.class.getDeclaredMethods()) {
                if (m.getName().equals("startConnecting") && Modifier.isStatic(m.getModifiers())
                        && (best == null || m.getParameterCount() > best.getParameterCount())) best = m;
            }
            if (best == null) return;
            Class<?>[] pt = best.getParameterTypes();
            Object[] args = new Object[pt.length];
            args[0] = back;
            args[1] = mc;
            args[2] = addr;
            args[3] = data;
            for (int i = 4; i < pt.length; i++) args[i] = pt[i] == boolean.class ? Boolean.FALSE : null;
            best.setAccessible(true);
            best.invoke(null, args);
        } catch (Exception e) {
            Notify.show("Cannot connect: " + e.getClass().getSimpleName(), 0xFF5C5C);
        }
    }

    private void join() {
        if (sel < 0 || sel >= list.size()) return;
        list.save();
        connect(this, list.get(sel));
    }

    // ------------------------------------------------------------ рендер
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return dlg == 0;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openAnim += (1f - openAnim) * Gfx.k(dt, 9f);
        dlgAnim += ((dlg != 0 ? 1f : 0f) - dlgAnim) * Gfx.k(dt, 14f);
        rebuild();
        int acc = Config.color() & 0xFFFFFF;
        Backdrop.draw(g, width, height);
        Gfx.use(g);
        float e = Gfx.ease(openAnim);

        // шапка
        boolean bh = dlg == 0 && Ui.in(mx, my, 16, 14, 26, 26);
        Gfx.circle(29, 27, 13, bh ? 0x40FFFFFF : 0x22FFFFFF);
        Gfx.icon(Gfx.CHEV_L, 28, 27, 13, 0xFFFFFFFF);
        Gfx.text(Tr.tr("Multiplayer"), 52, 11, 17f, Gfx.rgba(0xFFFFFF, e), true);
        int online = 0;
        for (int i = 0; i < list.size(); i++) {
            ServerPing.Info in = ServerPing.get(list.get(i).ip);
            if (in != null && in.state == 1) online++;
        }
        Gfx.text(Tr.fmt("%s servers · %s online", list.size(), online), 53, 30, Ui.BODY - 0.6f, 0x99FFFFFF, false);

        lw = Math.min(width - 32, 560);
        lx = (width - lw) / 2;
        float sw = 150;
        float sx = lx + lw - sw - 92;
        top = 56;
        bottom = height - 54;
        search.draw(Math.max(sx, 200), 16, sw, 22, Tr.tr("Search..."), acc);
        iconBtn(mx, my, lx + lw - 84, 16, Gfx.REFRESH, acc);
        iconBtn(mx, my, lx + lw - 56, 16, Gfx.PLUS, acc);
        iconBtn(mx, my, lx + lw - 28, 16, Gfx.KEY, acc);

        // список
        int cardH = 60, gap = 8;
        float total = shown.size() * (cardH + gap);
        float maxS = Math.max(0, total - (bottom - top));
        scrollT = Math.max(0, Math.min(maxS, scrollT));
        scroll += (scrollT - scroll) * Gfx.k(dt, 14f);
        Gfx.scissor(0, top - 4, width, bottom - top + 8);
        int y0 = top - Math.round(scroll);
        for (int n = 0; n < shown.size(); n++) {
            int idx = shown.get(n);
            float yy = y0 + n * (cardH + gap);
            if (yy + cardH < top - 4 || yy > bottom + 4) continue;
            float a = Gfx.ease(openAnim * 1.6f - n * 0.07f);
            float off = (1f - a) * 14f;
            card(g, idx, n, lx, yy + off, lw, cardH, a, dt, mx, my, acc);
        }
        Gfx.unscissor();
        Gfx.use(g);
        if (shown.isEmpty()) {
            Gfx.textC(Tr.tr(list.size() == 0 ? "No servers yet. Press + to add one." : "Nothing found"), width / 2f, height / 2f, 11f, 0x99FFFFFF, false);
        }
        if (maxS > 0) {
            float th = bottom - top, bh2 = Math.max(24, th * th / total), by = top + (th - bh2) * (scroll / maxS);
            Gfx.rr(lx + lw + 6, by, 3, bh2, 1.5f, 0x44FFFFFF);
        }

        // нижняя панель
        boolean has = sel >= 0 && sel < list.size();
        int by = height - 42, bw = 96, gx = width / 2 - (bw * 3 + 24) / 2;
        Ui.pill(g, gx, by, bw, 24, Tr.tr("Join"), has && dlg == 0 && Ui.in(mx, my, gx, by, bw, 24), true, acc);
        Ui.pill(g, gx + bw + 12, by, bw, 24, Tr.tr("Edit"), has && dlg == 0 && Ui.in(mx, my, gx + bw + 12, by, bw, 24), false, acc);
        Ui.pill(g, gx + (bw + 12) * 2, by, bw, 24, Tr.tr("Delete"), has && dlg == 0 && Ui.in(mx, my, gx + (bw + 12) * 2, by, bw, 24), false, 0xFF5C6C);
        Gfx.use(g);
        if (!has) Gfx.rr(gx - 2, by - 2, bw * 3 + 28, 28, 14, 0x66050309);
        Gfx.textC(Tr.tr("Double-click to join  ·  Esc to go back"), width / 2f, height - 12, Ui.BODY - 0.8f, 0x66FFFFFF, false);

        if (dlgAnim > 0.01f) dialog(g, mx, my, acc);
        Gfx.end();
    }

    private void iconBtn(int mx, int my, float x, float y, int icon, int acc) {
        boolean h = dlg == 0 && Ui.in(mx, my, x, y, 22, 22);
        Gfx.rr(x, y, 22, 22, 11, h ? 0x40FFFFFF : 0x22FFFFFF);
        if (h) Gfx.ring(x, y, 22, 22, 11, 1f, Gfx.rgba(acc, 0.8f));
        Gfx.icon(icon, x + 11, y + 11, 11, 0xFFFFFFFF);
    }

    private void ensureTex(ServerPing.Info in, String ip) {
        if (in.texTried || in.favicon == null) return;
        in.texTried = true;
        try {
            String f = in.favicon;
            int c = f.indexOf("base64,");
            if (c < 0) return;
            byte[] b = Base64.getMimeDecoder().decode(f.substring(c + 7));
            NativeImage img = NativeImage.read(new ByteArrayInputStream(b));
            ResourceLocation rl = ResourceLocation.fromNamespaceAndPath("flrvisuals", "srv/" + Integer.toHexString(ip.hashCode()) + Long.toHexString(System.nanoTime()));
            Minecraft.getInstance().getTextureManager().register(rl, new DynamicTexture(img));
            in.tex = rl;
        } catch (Exception ignored) {
        }
    }

    private void card(GuiGraphics g, int idx, int n, float x, float y, float w, float h, float a, float dt, int mx, int my, int acc) {
        ServerData d = list.get(idx);
        ServerPing.Info in = ServerPing.get(d.ip);
        boolean selc = idx == sel, hv = dlg == 0 && Ui.in(mx, my, x, y, w, h) && my >= top && my < bottom;
        int hi = n % hov.length;
        hov[hi] += ((hv || selc ? 1f : 0f) - hov[hi]) * Gfx.k(dt, 14f);
        float hh = hov[hi];
        if (selc) Gfx.glow(x, y, w, h, 14, 14, Gfx.rgba(acc, 0.16f * a));
        Gfx.glow(x, y + 3, w, h, 14, 9, Gfx.rgba(0x000000, 0.28f * a));
        Gfx.rr4(x, y, w, h, 14, Gfx.rgba(0xFFFFFF, (0.10f + 0.05f * hh) * a), Gfx.rgba(0xFFFFFF, (0.06f + 0.03f * hh) * a),
                Gfx.rgba(0xFFFFFF, (0.05f + 0.03f * hh) * a), Gfx.rgba(0xFFFFFF, (0.03f + 0.02f * hh) * a));
        Gfx.ring(x, y, w, h, 14, 1f, selc ? Gfx.rgba(acc, 0.85f * a) : Gfx.rgba(0xFFFFFF, (0.12f + 0.1f * hh) * a));
        if (selc) Gfx.rr(x + 6, y + 14, 3, h - 28, 1.5f, Gfx.rgba(acc, a));

        // иконка
        float ix = x + 14, iy = y + 9, is = 42;
        if (in != null && in.state == 1) ensureTex(in, d.ip);
        if (in != null && in.tex != null) {
            Gfx.glow(ix, iy, is, is, 9, 6, Gfx.rgba(0x000000, 0.4f * a));
            Gfx.flush();
            // скруглённая иконка: текстура поверх подложки
            Gfx.rr(ix, iy, is, is, 9, Gfx.rgba(0x000000, a));
            Gfx.tex(in.tex, ix, iy, is, is, 0, 0, 1, 1, Gfx.rgba(0xFFFFFF, a));
            Gfx.ring(ix, iy, is, is, 9, 1f, Gfx.rgba(0xFFFFFF, 0.18f * a));
        } else {
            float hue = (Math.abs(d.name.hashCode()) % 360) / 360f;
            Gfx.rr4(ix, iy, is, is, 10, Gfx.a(Gfx.hsb(hue, 0.55f, 0.95f), a), Gfx.a(Gfx.hsb(hue + 0.08f, 0.6f, 0.75f), a),
                    Gfx.a(Gfx.hsb(hue - 0.05f, 0.7f, 0.6f), a), Gfx.a(Gfx.hsb(hue + 0.12f, 0.6f, 0.45f), a));
            String ch = d.name.isEmpty() ? "?" : d.name.substring(0, 1).toUpperCase();
            Gfx.textC(ch, ix + is / 2f, iy + is / 2f, 20f, Gfx.rgba(0xFFFFFF, a), true);
        }

        // текст
        float tx = x + 66, right = x + w - 14;
        Gfx.text(Gfx.fit(d.name, w - 66 - 130, 11f, true), tx, y + 8, 11f, Gfx.rgba(0xFFFFFF, a), true);
        boolean ok = in != null && in.state == 1;
        if (in == null || in.state == 0) {
            float sh = (System.currentTimeMillis() % 1400) / 1400f;
            for (int l = 0; l < 2; l++) {
                float bw = (l == 0 ? 0.55f : 0.35f) * (w - 190);
                Gfx.rr(tx, y + 27 + l * 12, bw, 7, 3.5f, Gfx.rgba(0xFFFFFF, (0.07f + 0.05f * Math.abs(Mth(sh * 6.28f + l))) * a));
            }
        } else if (ok) {
            for (int l = 0; l < Math.min(2, in.motd.size()); l++) {
                float px = tx;
                for (ServerPing.Seg s : in.motd.get(l)) {
                    int col = lum(s.color) < 0.28f ? Gfx.mix(0xFF000000 | s.color, 0xFFFFFFFF, 0.55f) : 0xFF000000 | s.color;
                    String t = s.text;
                    float room = w - 66 - 140 - (px - tx);
                    if (room <= 4) break;
                    t = Gfx.fit(t, room, Ui.BODY - 0.4f, s.bold);
                    Gfx.text(t, px, y + 26 + l * 11.5f, Ui.BODY - 0.4f, Gfx.a(col, a * 0.95f), s.bold);
                    px += Gfx.textW(t, Ui.BODY - 0.4f, s.bold);
                }
            }
        } else {
            Gfx.text(Tr.tr("Can't connect to server"), tx, y + 27, Ui.BODY, Gfx.rgba(0xFF6B6B, a), false);
            Gfx.text(Gfx.fit(d.ip, w - 190, Ui.BODY - 0.6f, false), tx, y + 39, Ui.BODY - 0.6f, Gfx.rgba(0xFFFFFF, 0.45f * a), false);
        }

        // правая колонка: игроки и пинг
        if (ok) {
            String pl = in.online >= 0 ? in.online + "/" + in.max : "?";
            Gfx.rr(right - Gfx.textW(pl, Ui.BODY, true) - 22, y + 9, Gfx.textW(pl, Ui.BODY, true) + 22, 16, 8, Gfx.rgba(0xFFFFFF, 0.1f * a));
            Gfx.circle(right - Gfx.textW(pl, Ui.BODY, true) - 11, y + 17, 2.6f, Gfx.rgba(0x4CE08A, a));
            Gfx.textR(pl, right - 6, y + 17, Ui.BODY, Gfx.rgba(0xFFFFFF, a), true);
            int bars = in.ms < 0 ? 2 : in.ms < 60 ? 4 : in.ms < 120 ? 3 : in.ms < 260 ? 2 : 1;
            int bc = bars >= 3 ? 0xFF4CE08A : bars == 2 ? 0xFFFFC94D : 0xFFFF6B6B;
            for (int b = 0; b < 4; b++) {
                float bh = 4 + b * 3;
                Gfx.rr(right - 52 + b * 5, y + h - 14 - bh + 4, 3.2f, bh, 1.4f, Gfx.a(b < bars ? bc : 0x40FFFFFF, a));
            }
            Gfx.textR(in.ms >= 0 ? in.ms + " ms" : "-- ms", right - 58, y + h - 14, Ui.BODY - 0.6f, Gfx.rgba(0xFFFFFF, 0.7f * a), false);
            if (!in.version.isEmpty()) Gfx.textR(Gfx.fit(in.version, 120, Ui.BODY - 1.2f, false), right, y + h - 28 + 0, Ui.BODY - 1.2f, Gfx.rgba(0xFFFFFF, 0.0f), false);
        } else if (in != null && in.state == 2) {
            Gfx.rr(right - 52, y + 9, 52, 16, 8, Gfx.rgba(0xFF6B6B, 0.18f * a));
            Gfx.textC("OFFLINE", right - 26, y + 17, Ui.BODY - 1.4f, Gfx.rgba(0xFF8A8A, a), true);
        }
    }

    private static float Mth(float v) {
        return (float) Math.sin(v);
    }

    private static float lum(int rgb) {
        return (0.299f * (rgb >> 16 & 255) + 0.587f * (rgb >> 8 & 255) + 0.114f * (rgb & 255)) / 255f;
    }

    // ------------------------------------------------------------ диалоги
    private void dialog(GuiGraphics g, int mx, int my, int acc) {
        float a = Gfx.ease(dlgAnim);
        Gfx.rect(0, 0, width, height, Gfx.rgba(0x03020A, 0.6f * a));
        float w = 320, h = dlg == 4 ? 118 : dlg == 3 ? 134 : 178;
        float x = (width - w) / 2f, y = (height - h) / 2f + (1f - a) * 12;
        Gfx.glow(x, y + 6, w, h, 18, 24, Gfx.rgba(0x000000, 0.55f * a));
        Gfx.rr4(x, y, w, h, 18, Gfx.rgba(0x1E1832, 0.97f * a), Gfx.rgba(0x16122A, 0.97f * a), Gfx.rgba(0x120F22, 0.97f * a), Gfx.rgba(0x0E0B1C, 0.97f * a));
        Gfx.ring(x, y, w, h, 18, 1f, Gfx.rgba(0xFFFFFF, 0.14f * a));
        String title = dlg == 1 ? "Add server" : dlg == 2 ? "Edit server" : dlg == 3 ? "Direct connection" : "Delete server?";
        Gfx.text(Tr.tr(title), x + 20, y + 16, 14f, Gfx.rgba(0xFFFFFF, a), true);
        float fy = y + 46;
        if (dlg == 4) {
            String nm = sel >= 0 && sel < list.size() ? list.get(sel).name : "";
            Gfx.text(Gfx.fit(Tr.fmt("'%s' will be removed from the list.", nm), w - 40, Ui.BODY, false), x + 20, y + 46, Ui.BODY, Gfx.rgba(0xFFFFFF, 0.75f * a), false);
        } else {
            if (dlg != 3) {
                Gfx.text(Tr.tr("Name"), x + 20, fy - 2, Ui.BODY - 1f, Gfx.rgba(0xFFFFFF, 0.55f * a), false);
                fName.draw(x + 20, fy + 12, w - 40, 24, Tr.tr("Server name"), acc);
                fy += 52;
            }
            Gfx.text(Tr.tr("Address"), x + 20, fy - 2, Ui.BODY - 1f, Gfx.rgba(0xFFFFFF, 0.55f * a), false);
            fAddr.draw(x + 20, fy + 12, w - 40, 24, "play.example.net", acc);
        }
        int by = (int) (y + h - 40);
        String ok = dlg == 4 ? "Delete" : dlg == 3 ? "Connect" : "Save";
        Ui.pill(g, (int) (x + w - 20 - 100), by, 100, 24, Tr.tr(ok), Ui.in(mx, my, x + w - 120, by, 100, 24), true, acc);
        Ui.pill(g, (int) (x + w - 20 - 100 - 108), by, 100, 24, Tr.tr("Cancel"), Ui.in(mx, my, x + w - 228, by, 100, 24), false, acc);
        Gfx.use(g);
    }

    private void openDlg(int mode) {
        dlg = mode;
        search.focus = false;
        fName.focus = mode == 1 || mode == 2;
        fAddr.focus = mode == 3 || (mode != 1 && mode != 2 && mode != 4 ? true : false);
        if (mode == 1) {
            fName.set("");
            fAddr.set("");
            fName.focus = true;
            fAddr.focus = false;
        } else if (mode == 2 && sel >= 0 && sel < list.size()) {
            fName.set(list.get(sel).name);
            fAddr.set(list.get(sel).ip);
            editIdx = sel;
        } else if (mode == 3) {
            fAddr.set("");
            fAddr.focus = true;
            fName.focus = false;
        }
    }

    private void confirm() {
        if (dlg == 1) {
            String a = fAddr.text.trim();
            if (a.isEmpty()) return;
            String n = fName.text.trim().isEmpty() ? a : fName.text.trim();
            list.add(new ServerData(n, a, ServerData.Type.OTHER), false);
            list.save();
            ServerPing.ping(a, true);
            sel = list.size() - 1;
        } else if (dlg == 2 && editIdx >= 0 && editIdx < list.size()) {
            ServerData d = list.get(editIdx);
            d.name = fName.text.trim().isEmpty() ? fAddr.text.trim() : fName.text.trim();
            d.ip = fAddr.text.trim();
            list.save();
            ServerPing.ping(d.ip, true);
        } else if (dlg == 3) {
            String a = fAddr.text.trim();
            if (a.isEmpty()) return;
            dlg = 0;
            connect(this, new ServerData("Direct", a, ServerData.Type.OTHER));
            return;
        } else if (dlg == 4 && sel >= 0 && sel < list.size()) {
            list.remove(list.get(sel));
            list.save();
            sel = -1;
        }
        dlg = 0;
    }

    // ------------------------------------------------------------ ввод
    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (dlg != 0) {
            float w = 320, h = dlg == 4 ? 118 : dlg == 3 ? 134 : 178;
            float x = (width - w) / 2f, y = (height - h) / 2f;
            int by = (int) (y + h - 40);
            if (Ui.in(mx, my, x + w - 120, by, 100, 24)) confirm();
            else if (Ui.in(mx, my, x + w - 228, by, 100, 24)) dlg = 0;
            else if (dlg != 4) {
                float fy = y + 46;
                if (dlg != 3) {
                    fName.focus = Ui.in(mx, my, x + 20, fy + 12, w - 40, 24);
                    fy += 52;
                } else fName.focus = false;
                fAddr.focus = Ui.in(mx, my, x + 20, fy + 12, w - 40, 24);
            }
            return true;
        }
        search.focus = Ui.in(mx, my, Math.max(lx + lw - 150 - 92, 200), 16, 150, 22);
        if (Ui.in(mx, my, 16, 14, 26, 26)) { onClose(); return true; }
        if (Ui.in(mx, my, lx + lw - 84, 16, 22, 22)) { list.load(); refreshAll(true); return true; }
        if (Ui.in(mx, my, lx + lw - 56, 16, 22, 22)) { openDlg(1); return true; }
        if (Ui.in(mx, my, lx + lw - 28, 16, 22, 22)) { openDlg(3); return true; }
        int bw = 96, gx = width / 2 - (bw * 3 + 24) / 2, by = height - 42;
        boolean has = sel >= 0 && sel < list.size();
        if (has && Ui.in(mx, my, gx, by, bw, 24)) { join(); return true; }
        if (has && Ui.in(mx, my, gx + bw + 12, by, bw, 24)) { openDlg(2); return true; }
        if (has && Ui.in(mx, my, gx + (bw + 12) * 2, by, bw, 24)) { openDlg(4); return true; }
        if (my >= top && my < bottom) {
            int y0 = top - Math.round(scroll);
            for (int n = 0; n < shown.size(); n++) {
                float yy = y0 + n * 68;
                if (Ui.in(mx, my, lx, yy, lw, 60)) {
                    int idx = shown.get(n);
                    long now = System.currentTimeMillis();
                    if (idx == lastClickIdx && now - lastClick < 400) {
                        sel = idx;
                        join();
                    } else if (btn == 1) {
                        sel = idx;
                        openDlg(2);
                    }
                    sel = idx;
                    lastClickIdx = idx;
                    lastClick = now;
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scrollT -= (float) (sy * 40);
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (dlg != 0) {
            if (fName.charTyped(c)) return true;
            return fAddr.charTyped(c);
        }
        return search.charTyped(c) || super.charTyped(c, mods);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (dlg != 0) {
            if (key == 256) { dlg = 0; return true; }
            if (key == 257 || key == 335) { confirm(); return true; }
            if (key == 258 && dlg != 3 && dlg != 4) {
                boolean f = fName.focus;
                fName.focus = !f;
                fAddr.focus = f;
                return true;
            }
            if (fName.key(key, mods)) return true;
            return fAddr.key(key, mods) || true;
        }
        if (search.focus && search.key(key, mods)) return true;
        if (key == 264 || key == 265) {
            if (!shown.isEmpty()) {
                int pos = shown.indexOf(sel);
                pos = Math.floorMod(pos + (key == 264 ? 1 : -1), shown.size());
                if (sel < 0) pos = 0;
                sel = shown.get(pos);
            }
            return true;
        }
        if ((key == 257 || key == 335) && sel >= 0) { join(); return true; }
        if (key == 261 && sel >= 0) { openDlg(4); return true; }
        if (key == 294) { refreshAll(true); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
