package dev.flr.visuals;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Интерфейс медиаплеера: полный (вкладка Media), компактная карточка (главное меню) и мини-виджет HUD. */
final class MediaUi {
    private static final int PLAY = 1, PREV = 2, NEXT = 3, SHUF = 4, REP = 5, SEEK = 6, VOL = 7, FOLDER = 8, RESCAN = 9, ROW = 100;
    private static final List<float[]> HITS = new ArrayList<>();
    private static int drag;
    private static float seekX, seekW, volX, volW, listScroll, listScrollT, listTop, listBot;

    private MediaUi() {}

    private static void hit(int id, float x, float y, float w, float h) {
        HITS.add(new float[]{id, x, y, w, h});
    }

    private static int accent() {
        return Config.color() | 0xFF000000;
    }

    static void cover(float x, float y, float s, MediaPlayer.Track t, boolean play, float time) {
        float hue = t == null ? 0.7f : t.hue;
        int c1 = Gfx.hsb(hue, 0.6f, 0.95f), c2 = Gfx.hsb(hue + 0.12f, 0.7f, 0.55f), c3 = Gfx.hsb(hue - 0.1f, 0.8f, 0.35f);
        Gfx.glow(x, y + 3, s, s, s * 0.14f, 10, Gfx.a(c1, 0.35f));
        Gfx.rr4(x, y, s, s, s * 0.14f, c1, c2, c2, c3);
        float cx = x + s / 2f, cy = y + s / 2f;
        Gfx.orb(x + s * 0.25f, y + s * 0.2f, s * 0.55f, 0x40FFFFFF);
        float rot = play ? time * 1.2f : 0.6f;
        for (int i = 0; i < 3; i++) Gfx.circleRing(cx, cy, s * (0.2f + i * 0.1f), 0.8f, 0x22FFFFFF);
        Gfx.arc(cx, cy, s * 0.3f, 1.2f, rot, rot + 1.1f, 0x55FFFFFF);
        Gfx.circle(cx, cy, s * 0.13f, 0x55000000);
        Gfx.icon(Gfx.NOTE, cx, cy, s * 0.17f, 0xFFFFFFFF);
        Gfx.ring(x, y, s, s, s * 0.14f, 1f, 0x33FFFFFF);
    }

    private static void bar(float x, float y, float w, float h, float f, int acc, boolean knob) {
        Gfx.rr(x, y, w, h, h / 2f, 0x30FFFFFF);
        float fw = Math.max(h, w * Gfx.clamp01(f));
        Gfx.rrH(x, y, fw, h, h / 2f, Gfx.a(acc, 0.55f), acc);
        if (knob) {
            Gfx.glow(x + fw - 5, y + h / 2f - 5, 10, 10, 5, 6, Gfx.a(acc, 0.5f));
            Gfx.circle(x + fw, y + h / 2f, h * 0.9f + 1.5f, 0xFFFFFFFF);
        }
    }

    private static String ttl(MediaPlayer.Track t) {
        if (MediaPlayer.loading) return Tr.tr("Loading...");
        return t == null ? Tr.tr("Nothing playing") : t.title;
    }

    private static String art(MediaPlayer.Track t) {
        if (!MediaPlayer.error.isEmpty()) return MediaPlayer.error;
        if (t == null) return Tr.tr("Pick a track");
        return t.artist.isEmpty() ? Tr.tr("Unknown artist") : t.artist;
    }

    // ------------------------------------------------------------------ компактная карточка
    static void compact(GuiGraphics g, float x, float y, float w, float h, int mx, int my, float dt) {
        Gfx.use(g);
        HITS.clear();
        MediaPlayer.init();
        int acc = accent();
        MediaPlayer.Track t = MediaPlayer.current();
        float time = Backdrop.time();
        Gfx.glow(x, y + 3, w, h, 16, 12, 0x40000000);
        Gfx.rr4(x, y, w, h, 16, 0x30FFFFFF, 0x1CFFFFFF, 0x16FFFFFF, 0x0CFFFFFF);
        Gfx.ring(x, y, w, h, 16, 1f, 0x30FFFFFF);
        float cs = h - 16;
        cover(x + 8, y + 8, cs, t, MediaPlayer.playing, time);
        float tx = x + cs + 18, bw = w - cs - 26;
        Gfx.text(Gfx.fit(ttl(t), bw, 10.5f, true), tx, y + 9, 10.5f, 0xFFFFFFFF, true);
        Gfx.text(Gfx.fit(art(t), bw, Ui.BODY - 1f, false), tx, y + 22, Ui.BODY - 1f, 0x99FFFFFF, false);
        float by = y + h - 17;
        float cx = tx + 10;
        float[] off = {0, 22, 44};
        int[] ic = {Gfx.PREV, MediaPlayer.playing ? Gfx.PAUSE : Gfx.PLAY, Gfx.NEXT};
        int[] id = {PREV, PLAY, NEXT};
        for (int i = 0; i < 3; i++) {
            float bx = cx + off[i];
            boolean hv = Ui.in(mx, my, bx - 10, by - 8, 20, 16);
            if (i == 1) Gfx.circle(bx, by, 9.5f, hv ? 0xFFFFFFFF : 0xFFE6E8F4);
            else if (hv) Gfx.circle(bx, by, 9, 0x33FFFFFF);
            Gfx.icon(ic[i], bx, by, i == 1 ? 10 : 11, i == 1 ? 0xFF10121C : 0xFFFFFFFF);
            hit(id[i], bx - 10, by - 10, 20, 20);
        }
        float px = cx + 62, pw = x + w - 12 - px;
        if (pw > 20) {
            bar(px, by - 1.5f, pw, 3f, MediaPlayer.progress(), acc, false);
            hit(SEEK, px, by - 6, pw, 12);
            seekX = px;
            seekW = pw;
        }
    }

    // ------------------------------------------------------------------ мини-виджет HUD
    static void hud(GuiGraphics g, float x, float y, float w, float h) {
        Gfx.use(g);
        MediaPlayer.init();
        MediaPlayer.Track t = MediaPlayer.current();
        int acc = accent();
        Gfx.rr(x, y, w, h, 14, Gfx.rgba(0x0E1019, (float) Config.hudAlpha * 0.92f));
        Gfx.ring(x, y, w, h, 14, 1f, Gfx.a(acc, 0.35f));
        cover(x + 6, y + 6, h - 12, t, MediaPlayer.playing, Backdrop.time());
        float tx = x + h + 2, bw = w - h - 10;
        Gfx.text(Gfx.fit(ttl(t), bw, 9.6f, true), tx, y + 7, 9.6f, 0xFFFFFFFF, true);
        Gfx.text(Gfx.fit(art(t), bw, Ui.BODY - 1.2f, false), tx, y + 19, Ui.BODY - 1.2f, 0x99FFFFFF, false);
        bar(tx, y + h - 11, bw, 2.6f, MediaPlayer.progress(), acc, false);
    }

    // ------------------------------------------------------------------ полный плеер
    static void full(GuiGraphics g, float x, float y, float w, float h, int mx, int my, float dt) {
        Gfx.use(g);
        HITS.clear();
        MediaPlayer.init();
        int acc = accent();
        MediaPlayer.Track t = MediaPlayer.current();
        float time = Backdrop.time();
        float tb = Math.min(128, h * 0.52f);
        cover(x, y, tb, t, MediaPlayer.playing, time);
        float tx = x + tb + 16, tw = w - tb - 16;

        Gfx.text(Gfx.fit(ttl(t), tw, 16f, true), tx, y - 1, 16f, 0xFFFFFFFF, true);
        Gfx.text(Gfx.fit(art(t), tw, Ui.BODY + 0.4f, false), tx, y + 19, Ui.BODY + 0.4f, Gfx.a(acc, 0.95f), false);

        // визуализатор или текст песни
        float vy = y + 36, vh = tb - 36 - 44;
        int li = MediaPlayer.lyricIndex();
        if (t != null && !t.lrcText.isEmpty() && vh > 28) {
            for (int d = -1; d <= 1; d++) {
                int i = li + d;
                String s = i >= 0 && i < t.lrcText.size() ? t.lrcText.get(i) : "";
                if (s.isEmpty() && d == 0) s = "♪";
                Gfx.text(Gfx.fit(s, tw, d == 0 ? 11f : 9f, d == 0), tx, vy + (d + 1) * (vh / 3f) - 2, d == 0 ? 11f : 9f,
                        d == 0 ? 0xFFFFFFFF : 0x66FFFFFF, d == 0);
            }
        } else {
            float[] sp = MediaPlayer.spectrum(dt);
            int n = sp.length;
            float bw = (tw - (n - 1) * 2.5f) / n;
            for (int i = 0; i < n; i++) {
                float bh = Math.max(2.5f, sp[i] * vh);
                float bx = tx + i * (bw + 2.5f);
                Gfx.rrV(bx, vy + vh - bh, bw, bh, Math.min(bw / 2f, 2f), Gfx.a(Gfx.shift(acc, i / (float) n * 0.15f, 0f, 0f), 0.95f), Gfx.a(acc, 0.35f));
            }
        }

        // перемотка
        float sy = y + tb - 40;
        float len = MediaPlayer.lengthSec(), pos = MediaPlayer.positionSec();
        bar(tx + 28, sy + 4, tw - 56, 4f, MediaPlayer.progress(), acc, true);
        Gfx.textMid(MediaPlayer.time(pos), tx, sy + 6, Ui.BODY - 1f, 0xAAFFFFFF, false);
        Gfx.textR(MediaPlayer.time(len), tx + tw, sy + 6, Ui.BODY - 1f, 0xAAFFFFFF, false);
        hit(SEEK, tx + 28, sy - 2, tw - 56, 16);
        seekX = tx + 28;
        seekW = tw - 56;

        // кнопки
        float cy = y + tb - 14, cx = tx + Math.min(110, tw * 0.32f);
        ctl(mx, my, cx - 66, cy, Gfx.SHUFFLE, SHUF, Config.mediaShuffle, acc, false);
        ctl(mx, my, cx - 33, cy, Gfx.PREV, PREV, false, acc, false);
        ctl(mx, my, cx, cy, MediaPlayer.playing ? Gfx.PAUSE : Gfx.PLAY, PLAY, false, acc, true);
        ctl(mx, my, cx + 33, cy, Gfx.NEXT, NEXT, false, acc, false);
        ctl(mx, my, cx + 66, cy, Config.mediaRepeat == 2 ? Gfx.REPEAT1 : Gfx.REPEAT, REP, Config.mediaRepeat > 0, acc, false);

        float vx = tx + tw - 96;
        if (vx > cx + 90) {
            Gfx.icon(Config.mediaVolume <= 0.01 ? Gfx.MUTE : Gfx.VOLUME, vx - 12, cy, 12, 0xCCFFFFFF);
            bar(vx + 4, cy - 1.5f, 80, 3f, (float) Config.mediaVolume, acc, true);
            hit(VOL, vx, cy - 8, 88, 16);
            volX = vx + 4;
            volW = 80;
        }

        // плейлист
        float ly = y + tb + 14;
        Gfx.text(Tr.tr("Playlist"), x, ly, 10.5f, 0xFFFFFFFF, true);
        String info = MediaPlayer.LIST.size() + (MediaPlayer.skippedMp3 > 0 ? "  ·  " + Tr.fmt("%s unsupported (mp3, flac)", MediaPlayer.skippedMp3) : "");
        Gfx.textMid(info, x + Gfx.textW(Tr.tr("Playlist"), 10.5f, true) + 10, ly + 5, Ui.BODY - 1.2f, 0x66FFFFFF, false);
        float bx = x + w - 150;
        pillBtn(mx, my, bx, ly - 3, 72, 17, Tr.tr("Folder"), FOLDER, acc);
        pillBtn(mx, my, bx + 78, ly - 3, 72, 17, Tr.tr("Rescan"), RESCAN, acc);

        listTop = ly + 20;
        listBot = y + h;
        int n = MediaPlayer.LIST.size();
        float rh = 22;
        float tot = n * rh, view = listBot - listTop, maxS = Math.max(0, tot - view);
        listScrollT = Gfx.clamp(listScrollT, 0, maxS);
        listScroll += (listScrollT - listScroll) * Gfx.k(dt, 14f);
        if (n == 0) {
            Gfx.text(Tr.tr("Put .ogg or .wav files into the folder to play them."), x, listTop + 4, Ui.BODY, 0x88FFFFFF, false);
        }
        Gfx.scissor(x - 4, listTop, w + 8, Math.max(0, view));
        for (int i = 0; i < n; i++) {
            float ry = listTop + i * rh - listScroll;
            if (ry + rh < listTop || ry > listBot) continue;
            MediaPlayer.Track tr = MediaPlayer.LIST.get(i);
            boolean cur = i == MediaPlayer.index, hv = Ui.in(mx, my, x, ry, w, rh - 2) && my >= listTop && my < listBot;
            if (cur) {
                Gfx.rrH(x, ry, w, rh - 3, 9, Gfx.a(acc, 0.28f), Gfx.a(acc, 0.06f));
                Gfx.rr(x + 3, ry + 5, 2.4f, rh - 13, 1.2f, acc);
            } else if (hv) Gfx.rr(x, ry, w, rh - 3, 9, 0x16FFFFFF);
            if (cur && MediaPlayer.playing) {
                float[] sp = MediaPlayer.spectrum(0f);
                for (int b = 0; b < 3; b++) {
                    float bh = 3 + sp[b * 4 + 2] * 8;
                    Gfx.rr(x + 11 + b * 3.6f, ry + (rh - 3) / 2f + 4 - bh, 2.4f, bh, 1.2f, acc);
                }
            } else {
                Gfx.textMid(String.valueOf(i + 1), x + 16, ry + (rh - 3) / 2f, Ui.BODY - 0.6f, cur ? acc : 0x66FFFFFF, false);
            }
            Gfx.textMid(Gfx.fit(tr.title, w * 0.55f, Ui.BODY, cur), x + 30, ry + (rh - 3) / 2f, Ui.BODY, cur ? 0xFFFFFFFF : 0xFFD6D9EA, cur);
            Gfx.textR(Gfx.fit(tr.artist.isEmpty() ? (tr.builtin ? "FLR" : "") : tr.artist, w * 0.28f, Ui.BODY - 0.6f, false), x + w - 10, ry + (rh - 3) / 2f, Ui.BODY - 0.6f, 0x77FFFFFF, false);
            hit(ROW + i, x, Math.max(ry, listTop), w, Math.min(rh - 2, listBot - Math.max(ry, listTop)));
        }
        Gfx.unscissor();
        Gfx.use(g);
        if (maxS > 0) Gfx.rr(x + w + 4, listTop + (view - 20) * (listScroll / maxS), 2.5f, 20, 1.2f, 0x44FFFFFF);
    }

    private static void ctl(int mx, int my, float cx, float cy, int icon, int id, boolean on, int acc, boolean big) {
        float r = big ? 15 : 12;
        boolean hv = Ui.in(mx, my, cx - r, cy - r, r * 2, r * 2);
        if (big) {
            Gfx.glow(cx - r, cy - r, r * 2, r * 2, r, 9, Gfx.a(acc, hv ? 0.5f : 0.3f));
            Gfx.circle(cx, cy, r, hv ? 0xFFFFFFFF : 0xFFE8EAF6);
            Gfx.icon(icon, cx + (icon == Gfx.PLAY ? 1 : 0), cy, 13, 0xFF10121C);
        } else {
            if (hv) Gfx.circle(cx, cy, r, 0x30FFFFFF);
            Gfx.icon(icon, cx, cy, 12, on ? acc : 0xE6FFFFFF);
            if (on) Gfx.circle(cx, cy + 10, 1.4f, acc);
        }
        hit(id, cx - r, cy - r, r * 2, r * 2);
    }

    private static void pillBtn(int mx, int my, float x, float y, float w, float h, String label, int id, int acc) {
        boolean hv = Ui.in(mx, my, x, y, w, h);
        Gfx.rr(x, y, w, h, h / 2f, hv ? 0x38FFFFFF : 0x1EFFFFFF);
        if (hv) Gfx.ring(x, y, w, h, h / 2f, 1f, Gfx.a(acc, 0.8f));
        Gfx.textC(label, x + w / 2f, y + h / 2f, Ui.BODY - 0.8f, 0xFFFFFFFF, false);
        hit(id, x, y, w, h);
    }

    // ------------------------------------------------------------------ ввод
    static boolean mouseDown(double mx, double my, int btn) {
        for (int i = HITS.size() - 1; i >= 0; i--) {
            float[] h = HITS.get(i);
            if (!Ui.in(mx, my, h[1], h[2], h[3], h[4])) continue;
            int id = (int) h[0];
            switch (id) {
                case PLAY -> MediaPlayer.toggle();
                case PREV -> MediaPlayer.prev();
                case NEXT -> MediaPlayer.next();
                case SHUF -> { Config.mediaShuffle = !Config.mediaShuffle; Config.save(); }
                case REP -> { Config.mediaRepeat = (Config.mediaRepeat + 1) % 3; Config.save(); }
                case SEEK -> { drag = SEEK; seekTo(mx); }
                case VOL -> { drag = VOL; volTo(mx); }
                case FOLDER -> MediaPlayer.openFolder();
                case RESCAN -> MediaPlayer.scan();
                default -> { if (id >= ROW) MediaPlayer.play(id - ROW); }
            }
            return true;
        }
        return false;
    }

    private static void seekTo(double mx) {
        MediaPlayer.seek((float) ((mx - seekX) / Math.max(1f, seekW)));
    }

    private static void volTo(double mx) {
        Config.mediaVolume = Mth.clamp((mx - volX) / Math.max(1f, volW), 0.0, 1.0);
    }

    static void mouseDrag(double mx) {
        if (drag == SEEK) seekTo(mx);
        else if (drag == VOL) volTo(mx);
    }

    static void mouseUp() {
        if (drag == VOL) Config.save();
        drag = 0;
    }

    static boolean scroll(double mx, double my, double dy) {
        if (my < listTop || my > listBot) return false;
        listScrollT -= (float) (dy * 26);
        return true;
    }
}
