package dev.flr.visuals;

import net.minecraft.client.Minecraft;

/** Однострочное поле ввода в стиле FLR (гладкое, с курсором, вставкой из буфера). */
final class TextInput {
    String text = "";
    int cur;
    boolean focus;
    final int max;

    TextInput(int max) {
        this.max = max;
    }

    void set(String s) {
        text = s == null ? "" : s;
        cur = text.length();
    }

    boolean charTyped(char c) {
        if (!focus || c < 32 || c == 127 || text.length() >= max) return false;
        text = text.substring(0, cur) + c + text.substring(cur);
        cur++;
        return true;
    }

    boolean key(int key, int mods) {
        if (!focus) return false;
        if ((mods & 2) != 0 && key == 86) {
            String c = Minecraft.getInstance().keyboardHandler.getClipboard();
            if (c != null) {
                c = c.replace("\n", "").replace("\r", "");
                if (text.length() + c.length() > max) c = c.substring(0, Math.max(0, max - text.length()));
                text = text.substring(0, cur) + c + text.substring(cur);
                cur += c.length();
            }
            return true;
        }
        if ((mods & 2) != 0 && key == 65) {
            text = "";
            cur = 0;
            return true;
        }
        switch (key) {
            case 259 -> {
                if (cur > 0) {
                    text = text.substring(0, cur - 1) + text.substring(cur);
                    cur--;
                }
                return true;
            }
            case 261 -> {
                if (cur < text.length()) text = text.substring(0, cur) + text.substring(cur + 1);
                return true;
            }
            case 263 -> { cur = Math.max(0, cur - 1); return true; }
            case 262 -> { cur = Math.min(text.length(), cur + 1); return true; }
            case 268 -> { cur = 0; return true; }
            case 269 -> { cur = text.length(); return true; }
            default -> { return false; }
        }
    }

    void draw(float x, float y, float w, float h, String hint, int accent) {
        Gfx.rr(x, y, w, h, h / 2f, focus ? 0x26FFFFFF : 0x18FFFFFF);
        Gfx.ring(x, y, w, h, h / 2f, 1f, focus ? Gfx.rgba(accent, 0.9f) : 0x2EFFFFFF);
        float tx = x + h * 0.5f + 2, maxW = w - h - 4;
        float size = Ui.BODY;
        if (text.isEmpty()) {
            Gfx.textMid(hint, tx, y + h / 2f, size, 0x66FFFFFF, false);
        } else {
            int from = 0;
            while (from < cur && Gfx.textW(text.substring(from, cur), size, false) > maxW - 4) from++;
            String vis = text.substring(from);
            while (vis.length() > 1 && Gfx.textW(vis, size, false) > maxW) vis = vis.substring(0, vis.length() - 1);
            Gfx.textMid(vis, tx, y + h / 2f, size, 0xFFFFFFFF, false);
            if (focus && (System.currentTimeMillis() / 500) % 2 == 0) {
                float cx = tx + Gfx.textW(text.substring(from, cur), size, false);
                Gfx.rect(cx, y + h * 0.24f, 1f, h * 0.52f, 0xFFFFFFFF);
            }
            return;
        }
        if (focus && (System.currentTimeMillis() / 500) % 2 == 0) Gfx.rect(tx, y + h * 0.24f, 1f, h * 0.52f, 0xFFFFFFFF);
    }
}
