package dev.flr.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.stb.STBTTAlignedQuad;
import org.lwjgl.stb.STBTTFontinfo;
import org.lwjgl.stb.STBTTPackContext;
import org.lwjgl.stb.STBTTPackedchar;
import org.lwjgl.stb.STBTruetype;
import org.lwjgl.system.MemoryStack;

/**
 * Собственная растеризация шрифта (stb_truetype) в текстурные атласы с линейной фильтрацией.
 * Ванильный шрифт не используется: текст гладкий в любом масштабе интерфейса.
 */
final class Fonts {
    static final class Glyph {
        float x0, y0, x1, y1, s0, t0, s1, t1, adv;
        boolean vis;
    }

    static final class Atlas {
        int tex;
        float px, ascent, cap;
        final Map<Integer, Glyph> map = new HashMap<>();
        Glyph fallback;

        Glyph get(int cp) {
            Glyph g = map.get(cp);
            return g != null ? g : fallback;
        }
    }

    private static final Atlas[][] ATLAS = new Atlas[2][3];
    private static final float[] PX = {28f, 60f, 100f};
    private static final int[][] SIZE = {{512, 512}, {1536, 1024}, {2048, 1024}};
    private static final int[] OVER = {2, 2, 1};
    private static final int[][] FULL = {{32, 95}, {0xA0, 96}, {0x400, 96}, {0x2010, 32}};
    private static final int[][] LITE = {{32, 95}, {0x400, 96}, {0x2010, 32}};

    private Fonts() {}

    static Atlas get(boolean bold, float physPx) {
        int c = physPx <= 36f ? 0 : physPx <= 76f ? 1 : 2;
        int b = bold ? 1 : 0;
        Atlas a = ATLAS[b][c];
        if (a == null) {
            a = bake(bold, c);
            ATLAS[b][c] = a;
        }
        return a;
    }

    private static ByteBuffer load(boolean bold) {
        try (InputStream in = Fonts.class.getResourceAsStream("/assets/flrvisuals/font/" + (bold ? "carlito_b.ttf" : "carlito.ttf"))) {
            byte[] b = in.readAllBytes();
            ByteBuffer bb = BufferUtils.createByteBuffer(b.length);
            bb.put(b).flip();
            return bb;
        } catch (Exception e) {
            throw new RuntimeException("FLR font missing", e);
        }
    }

    private static Atlas bake(boolean bold, int cls) {
        float px = PX[cls];
        int w = SIZE[cls][0], h = SIZE[cls][1];
        int[][] ranges = cls == 2 ? LITE : FULL;
        ByteBuffer ttf = load(bold);
        ByteBuffer bitmap = BufferUtils.createByteBuffer(w * h);
        STBTTPackedchar.Buffer[] pcs = new STBTTPackedchar.Buffer[ranges.length];
        STBTTPackContext pc = STBTTPackContext.malloc();
        try {
            STBTruetype.stbtt_PackBegin(pc, bitmap, w, h, 0, 2, 0L);
            STBTruetype.stbtt_PackSetOversampling(pc, OVER[cls], OVER[cls]);
            for (int i = 0; i < ranges.length; i++) {
                pcs[i] = STBTTPackedchar.malloc(ranges[i][1]);
                STBTruetype.stbtt_PackFontRange(pc, ttf, 0, px, ranges[i][0], pcs[i]);
            }
            STBTruetype.stbtt_PackEnd(pc);
        } finally {
            pc.free();
        }

        Atlas at = new Atlas();
        at.px = px;
        try (MemoryStack st = MemoryStack.stackPush()) {
            STBTTFontinfo info = STBTTFontinfo.malloc(st);
            STBTruetype.stbtt_InitFont(info, ttf, 0);
            IntBuffer a = st.mallocInt(1), d = st.mallocInt(1), l = st.mallocInt(1);
            STBTruetype.stbtt_GetFontVMetrics(info, a, d, l);
            at.ascent = a.get(0) * STBTruetype.stbtt_ScaleForPixelHeight(info, px);
            FloatBuffer xp = st.mallocFloat(1), yp = st.mallocFloat(1);
            STBTTAlignedQuad q = STBTTAlignedQuad.malloc(st);
            for (int i = 0; i < ranges.length; i++) {
                for (int j = 0; j < ranges[i][1]; j++) {
                    xp.put(0, 0f);
                    yp.put(0, 0f);
                    STBTruetype.stbtt_GetPackedQuad(pcs[i], w, h, j, xp, yp, q, false);
                    Glyph g = new Glyph();
                    g.x0 = q.x0(); g.y0 = q.y0(); g.x1 = q.x1(); g.y1 = q.y1();
                    g.s0 = q.s0(); g.t0 = q.t0(); g.s1 = q.s1(); g.t1 = q.t1();
                    g.adv = xp.get(0);
                    g.vis = g.x1 - g.x0 > 0.01f && g.y1 - g.y0 > 0.01f;
                    at.map.put(ranges[i][0] + j, g);
                }
            }
        }
        for (STBTTPackedchar.Buffer b : pcs) b.free();
        Glyph hh = at.map.get((int) 'H');
        at.cap = hh == null ? px * 0.65f : -hh.y0;
        at.fallback = at.map.get((int) '?');

        ByteBuffer rgba = BufferUtils.createByteBuffer(w * h * 4);
        for (int i = 0; i < w * h; i++) {
            rgba.put((byte) 255).put((byte) 255).put((byte) 255).put(bitmap.get(i));
        }
        rgba.flip();
        int id = GL11.glGenTextures();
        GlStateManager._bindTexture(id);
        GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 1);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, w, h, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, rgba);
        GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 4);
        at.tex = id;
        return at;
    }
}
