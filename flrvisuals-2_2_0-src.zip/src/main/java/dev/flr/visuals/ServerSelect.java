package dev.flr.visuals;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;

/** Подключение к серверу из любого экрана FLR. */
final class ServerSelect {
    private ServerSelect() {}

    static void join(Screen back, ServerData d) {
        ServerScreen.connect(back, d);
    }
}
