package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;

/**
 * Питомцы 2.2: гладкие модели из эллипсоидов и конусов со сглаженными нормалями (а не кубики),
 * градиентная заливка, светящиеся глаза-блики, живая анимация (дыхание, моргание, слежение, хвост-цепочка, прыжки).
 * Единицы — 1/16 блока, начало у ног, y вверх, перёд = -z.
 */
final class PetModels {
    private static final float U = 1f / 16f;
    private static int latN = 7, lonN = 11;
    private static final float[] SA = new float[24], CA = new float[24], SB = new float[40], CB = new float[40];
    private static float lookYaw, lookPitch;

    private PetModels() {}

    private static void detail(int lat, int lon) {
        latN = lat;
        lonN = lon;
        for (int i = 0; i <= lat; i++) {
            float a = Mth.PI * i / lat - Mth.PI / 2f;
            SA[i] = Mth.sin(a);
            CA[i] = Mth.cos(a);
        }
        for (int j = 0; j <= lon; j++) {
            float b = Mth.TWO_PI * j / lon;
            SB[j] = Mth.sin(b);
            CB[j] = Mth.cos(b);
        }
    }

    // ------------------------------------------------------------------ примитивы
    private static void vtx(PoseStack.Pose p, float x, float y, float z, int col, float nx, float ny, float nz, int lit) {
        Pets.vc.addVertex(p.pose(), x * U, y * U, z * U).setColor(col).setUv(0f, 0f)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(lit).setNormal(p, nx, ny, nz);
    }

    static void ball(float cx, float cy, float cz, float rx, float ry, float rz, int c) {
        ball(cx, cy, cz, rx, ry, rz, c, false);
    }

    /** Эллипсоид со сглаженными нормалями. glow = рисуется на полной яркости (глаза, блики). */
    static void ball(float cx, float cy, float cz, float rx, float ry, float rz, int c, boolean glow) {
        if (rx <= 0.01f || ry <= 0.01f || rz <= 0.01f) return;
        PoseStack.Pose p = Pets.ps.last();
        int lit = glow ? LightTexture.FULL_BRIGHT : Pets.light;
        for (int i = 0; i < latN; i++) {
            for (int j = 0; j < lonN; j++) {
                for (int k = 0; k < 4; k++) {
                    int ii = i + (k == 2 || k == 3 ? 1 : 0), jj = j + (k == 1 || k == 2 ? 1 : 0);
                    float dx = CA[ii] * CB[jj], dy = SA[ii], dz = CA[ii] * SB[jj];
                    float nx = dx / rx, ny = dy / ry, nz = dz / rz, nl = Mth.sqrt(nx * nx + ny * ny + nz * nz);
                    int col = glow ? c : Pets.shade(c, 0.84f + 0.2f * dy);
                    vtx(p, cx + dx * rx, cy + dy * ry, cz + dz * rz, col, nx / nl, ny / nl, nz / nl, lit);
                }
            }
        }
    }

    /** Усечённый конус вдоль +Y (отрицательная длина — вниз). Для лап, ушей, носов, хвостов. */
    static void taper(float cx, float cy, float cz, float r0x, float r0z, float r1x, float r1z, float len, int c, int sides) {
        if (len < 0) {
            cy += len;
            len = -len;
            float tx = r0x, tz = r0z;
            r0x = r1x; r0z = r1z; r1x = tx; r1z = tz;
        }
        PoseStack.Pose p = Pets.ps.last();
        float slope = (r0x - r1x) / Math.max(0.01f, len);
        for (int i = 0; i < sides; i++) {
            float a0 = Mth.TWO_PI * i / sides, a1 = Mth.TWO_PI * (i + 1) / sides;
            float c0 = Mth.cos(a0), s0 = Mth.sin(a0), c1 = Mth.cos(a1), s1 = Mth.sin(a1);
            float n0l = Mth.sqrt(1 + slope * slope), n1l = n0l;
            int cb = Pets.shade(c, 0.78f), ct = Pets.shade(c, 1.04f);
            vtx(p, cx + c0 * r0x, cy, cz + s0 * r0z, cb, c0 / n0l, slope / n0l, s0 / n0l, Pets.light);
            vtx(p, cx + c1 * r0x, cy, cz + s1 * r0z, cb, c1 / n1l, slope / n1l, s1 / n1l, Pets.light);
            vtx(p, cx + c1 * r1x, cy + len, cz + s1 * r1z, ct, c1 / n1l, slope / n1l, s1 / n1l, Pets.light);
            vtx(p, cx + c0 * r1x, cy + len, cz + s0 * r1z, ct, c0 / n0l, slope / n0l, s0 / n0l, Pets.light);
            vtx(p, cx, cy + len, cz, ct, 0, 1, 0, Pets.light);
            vtx(p, cx + c0 * r1x, cy + len, cz + s0 * r1z, ct, 0, 1, 0, Pets.light);
            vtx(p, cx + c1 * r1x, cy + len, cz + s1 * r1z, ct, 0, 1, 0, Pets.light);
            vtx(p, cx, cy + len, cz, ct, 0, 1, 0, Pets.light);
        }
    }

    private static void shadow(float rx, float rz) {
        PoseStack.Pose p = Pets.ps.last();
        int c = 0x30000000;
        for (int i = 0; i < 12; i++) {
            float a0 = Mth.TWO_PI * i / 12, a1 = Mth.TWO_PI * (i + 1) / 12;
            vtx(p, 0, 0.1f, 0, c, 0, 1, 0, Pets.light);
            vtx(p, Mth.cos(a0) * rx, 0.1f, Mth.sin(a0) * rz, 0x00000000, 0, 1, 0, Pets.light);
            vtx(p, Mth.cos(a1) * rx, 0.1f, Mth.sin(a1) * rz, 0x00000000, 0, 1, 0, Pets.light);
            vtx(p, 0, 0.1f, 0, c, 0, 1, 0, Pets.light);
        }
    }

    private static void eye(float x, float y, float z, float s, float k, int iris) {
        ball(x, y, z, s * 0.92f, s * 1.08f * k + 0.06f, s * 0.5f, 0xFF15121C);
        ball(x, y, z - s * 0.28f, s * 0.64f, s * 0.8f * k + 0.04f, s * 0.3f, iris, true);
        ball(x + s * 0.3f, y + s * 0.34f * k, z - s * 0.5f, s * 0.26f, s * 0.26f * k + 0.01f, s * 0.2f, 0xFFFFFFFF, true);
    }

    private static float blink(float t) {
        return (t + 17f) % 95f < 4f ? 0.12f : 1f;
    }

    private static float hy(float t) {
        return Mth.clamp(-lookYaw, -50f, 50f) * 0.8f + Mth.sin(t * 0.031f) * 14f * (0.5f + 0.5f * Mth.sin(t * 0.0113f));
    }

    private static float hp(float t) {
        return Mth.clamp(-lookPitch, -25f, 25f) * 0.6f + Mth.sin(t * 0.06f) * 1.8f;
    }

    private static float flick(float t) {
        return Mth.sin(t * 0.017f) > 0.86f ? Mth.sin(t * 0.9f) * 12f : 0f;
    }

    private static void heart(float t, float y) {
        float q = (t % 360f) / 360f / 0.22f;
        if (q > 1f) return;
        float s = Mth.sin(q * Mth.PI);
        if (s < 0.05f) return;
        Pets.ps.pushPose();
        Pets.ps.translate(0, (y + q * 8f) * U, 0);
        Pets.ps.scale(s, s, s);
        ball(-1.1f, 0.6f, 0, 1.15f, 1.15f, 0.6f, 0xFFFF4F7B, true);
        ball(1.1f, 0.6f, 0, 1.15f, 1.15f, 0.6f, 0xFFFF4F7B, true);
        ball(0, -0.4f, 0, 1.5f, 1.5f, 0.6f, 0xFFFF4F7B, true);
        Pets.ps.popPose();
    }

    private static void part(float x, float y, float z, float rx, float ry, float rz, Runnable r) {
        Pets.part(x, y, z, rx, ry, rz, r);
    }

    // ------------------------------------------------------------------ вход
    static void pet(int type, float t, float ph, float walk, float yaw, float pitch, boolean lod) {
        lookYaw = yaw;
        lookPitch = pitch;
        if (lod) detail(4, 7);
        else detail(7, 11);
        switch (type) {
            case 1 -> rabbit(t, ph, walk);
            case 2 -> feline(0, t, ph, walk);
            case 3 -> feline(2, t, ph, walk);
            case 4 -> penguin(t, ph, walk);
            case 6 -> feline(1, t, ph, walk);
            case 7 -> snowman(t, ph, walk);
            case 8 -> panda(t, ph, walk);
            case 9 -> slime(t, ph, walk);
            default -> { }
        }
    }

    static void pet(int type, float t, float ph, float walk, float yaw, float pitch) {
        pet(type, t, ph, walk, yaw, pitch, false);
    }

    // ------------------------------------------------------------------ кролик
    private static void rabbit(float t, float ph, float walk) {
        final int FUR = 0xFFEDE8F6, FUR2 = 0xFFD9D2E8, BELLY = 0xFFFFFBFF, PINK = 0xFFF7A8C2;
        float w = Math.min(1f, walk * 2f), hopP = ph * 0.9f;
        float hop = walk > 0.05f ? Math.abs(Mth.sin(hopP)) * 3.4f * w : 0f;
        float pitchB = Mth.sin(hopP + 0.6f) * 13f * w, br = Mth.sin(t * 0.08f) * 0.2f;
        final float hyaw = hy(t), hpit = hp(t), k = blink(t), sw = Mth.sin(t * 0.07f) * 4f + flick(t), eb = Mth.sin(hopP + 1.2f) * 10f * w;
        final float tw = Mth.sin(t * 0.25f) * 0.4f;
        shadow(5.6f, 6.6f);
        Pets.ps.pushPose();
        Pets.ps.translate(0, hop * U, 0);
        part(0, 3.5f, 0, pitchB, 0, 0, () -> {
            ball(0, 4.5f, 0.8f, 3.7f, 3.4f + br, 4.4f, FUR);
            ball(0, 3.2f, -0.6f, 2.8f, 2.3f, 3.3f, BELLY);
            for (int s = -1; s <= 1; s += 2) {
                ball(s * 3.3f, 3.0f, 3.0f, 1.9f, 2.5f, 2.8f, FUR2);
                ball(s * 3.3f, 0.9f, 1.8f, 1.35f, 1.0f, 3.1f, FUR);
                ball(s * 1.6f, 1.0f, -2.6f, 1.05f, 1.05f, 1.6f, BELLY);
            }
            ball(0, 4.4f, 5.4f + tw, 2.0f, 2.0f, 2.0f, 0xFFFFFFFF);
            part(0, 6.3f, -2.6f, hpit, hyaw, 0, () -> {
                ball(0, 2.4f, -0.4f, 3.3f, 3.1f, 3.2f, FUR);
                ball(0, 1.3f, -3.0f, 1.9f, 1.4f, 1.4f, BELLY);
                ball(0, 1.8f, -4.2f, 0.62f, 0.45f, 0.45f, PINK);
                ball(-2.3f, 1.2f, -2.7f, 0.8f, 0.5f, 0.3f, 0x90FF9DB8);
                ball(2.3f, 1.2f, -2.7f, 0.8f, 0.5f, 0.3f, 0x90FF9DB8);
                eye(-1.65f, 2.8f, -3.2f, 0.88f, k, 0xFF6C4BC8);
                eye(1.65f, 2.8f, -3.2f, 0.88f, k, 0xFF6C4BC8);
                for (int s = -1; s <= 1; s += 2) {
                    for (int i = 0; i < 2; i++) Pets.box(s * 2.0f, 1.0f + i * 0.5f, -3.9f, s * 5.4f, 1.12f + i * 0.5f, -3.8f + (i - 0.5f) * 0.3f, 0xB0FFFFFF);
                    part(s * 1.5f, 4.9f, -0.4f, 0, 0, s * (14f + (s < 0 ? -1 : 1) * (sw - eb) * 0.0f) + (s < 0 ? sw : -sw) * 0.5f - eb * s, () -> {
                        taper(0, 0, 0, 1.15f, 0.6f, 0.85f, 0.45f, 7f, FUR, 7);
                        ball(0, 3.5f, -0.45f, 0.62f, 3.0f, 0.22f, PINK);
                    });
                }
            });
        });
        heart(t, 17);
        Pets.ps.popPose();
    }

    // ------------------------------------------------------------------ кошка / лиса / ягуар
    private static void tail(int i, int n, float t, float wag, float r0, float r1, float seg, int c, int tip, float curl) {
        if (i >= n) return;
        float f = i / (float) n, r = Mth.lerp(f, r0, r1);
        int col = i >= n - 2 ? tip : c;
        part(0, 0, 0, -curl, wag * (0.6f + f), 0, () -> {
            ball(0, 0, seg * 0.45f, r, r, seg * 0.75f, col);
            Pets.ps.pushPose();
            Pets.ps.translate(0, 0, seg * U);
            tail(i + 1, n, t, wag, r0, r1, seg, c, tip, curl);
            Pets.ps.popPose();
        });
    }

    /** kind: 0 кошка, 1 лиса, 2 ягуар. */
    private static void feline(int kind, float t, float ph, float walk) {
        final int B = kind == 1 ? 0xFFEC7A2C : kind == 2 ? 0xFFE8BE62 : 0xFFE69B52;
        final int BL = kind == 1 ? 0xFFFFF6EA : kind == 2 ? 0xFFF8EDD2 : 0xFFFFF2E0;
        final int D = kind == 1 ? 0xFF2A1D1A : kind == 2 ? 0xFF4A3017 : 0xFFB8651F;
        final int EYE = kind == 1 ? 0xFFFFC040 : kind == 2 ? 0xFFB4E86A : 0xFF7ADA6A;
        float w = Math.min(1f, walk * 2f), sit = kind == 2 ? 0f : 1f - Mth.clamp(walk * 5f, 0f, 1f);
        float stride = ph * 0.8f, swing = 38f * w, bob = Math.abs(Mth.sin(stride)) * 0.8f * w, br = Mth.sin(t * 0.08f) * 0.18f;
        final float hyaw = hy(t), hpit = hp(t) + Mth.sin(stride) * 3f * w, k = blink(t), ear = flick(t);
        final float L = kind == 2 ? 1.25f : 1f, snout = kind == 1 ? 1.9f : kind == 2 ? 0.8f : 0f;
        final float wag = Mth.sin(t * (0.1f + walk * 0.12f)) * 16f;
        shadow(5.6f, 7.4f * L);
        Pets.ps.pushPose();
        Pets.ps.translate(0, (bob - sit * 1.7f) * U, 0);
        part(0, 3.6f, 3.2f * L, sit * 30f, 0, 0, () -> {
            ball(0, 4.9f, -0.2f * L, 2.9f, 2.9f + br, 4.6f * L, B);
            ball(0, 4.0f, -1.2f * L, 2.2f, 1.9f, 3.9f * L, BL);
            ball(0, 4.7f, -3.4f * L, 2.75f, 2.9f, 2.4f, B);
            ball(0, 4.0f, -4.2f * L, 1.9f, 2.0f, 1.7f, BL);
            if (kind == 0) for (int i = 0; i < 4; i++) ball(0, 7.6f - Math.abs(i - 1.5f) * 0.25f, -3.5f + i * 2.2f, 2.35f, 0.5f, 0.7f, D);
            if (kind == 2) {
                float[][] sp = {{-1.7f, 6.4f, -3}, {1.7f, 6.6f, -1.2f}, {-2.2f, 5.7f, 0.4f}, {2.1f, 5.6f, 1.6f}, {-1.4f, 7.3f, 2f}, {1.2f, 7.5f, -4f}, {2.5f, 4.6f, -2.5f}, {-2.6f, 4.8f, 3.2f}};
                for (float[] q : sp) ball(q[0], q[1], q[2] * L, 0.85f, 0.4f, 0.85f, D);
            }
            for (int i = 0; i < 2; i++) {
                float x = i == 0 ? -1.8f : 1.8f;
                float a = Mth.sin(stride + i * Mth.PI) * swing;
                part(x, 3.4f, -4.2f * L, a, 0, 0, () -> leg(B, BL, kind == 1 ? D : BL));
            }
            part(0, 6.2f, -4.6f * L, hpit, hyaw, 0, () -> {
                ball(0, 2.1f, -0.2f, 3.5f, 3.1f, 3.1f, B);
                ball(0, 0.9f, -2.5f - snout * 0.45f, 1.8f + snout * 0.1f, 1.35f, 1.5f + snout * 0.8f, BL);
                ball(0, 1.6f, -3.9f - snout, 0.6f, 0.45f, 0.4f, kind == 1 ? 0xFF1B1412 : 0xFFF28CA2);
                ball(-2.6f, 0.9f, -1.4f, 1.1f, 1.2f, 1.2f, BL);
                ball(2.6f, 0.9f, -1.4f, 1.1f, 1.2f, 1.2f, BL);
                eye(-1.65f, 2.6f, -2.85f, 0.95f, k, EYE);
                eye(1.65f, 2.6f, -2.85f, 0.95f, k, EYE);
                for (int s = -1; s <= 1; s += 2) {
                    final int sd = s;
                    part(sd * 2.0f, 4.7f, -0.8f, 0, 0, sd * -(kind == 2 ? 8f : 4f) + (sd < 0 ? ear : -ear), () -> {
                        if (kind == 2) {
                            ball(0, 0.8f, 0, 1.3f, 1.2f, 0.7f, B);
                        } else {
                            taper(0, 0, 0, 1.5f, 0.7f, 0.15f, 0.12f, kind == 1 ? 4.6f : 3.3f, kind == 1 ? D : B, 6);
                            taper(0, 0.1f, -0.2f, 1.0f, 0.5f, 0.1f, 0.08f, kind == 1 ? 3.6f : 2.5f, 0xFFF7A8B8, 5);
                        }
                    });
                    for (int i = 0; i < 2; i++) Pets.box(sd * 1.6f, 0.7f + i * 0.5f, -3.4f - snout, sd * 5.3f, 0.82f + i * 0.5f, -3.3f - snout + (i - 0.5f) * 0.3f, 0xB0FFFFFF);
                }
            });
            Pets.ps.pushPose();
            Pets.ps.translate(0, 5.2f * U, 4.4f * L * U);
            if (kind == 1) tail(0, 6, t, wag * 0.02f, 1.8f, 2.6f, 2.2f, B, 0xFFFFFAF2, 22f - sit * 6f);
            else tail(0, kind == 2 ? 8 : 7, t, wag * 0.02f, 0.85f, 0.7f, 2.2f, B, D, (kind == 2 ? 14f : 18f) - sit * 6f);
            Pets.ps.popPose();
        });
        for (int i = 0; i < 2; i++) {
            float x = i == 0 ? -2.0f : 2.0f;
            float a = Mth.sin(stride + (1 - i) * Mth.PI) * swing * (1f - sit) + sit * 70f;
            part(x, 3.6f, 3.4f * L, a, 0, 0, () -> leg(B, BL, kind == 1 ? D : BL));
        }
        heart(t, 16);
        Pets.ps.popPose();
    }

    private static void leg(int c, int paw, int sock) {
        taper(0, 0, 0, 1.15f, 1.15f, 0.85f, 0.85f, -3.5f, c, 7);
        ball(0, -3.5f, -0.35f, 1.0f, 0.75f, 1.35f, sock);
    }

    // ------------------------------------------------------------------ пингвин
    private static void penguin(float t, float ph, float walk) {
        final int DK = 0xFF3C4150, BE = 0xFFF3F4F8, OR = 0xFFF0993C;
        float w = Math.min(1f, walk * 2f);
        float sway = Mth.sin(ph * 0.8f) * 8f * w + Mth.sin(t * 0.04f) * 1.5f;
        float flap = Mth.sin(t * 0.1f) * 3f + w * Mth.sin(ph * 0.8f + 1.5f) * 24f + (Mth.sin(t * 0.021f) > 0.9f ? Mth.sin(t * 0.8f) * 26f : 0f);
        final float hyaw = hy(t) * 1.2f, hpit = hp(t), k = blink(t);
        float foot = Mth.sin(ph * 0.8f) * 32f * w, hopI = Mth.sin(t * 0.017f) > 0.92f ? Math.abs(Mth.sin(t * 0.7f)) * 2f : 0f;
        shadow(5f, 5f);
        Pets.ps.pushPose();
        Pets.ps.translate(0, (Math.abs(Mth.sin(ph * 0.8f)) * 0.9f * w + hopI) * U, 0);
        part(0, 1.5f, 0, 0, 0, sway, () -> {
            ball(0, 4.6f, 0.2f, 3.9f, 4.7f, 3.6f, DK);
            ball(0, 4.1f, -1.1f, 2.95f, 3.8f, 2.7f, BE);
            ball(0, 1.8f, 3.2f, 1.2f, 0.7f, 1.8f, DK);
            for (int i = 0; i < 12; i++) {
                float a = Mth.TWO_PI * i / 12;
                ball(Mth.cos(a) * 3.0f, 8.0f, Mth.sin(a) * 2.8f - 0.3f, 0.95f, 0.95f, 0.95f, 0xFFE0384E);
            }
            ball(2.0f, 6.9f, -2.5f, 0.9f, 2.0f, 0.9f, 0xFFE0384E);
            part(0, 8.6f, 0, hpit, hyaw, 0, () -> {
                ball(0, 2.0f, -0.2f, 3.5f, 3.2f, 3.2f, DK);
                ball(0, 1.5f, -2.4f, 2.4f, 1.9f, 1.0f, BE);
                taper(0, 1.2f, -3.0f, 0.95f, 0.55f, 0.35f, 0.2f, -1.9f, OR, 6);
                eye(-1.6f, 2.5f, -2.75f, 0.85f, k, 0xFF222230);
                eye(1.6f, 2.5f, -2.75f, 0.85f, k, 0xFF222230);
                ball(-2.6f, 1.2f, -2.2f, 0.7f, 0.45f, 0.3f, 0x90FF9DB8);
                ball(2.6f, 1.2f, -2.2f, 0.7f, 0.45f, 0.3f, 0x90FF9DB8);
            });
            part(-3.6f, 6.8f, 0, 0, 0, -(8f + flap), () -> ball(-0.5f, -2.4f, 0, 0.8f, 3.2f, 1.6f, DK));
            part(3.6f, 6.8f, 0, 0, 0, 8f + flap, () -> ball(0.5f, -2.4f, 0, 0.8f, 3.2f, 1.6f, DK));
            part(-1.7f, 0.2f, 0.4f, foot, 0, 0, () -> ball(0, 0, -1.2f, 1.5f, 0.55f, 2.2f, OR));
            part(1.7f, 0.2f, 0.4f, -foot, 0, 0, () -> ball(0, 0, -1.2f, 1.5f, 0.55f, 2.2f, OR));
        });
        heart(t, 17);
        Pets.ps.popPose();
    }

    // ------------------------------------------------------------------ снеговик
    private static void snowman(float t, float ph, float walk) {
        final int SN = 0xFFF6F9FD, COAL = 0xFF1B1E24, RED = 0xFFE0384E, STICK = 0xFF6B4A2B;
        float w = Math.min(1f, walk * 2f);
        float hop = Math.abs(Mth.sin(ph * 0.8f)) * 1.8f * w, sway = Mth.sin(ph * 0.8f) * 6f * w + Mth.sin(t * 0.03f) * 1.5f;
        final float hyaw = hy(t), hpit = hp(t), k = blink(t), wave = Mth.sin(t * 0.15f) * 18f;
        shadow(5f, 5f);
        Pets.ps.pushPose();
        Pets.ps.translate(0, hop * U, 0);
        part(0, 0, 0, 0, 0, sway, () -> {
            ball(0, 3.6f, 0, 4.3f, 3.7f, 4.2f, SN);
            ball(0, 8.4f, 0, 3.3f, 3.0f, 3.2f, SN);
            for (int i = 0; i < 3; i++) ball(0, 8.9f - i * 1.7f, -3.1f + i * 0.12f, 0.45f, 0.45f, 0.3f, COAL);
            for (int i = 0; i < 12; i++) {
                float a = Mth.TWO_PI * i / 12;
                ball(Mth.cos(a) * 2.9f, 10.4f, Mth.sin(a) * 2.8f, 0.9f, 0.9f, 0.9f, RED);
            }
            ball(1.9f, 8.0f, -2.9f, 0.9f, 2.2f, 0.7f, RED);
            part(-3.1f, 9.0f, 0, 0, 0, -(34f + wave * 0.3f), () -> { taper(0, 0, 0, 0.35f, 0.35f, 0.2f, 0.2f, -6.5f, STICK, 5); });
            part(3.1f, 9.0f, 0, 0, 0, 36f + wave, () -> taper(0, 0, 0, 0.35f, 0.35f, 0.2f, 0.2f, 6.5f, STICK, 5));
            part(0, 10.9f, 0, hpit, hyaw, 0, () -> {
                ball(0, 2.0f, 0, 2.9f, 2.7f, 2.8f, SN);
                eye(-1.15f, 2.7f, -2.4f, 0.7f, k, 0xFF222230);
                eye(1.15f, 2.7f, -2.4f, 0.7f, k, 0xFF222230);
                taper(0, 1.7f, -2.5f, 0.55f, 0.55f, 0.1f, 0.1f, -2.8f, 0xFFF0782A, 6);
                for (int i = -2; i <= 2; i++) ball(i * 0.62f, 0.7f + (Math.abs(i) == 2 ? 0.45f : 0f), -2.65f, 0.26f, 0.26f, 0.2f, COAL);
                taper(0, 4.3f, 0, 3.6f, 3.6f, 3.4f, 3.4f, 0.5f, 0xFF15151C, 12);
                taper(0, 4.8f, 0, 2.3f, 2.3f, 2.1f, 2.1f, 3.4f, 0xFF1C1C26, 12);
                taper(0, 4.8f, 0, 2.35f, 2.35f, 2.15f, 2.15f, 0.8f, RED, 12);
            });
        });
        heart(t, 19);
        Pets.ps.popPose();
    }

    // ------------------------------------------------------------------ панда
    private static void panda(float t, float ph, float walk) {
        final int W = 0xFFF6F6FA, K = 0xFF22222B;
        float w = Math.min(1f, walk * 2f), stride = ph * 0.8f, sw = 34f * w, br = Mth.sin(t * 0.08f) * 0.2f;
        final float hyaw = hy(t), hpit = hp(t), k = blink(t), ear = flick(t);
        float bob = Math.abs(Mth.sin(stride)) * 0.8f * w;
        shadow(6f, 6.5f);
        Pets.ps.pushPose();
        Pets.ps.translate(0, bob * U, 0);
        ball(0, 5.6f, 0.4f, 4.3f, 4.0f + br, 4.0f, W);
        ball(0, 5.4f, -3.4f, 4.4f, 3.0f, 1.2f, K, false);
        ball(0, 5.2f, -3.0f, 3.2f, 2.5f, 1.8f, W);
        for (int i = 0; i < 2; i++) {
            float x = i == 0 ? -3.2f : 3.2f;
            part(x, 3.2f, -2.6f, Mth.sin(stride + i * Mth.PI) * sw, 0, 0, () -> { taper(0, 0, 0, 1.6f, 1.6f, 1.35f, 1.35f, -3.4f, K, 8); ball(0, -3.4f, -0.2f, 1.5f, 1.0f, 1.8f, K); });
            part(x * 0.95f, 3.2f, 2.6f, Mth.sin(stride + (1 - i) * Mth.PI) * sw, 0, 0, () -> { taper(0, 0, 0, 1.7f, 1.7f, 1.4f, 1.4f, -3.2f, K, 8); ball(0, -3.2f, -0.2f, 1.6f, 1.0f, 1.9f, K); });
        }
        ball(0, 5.0f, 4.4f, 1.3f, 1.3f, 1.3f, W);
        part(0, 9.4f, -2.2f, hpit, hyaw, 0, () -> {
            ball(0, 2.0f, 0, 4.0f, 3.4f, 3.5f, W);
            ball(0, 0.9f, -2.9f, 1.8f, 1.2f, 1.1f, 0xFFFFFFFF);
            ball(0, 1.5f, -3.9f, 0.7f, 0.5f, 0.4f, K);
            for (int s = -1; s <= 1; s += 2) {
                ball(s * 1.7f, 2.5f, -3.0f, 1.25f, 1.65f, 0.7f, K);
                eye(s * 1.7f, 2.6f, -3.35f, 0.65f, k, 0xFF3A2A18);
                final int sd = s;
                part(sd * 3.1f, 4.9f, 0, 0, 0, sd * -18f + (sd < 0 ? ear : -ear), () -> ball(0, 0.4f, 0, 1.45f, 1.45f, 1.0f, K));
            }
        });
        heart(t, 17);
        Pets.ps.popPose();
    }

    // ------------------------------------------------------------------ слайм
    private static void slime(float t, float ph, float walk) {
        float w = Math.min(1f, walk * 2f);
        float cyc = walk > 0.05f ? Math.abs(Mth.sin(ph * 0.55f)) : 0.5f + 0.5f * Mth.sin(t * 0.09f);
        float air = walk > 0.05f ? cyc * 3.2f * w : 0f;
        float sy = 1f + (walk > 0.05f ? (cyc - 0.4f) * 0.3f * w : Mth.sin(t * 0.09f) * 0.06f), sxz = 1f / Mth.sqrt(sy);
        final float k = blink(t);
        shadow(5.5f * (1f - air * 0.05f), 5.5f * (1f - air * 0.05f));
        Pets.ps.pushPose();
        Pets.ps.translate(0, air * U, 0);
        Pets.ps.scale(sxz, sy, sxz);
        ball(0, 4.4f, 0, 4.4f, 4.1f, 4.4f, 0xE04ADE6A);
        ball(0.6f, 3.6f, 0.4f, 2.1f, 1.9f, 2.1f, 0xF02FA64A);
        ball(-1.3f, 6.2f, -2.5f, 0.9f, 0.55f, 0.55f, 0xA0FFFFFF, true);
        eye(-1.6f, 4.6f, -4.15f, 0.8f, k, 0xFF173B22);
        eye(1.6f, 4.6f, -4.15f, 0.8f, k, 0xFF173B22);
        ball(0, 3.0f, -4.2f, 0.9f, 0.35f, 0.3f, 0xFF173B22);
        ball(-2.8f, 3.4f, -3.4f, 0.8f, 0.5f, 0.3f, 0x90FF9DB8);
        ball(2.8f, 3.4f, -3.4f, 0.8f, 0.5f, 0.3f, 0x90FF9DB8);
        Pets.ps.popPose();
    }
}
