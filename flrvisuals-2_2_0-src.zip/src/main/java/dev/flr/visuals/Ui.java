package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/** Общий набор для собственного оформления: гладкий шрифт Carlito, логотип кролика, иконки и кнопки-«таблетки». Всё через {@link Gfx}. */
final class Ui {
    static final ResourceLocation LOGO = ResourceLocation.fromNamespaceAndPath("flrvisuals", "textures/gui/logo.png");
    static final ResourceLocation ICONS = ResourceLocation.fromNamespaceAndPath("flrvisuals", "textures/gui/icons.png");
    /** Размер основного текста (высота строки в единицах GUI). */
    static final float BODY = 9.6f;

    private Ui() {}

    static Font font() {
        return Minecraft.getInstance().font;
    }

    static int w(String s) {
        return (int) Math.ceil(Gfx.textW(s, BODY, false));
    }

    static int wb(String s) {
        return (int) Math.ceil(Gfx.textW(s, BODY, true));
    }

    static void text(GuiGraphics g, String s, int x, int y, int color, boolean shadow) {
        Gfx.use(g);
        if (shadow) Gfx.text(s, x + 0.6f, y + 0.6f, BODY, Gfx.a(0xFF000000, ((color >>> 24) / 255f) * 0.6f), false);
        Gfx.text(s, x, y, BODY, color, false);
    }

    static void text(GuiGraphics g, String s, int x, int y, int color) {
        text(g, s, x, y, color, false);
    }

    static void bold(GuiGraphics g, String s, int x, int y, int color) {
        Gfx.use(g);
        Gfx.text(s, x, y, BODY, color, true);
    }

    static void center(GuiGraphics g, String s, int cx, int y, int color) {
        Gfx.use(g);
        Gfx.text(s, cx - Gfx.textW(s, BODY, false) / 2f, y, BODY, color, false);
    }

    static void scaled(GuiGraphics g, String s, float x, float y, float sc, int color, boolean bold) {
        Gfx.use(g);
        Gfx.text(s, x, y, BODY * sc, color, bold);
    }

    static String fit(String s, int maxW) {
        return Gfx.fit(s, maxW, BODY, false);
    }

    /** rgb + прозрачность 0..1 -> ARGB. */
    static int argb(int rgb, float a) {
        return Gfx.rgba(rgb, Math.max(a, 0.03f));
    }

    static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        Gfx.use(g);
        Gfx.rr(x, y, w, h, r, c);
    }

    static void logo(GuiGraphics g, int x, int y, int size, float alpha) {
        Gfx.use(g);
        Gfx.tex(LOGO, x, y, size, size, 0f, 0f, 1f, 1f, Gfx.rgba(0xFFFFFF, alpha));
    }

    static void logo(GuiGraphics g, float x, float y, float size, float alpha) {
        Gfx.use(g);
        Gfx.tex(LOGO, x, y, size, size, 0f, 0f, 1f, 1f, Gfx.rgba(0xFFFFFF, alpha));
    }

    /** idx: 0 игрок, 1 игроки, 2 моды, 3 настройки, 4 выход, 5 шестерня, 6 глобус, 7 снежинка. */
    static void icon(GuiGraphics g, int idx, float x, float y, float size, int rgb, float alpha) {
        Gfx.use(g);
        Gfx.tex(ICONS, x, y, size, size, idx / 8f, 0f, (idx + 1) / 8f, 1f, Gfx.rgba(rgb, alpha));
    }

    static boolean in(double mx, double my, double x, double y, double w, double h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Кнопка-«таблетка». primary = светлая заливка с тёмным текстом. */
    static void pill(GuiGraphics g, int x, int y, int w, int h, String label, boolean hover, boolean primary, int accent) {
        Gfx.use(g);
        float cy = y + h / 2f;
        if (primary) {
            Gfx.glow(x, y + 1, w, h, h / 2f, 6, Gfx.rgba(accent, hover ? 0.35f : 0.18f));
            Gfx.rrV(x, y, w, h, h / 2f, hover ? 0xFFFFFFFF : 0xFFF2F3FA, hover ? 0xFFE4E7F6 : 0xFFD9DCEE);
            Gfx.textC(label, x + w / 2f, cy, BODY, 0xFF10121C, true);
        } else {
            Gfx.rrV(x, y, w, h, h / 2f, hover ? 0x33FFFFFF : 0x1EFFFFFF, hover ? 0x22FFFFFF : 0x10FFFFFF);
            Gfx.ring(x, y, w, h, h / 2f, 1f, hover ? Gfx.rgba(accent, 0.8f) : 0x30FFFFFF);
            Gfx.textC(label, x + w / 2f, cy, BODY, 0xFFFFFFFF, false);
        }
    }
}
