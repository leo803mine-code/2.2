package dev.flr.visuals;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;

/** Свой прицел вместо ванильного: точка, кольцо, плюс или логотип кролика. Краснеет при наведении на существо. */
final class Crosshair {
    private static float gap, hit;

    private Crosshair() {}

    static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.getCameraType() != CameraType.FIRST_PERSON) return;
        Gfx.use(g);
        float cx = g.guiWidth() / 2f, cy = g.guiHeight() / 2f;
        boolean over = mc.crosshairPickEntity instanceof LivingEntity;
        hit += ((over ? 1f : 0f) - hit) * 0.25f;
        gap += ((mc.options.keyAttack.isDown() ? 2.5f : 0f) - gap) * 0.3f;
        int base = Config.color() | 0xFF000000;
        int col = Gfx.mix(base, 0xFFFF4D5E, hit), dark = 0x90000000;
        switch (Config.crosshair) {
            case 1 -> {
                Gfx.circle(cx, cy, 2.6f, dark);
                Gfx.circle(cx, cy, 1.6f, col);
            }
            case 2 -> {
                float r = 5.5f + gap;
                Gfx.circleRing(cx, cy, r + 0.6f, 2.4f, dark);
                Gfx.circleRing(cx, cy, r, 1.3f, col);
                Gfx.circle(cx, cy, 0.9f, col);
            }
            case 3 -> {
                float o = 3f + gap, l = 5f;
                for (int s = 0; s < 4; s++) {
                    float dx = s == 0 ? -1 : s == 1 ? 1 : 0, dy = s == 2 ? -1 : s == 3 ? 1 : 0;
                    Gfx.line(cx + dx * o, cy + dy * o, cx + dx * (o + l), cy + dy * (o + l), 3f, dark);
                    Gfx.line(cx + dx * o, cy + dy * o, cx + dx * (o + l), cy + dy * (o + l), 1.4f, col);
                }
            }
            case 4 -> {
                float s = 14 + gap * 2;
                Ui.logo(g, cx - s / 2f, cy - s / 2f, s, 0.55f + 0.45f * hit);
                Gfx.use(g);
                Gfx.circle(cx, cy, 0.9f, col);
            }
            default -> { }
        }
    }
}
