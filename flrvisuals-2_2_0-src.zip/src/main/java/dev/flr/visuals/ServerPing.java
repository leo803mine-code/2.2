package dev.flr.visuals;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import net.minecraft.resources.ResourceLocation;

/** Свой опрос серверов (Server List Ping): MOTD с цветами, онлайн, версия, иконка и пинг — без ванильного списка. */
final class ServerPing {
    static final class Seg {
        final String text;
        final int color;
        final boolean bold;

        Seg(String text, int color, boolean bold) {
            this.text = text;
            this.color = color;
            this.bold = bold;
        }
    }

    static final class Info {
        volatile int state; // 0 опрос, 1 ок, 2 недоступен
        volatile int online = -1, max = -1;
        volatile long ms = -1;
        volatile String version = "", favicon, err = "";
        volatile List<String> sample = List.of();
        volatile List<List<Seg>> motd = List.of();
        volatile long time;
        ResourceLocation tex;
        boolean texTried;
    }

    private static final Map<String, Info> CACHE = new ConcurrentHashMap<>();
    private static final ExecutorService EX = Executors.newFixedThreadPool(4, r -> {
        Thread t = new Thread(r, "FLR-Ping");
        t.setDaemon(true);
        return t;
    });
    private static final int[] COL = {0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA,
            0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};
    private static final Map<String, Integer> NAMES = new HashMap<>();

    static {
        String[] n = {"black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray", "dark_gray", "blue",
                "green", "aqua", "red", "light_purple", "yellow", "white"};
        for (int i = 0; i < n.length; i++) NAMES.put(n[i], COL[i]);
    }

    private ServerPing() {}

    static Info get(String ip) {
        return CACHE.get(ip);
    }

    static Info ping(String ip, boolean force) {
        Info i = CACHE.get(ip);
        long now = System.currentTimeMillis();
        if (i != null && !force && (i.state == 0 || now - i.time < 45_000L)) return i;
        if (i == null) {
            i = new Info();
            CACHE.put(ip, i);
        }
        i.state = 0;
        i.time = now;
        final Info fi = i;
        EX.submit(() -> run(ip, fi));
        return i;
    }

    private static void run(String ip, Info info) {
        try {
            String host = ip.trim();
            int port = 25565;
            boolean explicit = false;
            int c = host.lastIndexOf(':');
            if (c > 0 && c < host.length() - 1 && host.indexOf(':') == c) {
                try {
                    port = Integer.parseInt(host.substring(c + 1));
                    host = host.substring(0, c);
                    explicit = true;
                } catch (NumberFormatException ignored) {
                }
            }
            String connectHost = host;
            if (!explicit) {
                String[] srv = srv(host);
                if (srv != null) {
                    connectHost = srv[0];
                    port = Integer.parseInt(srv[1]);
                }
            }
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(connectHost, port), 3500);
                s.setSoTimeout(4500);
                DataOutputStream out = new DataOutputStream(s.getOutputStream());
                DataInputStream in = new DataInputStream(s.getInputStream());
                ByteArrayOutputStream hb = new ByteArrayOutputStream();
                DataOutputStream h = new DataOutputStream(hb);
                varInt(h, 0);
                varInt(h, 767);
                byte[] hs = host.getBytes(StandardCharsets.UTF_8);
                varInt(h, hs.length);
                h.write(hs);
                h.writeShort(port);
                varInt(h, 1);
                varInt(out, hb.size());
                out.write(hb.toByteArray());
                varInt(out, 1);
                varInt(out, 0);
                out.flush();
                readVarInt(in);
                readVarInt(in);
                int len = readVarInt(in);
                byte[] data = new byte[len];
                in.readFully(data);
                long t0 = System.nanoTime();
                varInt(out, 9);
                varInt(out, 1);
                out.writeLong(t0);
                out.flush();
                long ms = -1;
                try {
                    readVarInt(in);
                    readVarInt(in);
                    in.readLong();
                    ms = (System.nanoTime() - t0) / 1_000_000L;
                } catch (IOException ignored) {
                }
                parse(new String(data, StandardCharsets.UTF_8), info, ms);
            }
        } catch (Throwable e) {
            info.err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            info.state = 2;
        }
        info.time = System.currentTimeMillis();
    }

    private static void parse(String json, Info info, long ms) {
        JsonObject o = JsonParser.parseString(json).getAsJsonObject();
        if (o.has("version")) info.version = str(o.getAsJsonObject("version"), "name");
        if (o.has("players")) {
            JsonObject p = o.getAsJsonObject("players");
            info.online = p.has("online") ? p.get("online").getAsInt() : -1;
            info.max = p.has("max") ? p.get("max").getAsInt() : -1;
            List<String> names = new ArrayList<>();
            if (p.has("sample") && p.get("sample").isJsonArray()) {
                for (JsonElement e : p.getAsJsonArray("sample")) {
                    if (e.isJsonObject()) names.add(str(e.getAsJsonObject(), "name"));
                }
            }
            info.sample = names;
        }
        List<Seg> segs = new ArrayList<>();
        if (o.has("description")) comp(o.get("description"), 0xFFFFFF, false, segs);
        info.motd = lines(segs);
        if (o.has("favicon")) info.favicon = o.get("favicon").getAsString();
        info.ms = ms;
        info.state = 1;
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : "";
    }

    private static void comp(JsonElement el, int color, boolean bold, List<Seg> out) {
        if (el == null || el.isJsonNull()) return;
        if (el.isJsonPrimitive()) {
            legacy(el.getAsString(), color, bold, out);
        } else if (el.isJsonArray()) {
            JsonArray a = el.getAsJsonArray();
            for (JsonElement e : a) comp(e, color, bold, out);
        } else {
            JsonObject o = el.getAsJsonObject();
            int col = color;
            if (o.has("color")) {
                String cs = o.get("color").getAsString();
                if (cs.startsWith("#") && cs.length() == 7) {
                    try {
                        col = Integer.parseInt(cs.substring(1), 16);
                    } catch (NumberFormatException ignored) {
                    }
                } else if (NAMES.containsKey(cs)) col = NAMES.get(cs);
            }
            boolean b = o.has("bold") ? o.get("bold").getAsBoolean() : bold;
            if (o.has("text")) legacy(o.get("text").getAsString(), col, b, out);
            if (o.has("extra") && o.get("extra").isJsonArray()) for (JsonElement e : o.getAsJsonArray("extra")) comp(e, col, b, out);
        }
    }

    private static void legacy(String s, int color, boolean bold, List<Seg> out) {
        StringBuilder sb = new StringBuilder();
        int col = color;
        boolean b = bold;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if ((ch == '§' || ch == '\u00A7') && i + 1 < s.length()) {
                if (sb.length() > 0) {
                    out.add(new Seg(sb.toString(), col, b));
                    sb.setLength(0);
                }
                char k = Character.toLowerCase(s.charAt(++i));
                int idx = "0123456789abcdef".indexOf(k);
                if (idx >= 0) {
                    col = COL[idx];
                    b = false;
                } else if (k == 'l') b = true;
                else if (k == 'r') {
                    col = color;
                    b = bold;
                }
            } else {
                sb.append(ch);
            }
        }
        if (sb.length() > 0) out.add(new Seg(sb.toString(), col, b));
    }

    private static List<List<Seg>> lines(List<Seg> segs) {
        List<List<Seg>> res = new ArrayList<>();
        List<Seg> cur = new ArrayList<>();
        for (Seg s : segs) {
            String[] parts = s.text.split("\n", -1);
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) {
                    res.add(cur);
                    cur = new ArrayList<>();
                }
                if (!parts[i].isEmpty()) cur.add(new Seg(parts[i], s.color, s.bold));
            }
        }
        res.add(cur);
        return res;
    }

    private static String[] srv(String host) {
        try {
            Hashtable<String, String> env = new Hashtable<>();
            env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
            env.put("java.naming.provider.url", "dns:");
            env.put("com.sun.jndi.dns.timeout.retries", "1");
            DirContext ctx = new InitialDirContext(env);
            Attributes at = ctx.getAttributes("_minecraft._tcp." + host, new String[]{"SRV"});
            Attribute a = at.get("srv");
            if (a != null) {
                String[] p = a.get().toString().split(" ");
                return new String[]{p[3].replaceAll("\\.$", ""), p[2]};
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static void varInt(DataOutputStream o, int v) throws IOException {
        while ((v & ~0x7F) != 0) {
            o.writeByte((v & 0x7F) | 0x80);
            v >>>= 7;
        }
        o.writeByte(v);
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int v = 0, sh = 0, b;
        do {
            b = in.readUnsignedByte();
            v |= (b & 0x7F) << sh;
            sh += 7;
            if (sh > 35) throw new IOException("VarInt too big");
        } while ((b & 0x80) != 0);
        return v;
    }
}
