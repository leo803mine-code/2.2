package dev.flr.visuals;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Меню FLR 2.2 в стиле стеклянных клиентов: слева категории с «жидкой» панелью выбора, справа сетка карточек
 * (название, описание, «+» для настроек, переключатель), поиск, всплывающие настройки, выпадающие списки и вкладка плеера.
 */
public class CosmeticsScreen extends Screen {
    private static final int SIDE = 134, MEDIA = 7;
    private static final String VERSION = "2.2";
    private static final String[] TABS = {"Cosmetics", "Effects", "Atmosphere", "Colors", "Utility", "Performance", "HUD", "Media", "Settings"};
    private static final int[] TAB_ICON = {Gfx.STAR, Gfx.SPARK, Gfx.CLOUD, Gfx.DROP, Gfx.GEAR, Gfx.CHIP, Gfx.FRAME, Gfx.NOTE, Gfx.SLIDERS};

    private final List<List<Row>> pages = new ArrayList<>();
    private int tab;
    private Row openRow, ddRow, dragging;
    private List<Row> openSub;
    private float headY = -1, tailY = -1, openAnim, pageAnim = 1f, scroll, scrollT, popAnim, popScroll, popScrollT, ddAnim;
    private long last;
    private int sel;
    private boolean padMode;
    private float px, py, W, H, cx, cw, rtop, rbot;
    private float popX, popY, popW, popH, ddX, ddY, ddW, ddH;
    private int mouseX, mouseY;
    private final TextInput search = new TextInput(32);
    private final List<Row> vis = new ArrayList<>();
    private static KeyMapping capturing;

    public CosmeticsScreen() {
        this(0);
    }

    public CosmeticsScreen(int tab) {
        super(Component.literal("FLR VISUALS"));
        this.tab = Math.max(0, Math.min(TABS.length - 1, tab));
    }

    // ---------------------------------------------------------------- строки
    private static final class Row {
        final String label;
        final int type; // 0 переключатель, 1 список, 2 ползунок, 3 кнопка
        String desc;
        boolean warn, rainbow;
        BooleanSupplier bget; Consumer<Boolean> bset;
        String[] names; IntSupplier iget; IntConsumer iset;
        DoubleSupplier dget; DoubleConsumer dset; double min, max; boolean isInt;
        Runnable action;
        String btn = "Reset";
        Supplier<String> btnSup;
        List<Row> sub;
        String subTitle;
        float anim, hov;
        final float[] box = new float[4], ctl = new float[4], plus = new float[4];
        boolean drawn;

        Row(String label, int type) { this.label = label; this.type = type; }

        Row btn(String b) { this.btn = b; return this; }
        Row desc(String d) { this.desc = d; return this; }
        Row warn(String d) { this.desc = d; this.warn = true; return this; }
        Row rainbow() { this.rainbow = true; return this; }
        Row sub(String title, Row... rows) { this.subTitle = title; this.sub = List.of(rows); return this; }
    }

    private static Row toggle(String l, BooleanSupplier g, Consumer<Boolean> s) {
        Row r = new Row(l, 0); r.bget = g; r.bset = s; r.anim = g.getAsBoolean() ? 1f : 0f; return r;
    }
    private static Row choice(String l, String[] n, IntSupplier g, IntConsumer s) {
        Row r = new Row(l, 1); r.names = n; r.iget = g; r.iset = s; return r;
    }
    private static Row slider(String l, double min, double max, boolean isInt, DoubleSupplier g, DoubleConsumer s) {
        Row r = new Row(l, 2); r.min = min; r.max = max; r.isInt = isInt; r.dget = g; r.dset = s; return r;
    }
    private static Row button(String l, Runnable a) {
        Row r = new Row(l, 3); r.action = a; return r;
    }
    private static Row key(String l, KeyMapping km) {
        Row r = new Row(l, 3);
        r.action = () -> capturing = km;
        r.btnSup = () -> capturing == km ? Tr.tr("Press a key...") : km.getTranslatedKeyMessage().getString();
        return r;
    }

    private static void bindCaptured(com.mojang.blaze3d.platform.InputConstants.Key k) {
        capturing.setKey(k);
        KeyMapping.resetMapping();
        Minecraft.getInstance().options.save();
        capturing = null;
    }

    private static Row msgChoice() {
        return choice("Messages", Config.MSG_NAMES, () -> Config.msgMode, v -> Config.msgMode = v);
    }

    @Override
    protected void init() {
        if (!pages.isEmpty()) return;
        pages.add(List.of(
                toggle("Wings", () -> Config.wings, v -> Config.wings = v).desc("Animated wings on your back").sub("Wing settings",
                        choice("Wing type", Config.WING_NAMES, () -> Config.wingStyle, v -> Config.wingStyle = v),
                        slider("Size", 0.5, 1.6, false, () -> Config.wingSize, v -> Config.wingSize = v),
                        slider("Opacity", 0.2, 1.0, false, () -> Config.wingAlpha, v -> Config.wingAlpha = v),
                        slider("Angle", -25, 35, false, () -> Config.wingAngle, v -> Config.wingAngle = v),
                        slider("Gap between wings", 0, 0.15, false, () -> Config.wingGap, v -> Config.wingGap = v),
                        slider("Height", -0.2, 0.2, false, () -> Config.wingHeight, v -> Config.wingHeight = v),
                        slider("Distance from back", -0.05, 0.2, false, () -> Config.wingDepth, v -> Config.wingDepth = v),
                        slider("Flap amount", 0, 2, false, () -> Config.wingFlap, v -> Config.wingFlap = v),
                        slider("Flap speed", 0.2, 3.0, false, () -> Config.speed, v -> Config.speed = v),
                        choice("Colour mode", Config.WING_COLOR_NAMES, () -> Config.wingColorMode, v -> Config.wingColorMode = v),
                        slider("Hue", 0, 1, false, () -> Config.wingHue, v -> Config.wingHue = v).rainbow(),
                        slider("Saturation", 0, 1, false, () -> Config.wingSat, v -> Config.wingSat = v),
                        slider("Brightness", 0.2, 1, false, () -> Config.wingBri, v -> Config.wingBri = v)),
                toggle("Halo", () -> Config.halo, v -> Config.halo = v).desc("Glowing ring above the head").sub("Halo settings",
                        slider("Size", 0.6, 2.0, false, () -> Config.haloSize, v -> Config.haloSize = v),
                        slider("Height", -0.1, 0.3, false, () -> Config.haloHeight, v -> Config.haloHeight = v),
                        choice("Colour mode", Config.COLOR_NAMES, () -> Config.haloColorMode, v -> Config.haloColorMode = v),
                        slider("Hue", 0, 1, false, () -> Config.haloHue, v -> Config.haloHue = v).rainbow(),
                        slider("Saturation", 0, 1, false, () -> Config.haloSat, v -> Config.haloSat = v),
                        slider("Brightness", 0.2, 1, false, () -> Config.haloBri, v -> Config.haloBri = v)),
                toggle("Cape", () -> Config.cape, v -> Config.cape = v).desc("Narrow flowing cape").sub("Cape settings",
                        slider("Length", 0.5, 1.6, false, () -> Config.capeLength, v -> Config.capeLength = v),
                        slider("Width", 0.5, 1.6, false, () -> Config.capeWidth, v -> Config.capeWidth = v),
                        slider("Sway", 0, 2, false, () -> Config.capeSway, v -> Config.capeSway = v),
                        choice("Colour mode", Config.CAPE_COLOR_NAMES, () -> Config.capeColorMode, v -> Config.capeColorMode = v),
                        slider("Hue (top)", 0, 1, false, () -> Config.capeHue, v -> Config.capeHue = v).rainbow(),
                        slider("Hue (bottom)", 0, 1, false, () -> Config.capeHue2, v -> Config.capeHue2 = v).rainbow(),
                        slider("Saturation", 0, 1, false, () -> Config.capeSat, v -> Config.capeSat = v),
                        slider("Brightness", 0.2, 1, false, () -> Config.capeBri, v -> Config.capeBri = v)),
                toggle("Jacket", () -> Config.jacket, v -> Config.jacket = v).desc("Six styles: puffer, bomber, hoodie, biker...").sub("Jacket settings",
                        choice("Style", Config.JACKET_NAMES, () -> Config.jacketStyle, v -> Config.jacketStyle = v),
                        choice("Colour mode", Config.JACKET_COLOR_NAMES, () -> Config.jacketColorMode, v -> Config.jacketColorMode = v),
                        slider("Hue", 0, 1, false, () -> Config.jacketHue, v -> Config.jacketHue = v).rainbow(),
                        slider("Saturation", 0, 1, false, () -> Config.jacketSat, v -> Config.jacketSat = v),
                        slider("Brightness", 0.2, 1, false, () -> Config.jacketBri, v -> Config.jacketBri = v)),
                choice("Pet", Config.PET_NAMES, () -> Config.pet, v -> Config.pet = v).desc("Smooth animated companion").sub("Pet settings",
                        slider("Pet size", 0.5, 1.5, false, () -> Config.petSize, v -> Config.petSize = v),
                        choice("Side", Config.SIDE_NAMES, () -> Config.petSide, v -> Config.petSide = v)),
                choice("Hat", Config.HAT_NAMES, () -> Config.hat, v -> Config.hat = v),
                choice("Back item", Config.BACK_NAMES, () -> Config.backItem, v -> Config.backItem = v),
                toggle("Show on other players", () -> Config.others, v -> Config.others = v),
                toggle("Show on invisible players", () -> Config.showInvisible, v -> Config.showInvisible = v)
                        .warn("At your own risk: may break server rules")));

        pages.add(List.of(
                toggle("Aura", () -> Config.aura, v -> Config.aura = v).desc("Soft particles around you"),
                toggle("Trail", () -> Config.trail, v -> Config.trail = v).desc("Particle trail while moving"),
                toggle("Hit sparks", () -> Config.hitSparks, v -> Config.hitSparks = v).desc("Sparks when you hit"),
                toggle("Ambient fireflies", () -> Config.ambient, v -> Config.ambient = v).desc("Fireflies in the air"),
                choice("Particle type", Config.PARTICLE_NAMES, () -> Config.particleType, v -> Config.particleType = v),
                slider("Effect scale", 0.5, 2.0, false, () -> Config.scale, v -> Config.scale = v)));

        pages.add(List.of(
                slider("Fog tint", 0, 1, false, () -> Config.fogTint, v -> Config.fogTint = v).desc("Tints the fog with the theme colour"),
                slider("Fog density", 0, 1, false, () -> Config.fogDensity, v -> Config.fogDensity = v).desc("Closer, thicker fog"),
                choice("Weather", Config.WEATHER_NAMES, () -> Config.weather, v -> Config.weather = v).desc("Own particles over the screen"),
                slider("Weather amount", 0.1, 1, false, () -> Config.weatherAmount, v -> Config.weatherAmount = v),
                toggle("Colour sky", () -> Config.sky, v -> Config.sky = v).desc("Gradient dome in the overworld").sub("Sky settings",
                        choice("Colour mode", Config.SKY_NAMES, () -> Config.skyMode, v -> Config.skyMode = v),
                        slider("Hue", 0, 1, false, () -> Config.skyHue, v -> Config.skyHue = v).rainbow(),
                        slider("Sky strength", 0.1, 1, false, () -> Config.skyAlpha, v -> Config.skyAlpha = v))));

        pages.add(List.of(
                choice("Theme", Config.THEME_NAMES, () -> Config.theme, v -> Config.theme = v).desc("Used by wings, halo, cape, fog, HUD"),
                slider("Custom hue", 0, 1, false, () -> Config.hue, v -> Config.hue = v).rainbow(),
                slider("Custom saturation", 0, 1, false, () -> Config.themeSat, v -> Config.themeSat = v),
                choice("Menu background", Config.BG_NAMES, () -> Config.bgStyle, v -> Config.bgStyle = v).desc("Main menu and loading screens")));

        pages.add(List.of(
                toggle("Target ESP", () -> Config.targetEsp, v -> Config.targetEsp = v).desc("Rotating reticle on the target").sub("Target ESP settings",
                        choice("Style", Config.ESP_NAMES, () -> Config.espStyle, v -> Config.espStyle = v),
                        slider("Reticle size", 0.6, 1.6, false, () -> Config.espSize, v -> Config.espSize = v)),
                choice("Crosshair", Config.CROSS_NAMES, () -> Config.crosshair, v -> Config.crosshair = v).desc("Smooth custom crosshair"),
                toggle("Coordinates HUD", () -> Config.coords, v -> Config.coords = v).desc("XYZ and direction"),
                key("Zoom key", FlrKeys.ZOOM),
                toggle("Auto Swap", () -> Config.autoSwap, v -> Config.autoSwap = v).desc("Totem to offhand when falling").sub("Auto Swap settings",
                        key("Keybind", FlrKeys.AUTOSWAP),
                        slider("Fall height (blocks)", 5, 20, true, () -> Config.swapHeight, v -> Config.swapHeight = (int) Math.round(v)),
                        msgChoice()),
                toggle("Armor Alert", () -> Config.armorAlert, v -> Config.armorAlert = v).desc("Warns when armor is about to break").sub("Armor Alert settings",
                        slider("Warn below (%)", 5, 50, true, () -> Config.armorPercent, v -> Config.armorPercent = (int) Math.round(v)),
                        msgChoice()),
                msgChoice().desc("Where function messages are shown")));

        pages.add(List.of(
                toggle("Auto performance", () -> Config.autoPerf, v -> Config.autoPerf = v).desc("Lowers detail when FPS is low"),
                toggle("FPS counter", () -> Config.hud, v -> Config.hud = v),
                slider("Particle budget", 0, 100, true, () -> Config.particleBudget, v -> Config.particleBudget = (int) Math.round(v)),
                slider("Max distance", 8, 96, true, () -> Config.maxDistance, v -> Config.maxDistance = (int) Math.round(v)),
                slider("Max players", 1, 32, true, () -> Config.maxPlayers, v -> Config.maxPlayers = (int) Math.round(v)),
                slider("Detail distance", 8, 64, true, () -> Config.lodDistance, v -> Config.lodDistance = (int) Math.round(v)).desc("Simple models farther than this")));

        pages.add(List.of(
                button("Move HUD", () -> {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.level == null) Notify.show(Tr.tr("Join a world, then open chat to move the HUD"), 0xFFC94D);
                    else mc.setScreen(new ChatScreen(""));
                }).btn("Open chat").desc("Drag widgets while chat is open"),
                button("Reset HUD positions", HudLayout::resetAll).desc("Put every widget back"),
                toggle("Watermark", () -> Config.hudWatermark, v -> Config.hudWatermark = v).desc("Name, FPS and ping"),
                toggle("Target HUD", () -> Config.hudTarget, v -> Config.hudTarget = v).desc("Name and health of your target"),
                toggle("Effects list", () -> Config.hudPotions, v -> Config.hudPotions = v).desc("Active potion effects"),
                toggle("Armor HUD", () -> Config.hudArmor, v -> Config.hudArmor = v).desc("Worn armor and durability"),
                toggle("Hotkeys list", () -> Config.hudHotkeys, v -> Config.hudHotkeys = v).desc("FLR keybinds and states"),
                toggle("Cooldowns", () -> Config.hudCooldowns, v -> Config.hudCooldowns = v).desc("Pearl, apples, shield..."),
                toggle("Item counter", () -> Config.hudItems, v -> Config.hudItems = v).desc("Totems, apples, pearls..."),
                toggle("Media player", () -> Config.hudMedia, v -> Config.hudMedia = v).desc("Now playing widget"),
                toggle("Stacked notifications", () -> Config.notifyStack, v -> Config.notifyStack = v).desc("Messages stack at the bottom right"),
                slider("HUD opacity", 0.3, 1.0, false, () -> Config.hudAlpha, v -> Config.hudAlpha = v)));

        pages.add(List.of());

        pages.add(List.of(
                toggle("FLR Visuals enabled", () -> Config.master, v -> Config.master = v).desc("Master switch"),
                choice("Language", Config.LANG_NAMES, () -> Config.lang, v -> Config.lang = v),
                button("Account switcher", () -> Minecraft.getInstance().setScreen(new AccountScreen(this))).btn("Open").desc("Switch offline nickname"),
                toggle("Custom menu style", () -> Config.menuStyle, v -> Config.menuStyle = v).desc("Own main menu, servers and loading"),
                key("Open menu key", FlrKeys.MENU),
                key("Play / pause key", FlrKeys.SOUND),
                toggle("Gamepad support", () -> Config.gamepad, v -> Config.gamepad = v).desc("D-pad, A/B/X buttons, LB/RB tabs"),
                button("Reset to defaults", Config::reset)));
    }

    // ---------------------------------------------------------------- утилиты
    private static boolean in(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private List<Row> pageRows() {
        if (!search.text.isBlank()) {
            String q = search.text.toLowerCase(Locale.ROOT).trim();
            List<Row> res = new ArrayList<>();
            for (List<Row> p : pages) {
                for (Row r : p) {
                    if (r.label.toLowerCase(Locale.ROOT).contains(q) || Tr.tr(r.label).toLowerCase(Locale.ROOT).contains(q)) res.add(r);
                }
            }
            return res;
        }
        return pages.get(tab);
    }

    private List<Row> cur() {
        return openSub != null ? openSub : pageRows();
    }

    private boolean media() {
        return tab == MEDIA && search.text.isBlank();
    }

    private void resetPage() {
        scroll = 0; scrollT = 0; pageAnim = 0f; sel = 0;
    }

    private void setTab(int i) {
        if (tab == i && openSub == null) return;
        tab = i; openRow = null; openSub = null; ddRow = null; resetPage();
    }

    private void openSettings(Row r) {
        if (r.sub == null) return;
        openRow = r; openSub = r.sub; popScroll = 0; popScrollT = 0; sel = 0; ddRow = null;
    }

    private void closeSettings() {
        openRow = null; openSub = null; ddRow = null; sel = 0;
    }

    private String valueText(Row r) {
        if (r.type == 1) return Tr.tr(r.names[Math.max(0, Math.min(r.names.length - 1, r.iget.getAsInt()))]);
        double v = r.dget.getAsDouble();
        return r.isInt ? String.valueOf(Math.round(v)) : (r.max - r.min >= 10 ? String.format(Locale.ROOT, "%.1f", v) : String.format(Locale.ROOT, "%.2f", v));
    }

    // ---------------------------------------------------------------- рендер
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        mouseX = mx; mouseY = my;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openAnim += (1f - openAnim) * Gfx.k(dt, 11f);
        pageAnim = Math.min(1f, pageAnim + dt * 3.4f);
        popAnim += ((openSub != null ? 1f : 0f) - popAnim) * Gfx.k(dt, 16f);
        ddAnim += ((ddRow != null ? 1f : 0f) - ddAnim) * Gfx.k(dt, 20f);
        float e = Gfx.ease(openAnim);
        int acc = Config.color() | 0xFF000000;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) renderBlurredBackground(pt);
        if (mc.level != null) Backdrop.tint(g, width, height, e);
        else Backdrop.draw(g, width, height);
        Gfx.use(g);

        W = Math.min(560, width - 10);
        H = Math.min(336, height - 10);
        px = (width - W) / 2f;
        py = (height - H) / 2f + (1f - e) * 16;
        cx = px + SIDE + 22;
        cw = W - SIDE - 34;
        rtop = py + 62;
        rbot = py + H - 16;

        // стеклянная панель
        Gfx.glow(px, py + 10, W, H, 24, 40, Gfx.rgba(0x000000, 0.55f * e));
        Gfx.glow(px, py, W, H, 24, 22, Gfx.a(acc, 0.10f * e));
        Gfx.rr4(px, py, W, H, 24, Gfx.rgba(0x2C2450, 0.80f * e), Gfx.rgba(0x1C1636, 0.82f * e), Gfx.rgba(0x16112C, 0.86f * e), Gfx.rgba(0x0E0B20, 0.90f * e));
        Gfx.orb(px + 70, py + 40, 150, Gfx.a(acc, 0.16f * e));
        Gfx.ring(px, py, W, H, 24, 1f, Gfx.rgba(0xFFFFFF, 0.16f * e));
        Gfx.rr(px + 9, py + 9, SIDE, H - 18, 18, Gfx.rgba(0x000000, 0.22f * e));
        Gfx.ring(px + 9, py + 9, SIDE, H - 18, 18, 1f, Gfx.rgba(0xFFFFFF, 0.06f * e));

        // шапка боковой панели
        Ui.logo(g, px + 20, py + 17, 26, e);
        Gfx.use(g);
        Gfx.text("FLR", px + 52, py + 15, 13f, Gfx.rgba(0xFFFFFF, e), true);
        Gfx.text("Visuals " + VERSION, px + 52, py + 30, Ui.BODY - 1.2f, Gfx.rgba(0xFFFFFF, 0.5f * e), false);

        // жидкая панель выбора
        float itemH = 27, step = 30, listY = py + 58;
        float tgt = listY + tab * step;
        if (headY < 0) { headY = tgt; tailY = tgt; }
        headY += (tgt - headY) * Gfx.k(dt, 24f);
        tailY += (tgt - tailY) * Gfx.k(dt, 9f);
        float top = Math.min(headY, tailY), bot = Math.max(headY, tailY) + itemH;
        float stretch = Gfx.clamp01((bot - top - itemH) / 40f);
        float lx = px + 15 + stretch * 3, lw = SIDE - 12 - stretch * 6;
        Gfx.glow(lx, top, lw, bot - top, 13, 14, Gfx.a(acc, 0.30f * e));
        Gfx.rr4(lx, top, lw, bot - top, 13, Gfx.a(Gfx.mix(acc, 0xFFFFFFFF, 0.25f), 0.60f * e), Gfx.a(acc, 0.42f * e), Gfx.a(acc, 0.28f * e), Gfx.a(Gfx.shift(acc, 0.06f, 0f, -0.1f), 0.34f * e));
        Gfx.rr(lx + 5, top + 2, lw - 10, Math.min(9, (bot - top) * 0.35f), 5, Gfx.rgba(0xFFFFFF, 0.20f * e));
        Gfx.ring(lx, top, lw, bot - top, 13, 1f, Gfx.rgba(0xFFFFFF, 0.38f * e));

        for (int i = 0; i < TABS.length; i++) {
            float ty = listY + i * step;
            boolean h = in(mx, my, px + 15, ty, SIDE - 12, itemH) && openSub == null;
            boolean on = i == tab && search.text.isBlank();
            Gfx.icon(TAB_ICON[i], px + 32, ty + itemH / 2f, 13, Gfx.rgba(0xFFFFFF, e * (on ? 1f : h ? 0.9f : 0.62f)));
            Gfx.textMid(Tr.tr(TABS[i]), px + 46, ty + itemH / 2f, Ui.BODY + 0.2f, Gfx.rgba(0xFFFFFF, e * (on ? 1f : h ? 0.95f : 0.7f)), on);
            int cnt = i == MEDIA ? MediaPlayer.LIST.size() : pages.get(i).size();
            Gfx.textR(String.valueOf(cnt), px + SIDE - 6, ty + itemH / 2f, Ui.BODY - 1.4f, Gfx.rgba(0xFFFFFF, e * 0.35f), false);
        }

        // статус
        float sy = py + H - 40;
        boolean on = Config.master, sh = in(mx, my, px + 15, sy, SIDE - 12, 24);
        Gfx.rr(px + 15, sy, SIDE - 12, 24, 12, Gfx.rgba(0xFFFFFF, (sh ? 0.14f : 0.08f) * e));
        float pulse = 0.65f + 0.35f * (float) Math.sin(now / 3.0e8);
        int sc = on ? 0xFF4CE08A : 0xFFE0524C;
        Gfx.glow(px + 24, sy + 8, 8, 8, 4, 6, Gfx.a(sc, 0.5f * pulse * e));
        Gfx.circle(px + 28, sy + 12, 3.2f, Gfx.a(sc, e));
        Gfx.textMid(Tr.tr(on ? "ACTIVE" : "OFF").toUpperCase(Locale.ROOT), px + 38, sy + 12, Ui.BODY - 0.6f, Gfx.rgba(on ? 0xCFFFE3 : 0xFFCFCF, e), true);

        // заголовок и поиск
        boolean searching = !search.text.isBlank();
        String title = searching ? Tr.tr("Search") : Tr.tr(TABS[tab]);
        Gfx.text(title, cx, py + 19, 17f, Gfx.rgba(0xFFFFFF, e), true);
        int count = media() ? MediaPlayer.LIST.size() : pageRows().size();
        Gfx.text(searching ? Tr.fmt("%s results", count) : Tr.fmt("%s items", count), cx + 1, py + 40, Ui.BODY - 1f, Gfx.rgba(0xFFFFFF, 0.45f * e), false);
        float sw = Math.min(170, cw * 0.42f);
        search.draw(cx + cw - sw, py + 17, sw, 22, Tr.tr("Search..."), acc & 0xFFFFFF);
        Gfx.icon(Gfx.SEARCH, cx + cw - 14, py + 28, 10, 0x77FFFFFF);
        Gfx.rect(cx, py + 52, cw, 1, Gfx.rgba(0xFFFFFF, 0.07f * e));

        vis.clear();
        if (media()) {
            MediaUi.full(g, cx, rtop - 2, cw, rbot - rtop + 2, mx, my, dt);
        } else {
            grid(g, mx, my, dt, e, acc);
        }
        Gfx.use(g);

        String hint = padMode ? "A: select  X: settings  B: back  LB/RB: tabs" : "Click + for settings  ·  Right-click a card for settings";
        if (!media()) Gfx.text(Gfx.fit(Tr.tr(hint), cw, Ui.BODY - 1.2f, false), cx, py + H - 15, Ui.BODY - 1.2f, Gfx.rgba(0xFFFFFF, 0.3f * e), false);

        if (popAnim > 0.01f) popup(g, mx, my, dt, e, acc);
        if (ddAnim > 0.01f && ddRow != null) dropdown(mx, my, e, acc);
        Gfx.end();
    }

    // ---------------------------------------------------------------- сетка карточек
    private void grid(GuiGraphics g, int mx, int my, float dt, float e, int acc) {
        List<Row> rows = pageRows();
        int cols = cw >= 340 ? 2 : 1;
        float gap = 9, cardW = (cw - (cols - 1) * gap) / cols, cardH = 56;
        int nrows = (rows.size() + cols - 1) / cols;
        float total = nrows * (cardH + gap);
        float maxS = Math.max(0, total - (rbot - rtop));
        scrollT = Math.max(0f, Math.min(maxS, scrollT));
        scroll += (scrollT - scroll) * Gfx.k(dt, 16f);
        Gfx.scissor(cx - 8, rtop - 4, cw + 16, rbot - rtop + 8);
        boolean block = openSub != null || ddRow != null;
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            int c = i % cols, rw = i / cols;
            float x = cx + c * (cardW + gap), y = rtop - scroll + rw * (cardH + gap);
            r.drawn = false;
            if (y + cardH < rtop - 6 || y > rbot + 6) continue;
            float a = Gfx.ease(pageAnim * 1.8f - (rw * cols + c) * 0.08f) * e;
            float yy = y + (1f - a / Math.max(e, 0.001f)) * 10f;
            boolean hv = !block && !padMode && in(mx, my, x, yy, cardW, cardH) && my >= rtop && my < rbot;
            boolean sl = padMode && openSub == null && i == sel;
            card(r, x, yy, cardW, cardH, a, dt, hv || r == dragging, sl, acc, false);
            vis.add(r);
        }
        Gfx.unscissor();
        Gfx.use(g);
        if (maxS > 0) {
            float th = rbot - rtop, bh = Math.max(18, th * th / total), by = rtop + (th - bh) * (scroll / maxS);
            Gfx.rr(px + W - 10, by, 3, bh, 1.5f, Gfx.rgba(0xFFFFFF, 0.22f * e));
        }
        if (rows.isEmpty()) Gfx.textC(Tr.tr("Nothing found"), cx + cw / 2f, rtop + 40, 11f, Gfx.rgba(0xFFFFFF, 0.5f * e), false);
    }

    private void switchCtl(Row r, float x, float y, float a, float dt, int acc) {
        r.anim += ((r.bget.getAsBoolean() ? 1f : 0f) - r.anim) * Gfx.k(dt, 15f);
        float t = Gfx.ease(r.anim), w = 32, h = 16;
        r.ctl[0] = x; r.ctl[1] = y; r.ctl[2] = w; r.ctl[3] = h;
        if (t > 0.02f) Gfx.glow(x, y, w, h, 8, 8, Gfx.a(acc, 0.35f * t * a));
        Gfx.rr(x, y, w, h, 8, Gfx.a(Gfx.mix(0xFF2A2740, acc, t), a));
        Gfx.ring(x, y, w, h, 8, 1f, Gfx.rgba(0xFFFFFF, (0.12f + 0.2f * t) * a));
        float kx = x + 8 + t * (w - 16);
        Gfx.circle(kx, y + h / 2f, 5.4f, Gfx.rgba(Gfx.mix(0xFFB4B8D2, 0xFFFFFFFF, t) & 0xFFFFFF, a));
    }

    private void plusBtn(Row r, float x, float y, float a, boolean hv, int acc) {
        r.plus[0] = x; r.plus[1] = y; r.plus[2] = 18; r.plus[3] = 18;
        boolean h = hv && in(mouseX, mouseY, x, y, 18, 18);
        Gfx.circle(x + 9, y + 9, 9, Gfx.rgba(0xFFFFFF, (h ? 0.22f : 0.10f) * a));
        if (h) Gfx.circleRing(x + 9, y + 9, 9, 1f, Gfx.a(acc, 0.9f * a));
        Gfx.icon(Gfx.PLUS, x + 9, y + 9, 9, Gfx.rgba(0xFFFFFF, (h ? 1f : 0.75f) * a));
    }

    /** Карточка функции: акцентная полоска слева, название, описание, «+» и переключатель/значение. */
    private void card(Row r, float x, float y, float w, float h, float a, float dt, boolean hv, boolean selected, int acc, boolean popupRow) {
        r.box[0] = x; r.box[1] = y; r.box[2] = w; r.box[3] = h; r.drawn = true;
        r.hov += ((hv || selected ? 1f : 0f) - r.hov) * Gfx.k(dt, 18f);
        boolean on = r.type == 0 && r.bget.getAsBoolean();
        float hh = r.hov;
        Gfx.glow(x, y + 2, w, h, 13, 9, Gfx.rgba(0x000000, 0.25f * a));
        int wA = Gfx.rgba(0xFFFFFF, (0.09f + 0.05f * hh) * a), wB = Gfx.rgba(0xFFFFFF, (0.04f + 0.03f * hh) * a);
        if (on) {
            wA = Gfx.mix(wA, Gfx.a(acc, 0.30f * a), 0.7f);
            wB = Gfx.mix(wB, Gfx.a(acc, 0.12f * a), 0.7f);
        }
        Gfx.rr4(x, y, w, h, 13, wA, wB, wB, wB);
        Gfx.ring(x, y, w, h, 13, 1f, on || selected ? Gfx.a(acc, 0.6f * a) : Gfx.rgba(0xFFFFFF, (0.10f + 0.10f * hh) * a));
        Gfx.rr(x + 9, y + 13, 3, h - 26, 1.5f, on ? Gfx.a(acc, a) : Gfx.rgba(0xFFFFFF, 0.22f * a));

        float tx = x + 20, right = x + w - 12;
        String t = Tr.tr(r.label);
        Gfx.text(Gfx.fit(t, w - 120, 10.6f, true), tx, y + 10, 10.6f, Gfx.rgba(0xFFFFFF, a), true);
        String d = r.desc != null ? Tr.tr(r.desc) : null;
        if (d != null) Gfx.text(Gfx.fit(d, w - 34, 8.7f, false), tx, y + 25, 8.7f, r.warn ? Gfx.rgba(0xFF9B4D, a) : Gfx.rgba(0xFFFFFF, 0.52f * a), false);

        float cy = y + 10;
        switch (r.type) {
            case 0 -> {
                float sx = right - 32;
                switchCtl(r, sx, cy, a, dt, acc);
                if (r.sub != null) plusBtn(r, sx - 24, cy - 1, a, hv, acc);
            }
            case 1 -> {
                String v = valueText(r);
                float cwid = Gfx.textW(v, Ui.BODY - 0.4f, true) + 30;
                float sx = right - cwid;
                boolean hc = hv && in(mouseX, mouseY, sx, cy - 1, cwid, 18);
                r.ctl[0] = sx; r.ctl[1] = cy - 1; r.ctl[2] = cwid; r.ctl[3] = 18;
                Gfx.rr(sx, cy - 1, cwid, 18, 9, Gfx.a(acc, (hc || ddRow == r ? 0.45f : 0.28f) * a));
                Gfx.ring(sx, cy - 1, cwid, 18, 9, 1f, Gfx.a(acc, 0.65f * a));
                Gfx.textMid(v, sx + 10, cy + 8, Ui.BODY - 0.4f, Gfx.rgba(0xFFFFFF, a), true);
                Gfx.icon(ddRow == r ? Gfx.CHEV_U : Gfx.CHEV_D, sx + cwid - 10, cy + 8, 8, Gfx.rgba(0xFFFFFF, 0.85f * a));
                if (r.sub != null) plusBtn(r, sx - 24, cy - 1, a, hv, acc);
            }
            case 2 -> {
                String v = valueText(r);
                Gfx.textR(v, right, cy + 7, Ui.BODY, Gfx.rgba(0xFFFFFF, 0.8f * a), true);
                if (r.sub != null) plusBtn(r, right - Gfx.textW(v, Ui.BODY, true) - 28, cy - 1, a, hv, acc);
                slider(r, x + 20, y + h - 15, w - 38, a, acc);
            }
            default -> {
                String bl = r.btnSup != null ? r.btnSup.get() : Tr.tr(r.btn);
                float cwid = Math.max(70, Gfx.textW(bl, Ui.BODY, false) + 22), sx = right - cwid;
                boolean cap = capturing != null && r.btnSup != null && bl.equals(Tr.tr("Press a key..."));
                boolean hc = hv && in(mouseX, mouseY, sx, cy - 1, cwid, 18);
                r.ctl[0] = sx; r.ctl[1] = cy - 1; r.ctl[2] = cwid; r.ctl[3] = 18;
                Gfx.rr(sx, cy - 1, cwid, 18, 9, cap ? Gfx.a(acc, 0.9f * a) : Gfx.rgba(0xFFFFFF, (hc ? 0.24f : 0.13f) * a));
                Gfx.ring(sx, cy - 1, cwid, 18, 9, 1f, Gfx.rgba(0xFFFFFF, 0.18f * a));
                Gfx.textC(bl, sx + cwid / 2f, cy + 8, Ui.BODY, Gfx.rgba(0xFFFFFF, a), false);
            }
        }
    }

    private void slider(Row r, float x, float y, float w, float a, int acc) {
        double v = r.dget.getAsDouble();
        float f = Gfx.clamp01((float) ((v - r.min) / (r.max - r.min)));
        r.ctl[0] = x; r.ctl[1] = y - 6; r.ctl[2] = w; r.ctl[3] = 14;
        if (r.rainbow) {
            int n = 14;
            for (int i = 0; i < n; i++) {
                float t0 = i / (float) n, t1 = (i + 1) / (float) n;
                Gfx.quad(x + w * t0, y - 1.5f, Gfx.a(Gfx.hsb(t0, 0.75f, 1f), a), x + w * t1, y - 1.5f, Gfx.a(Gfx.hsb(t1, 0.75f, 1f), a),
                        x + w * t1, y + 1.5f, Gfx.a(Gfx.hsb(t1, 0.75f, 1f), a), x + w * t0, y + 1.5f, Gfx.a(Gfx.hsb(t0, 0.75f, 1f), a));
            }
        } else {
            Gfx.rr(x, y - 2, w, 4, 2, Gfx.rgba(0xFFFFFF, 0.14f * a));
            Gfx.rrH(x, y - 2, Math.max(4, w * f), 4, 2, Gfx.a(acc, 0.55f * a), Gfx.a(acc, a));
        }
        float kx = x + w * f;
        Gfx.glow(kx - 5, y - 5, 10, 10, 5, 7, Gfx.a(acc, 0.45f * a));
        Gfx.circle(kx, y, 5, Gfx.rgba(0xFFFFFF, a));
    }

    // ---------------------------------------------------------------- всплывающие настройки
    private void popup(GuiGraphics g, int mx, int my, float dt, float e, int acc) {
        float a = Gfx.ease(popAnim) * e;
        Gfx.rr(cx - 12, rtop - 8, cw + 24, rbot - rtop + 14, 14, Gfx.rgba(0x05030C, 0.58f * a));
        List<Row> rows = openSub != null ? openSub : List.of();
        float rowsH = 0;
        for (Row r : rows) rowsH += r.type == 2 ? 38 : 30;
        popW = Math.min(250, cw);
        popH = Math.min(rowsH + 56, rbot - rtop + 6);
        popX = cx + (cw - popW) / 2f;
        popY = rtop - 4 + (rbot - rtop + 6 - popH) / 2f + (1f - Gfx.outBack(popAnim)) * 18;
        Gfx.glow(popX, popY + 6, popW, popH, 18, 26, Gfx.rgba(0x000000, 0.6f * a));
        Gfx.rr4(popX, popY, popW, popH, 18, Gfx.rgba(0x30285A, 0.96f * a), Gfx.rgba(0x201A42, 0.97f * a), Gfx.rgba(0x181334, 0.97f * a), Gfx.rgba(0x110E26, 0.98f * a));
        Gfx.ring(popX, popY, popW, popH, 18, 1f, Gfx.rgba(0xFFFFFF, 0.2f * a));
        if (openRow != null) Gfx.text(Gfx.fit(Tr.tr(openRow.subTitle), popW - 60, 11.5f, true), popX + 16, popY + 13, 11.5f, Gfx.rgba(0xFFFFFF, a), true);
        boolean ch = in(mx, my, popX + popW - 30, popY + 9, 20, 20);
        Gfx.circle(popX + popW - 20, popY + 19, 10, Gfx.rgba(0xFFFFFF, (ch ? 0.22f : 0.1f) * a));
        Gfx.icon(Gfx.CLOSE, popX + popW - 20, popY + 19, 9, Gfx.rgba(0xFFFFFF, a));
        Gfx.rect(popX + 14, popY + 36, popW - 28, 1, Gfx.rgba(0xFFFFFF, 0.1f * a));

        float vTop = popY + 40, vBot = popY + popH - 8;
        float maxS = Math.max(0, rowsH - (vBot - vTop));
        popScrollT = Math.max(0, Math.min(maxS, popScrollT));
        popScroll += (popScrollT - popScroll) * Gfx.k(dt, 16f);
        Gfx.scissor(popX, vTop, popW, vBot - vTop);
        float y = vTop - popScroll;
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            float h = r.type == 2 ? 38 : 30;
            r.drawn = false;
            if (y + h >= vTop - 2 && y <= vBot + 2) {
                boolean hv = ddRow == null && !padMode && in(mx, my, popX, y, popW, h) && my >= vTop && my < vBot;
                boolean sl = padMode && i == sel;
                popRow(r, popX + 8, y, popW - 16, h, a, dt, hv || r == dragging, sl, acc);
            }
            y += h;
        }
        Gfx.unscissor();
        Gfx.use(g);
    }

    private void popRow(Row r, float x, float y, float w, float h, float a, float dt, boolean hv, boolean sl, int acc) {
        r.box[0] = x; r.box[1] = y; r.box[2] = w; r.box[3] = h; r.drawn = true;
        r.hov += ((hv || sl ? 1f : 0f) - r.hov) * Gfx.k(dt, 18f);
        if (r.hov > 0.02f) Gfx.rr(x, y + 1, w, h - 2, 9, Gfx.rgba(0xFFFFFF, 0.08f * r.hov * a));
        if (sl) Gfx.ring(x, y + 1, w, h - 2, 9, 1f, Gfx.a(acc, 0.7f * a));
        float cy = y + (r.type == 2 ? 12 : h / 2f), right = x + w - 8;
        Gfx.textMid(Gfx.fit(Tr.tr(r.label), w - 110, Ui.BODY, false), x + 9, cy, Ui.BODY, Gfx.rgba(0xFFFFFF, 0.92f * a), false);
        switch (r.type) {
            case 0 -> switchCtl(r, right - 32, cy - 8, a, dt, acc);
            case 1 -> {
                String v = valueText(r);
                float cwid = Math.max(60, Gfx.textW(v, Ui.BODY - 0.4f, true) + 28), sx = right - cwid;
                boolean hc = hv && in(mouseX, mouseY, sx, cy - 9, cwid, 18);
                r.ctl[0] = sx; r.ctl[1] = cy - 9; r.ctl[2] = cwid; r.ctl[3] = 18;
                Gfx.rr(sx, cy - 9, cwid, 18, 9, Gfx.a(acc, (hc || ddRow == r ? 0.45f : 0.26f) * a));
                Gfx.ring(sx, cy - 9, cwid, 18, 9, 1f, Gfx.a(acc, 0.6f * a));
                Gfx.textMid(v, sx + 9, cy, Ui.BODY - 0.4f, Gfx.rgba(0xFFFFFF, a), true);
                Gfx.icon(Gfx.CHEV_D, sx + cwid - 9, cy, 8, Gfx.rgba(0xFFFFFF, 0.85f * a));
            }
            case 2 -> {
                Gfx.textR(valueText(r), right, cy, Ui.BODY, Gfx.rgba(0xFFFFFF, 0.8f * a), true);
                slider(r, x + 10, y + h - 11, w - 20, a, acc);
            }
            default -> {
                String bl = r.btnSup != null ? r.btnSup.get() : Tr.tr(r.btn);
                float cwid = Math.max(60, Gfx.textW(bl, Ui.BODY, false) + 20), sx = right - cwid;
                boolean cap = capturing != null && r.btnSup != null && bl.equals(Tr.tr("Press a key..."));
                r.ctl[0] = sx; r.ctl[1] = cy - 9; r.ctl[2] = cwid; r.ctl[3] = 18;
                Gfx.rr(sx, cy - 9, cwid, 18, 9, cap ? Gfx.a(acc, 0.9f * a) : Gfx.rgba(0xFFFFFF, 0.14f * a));
                Gfx.ring(sx, cy - 9, cwid, 18, 9, 1f, Gfx.rgba(0xFFFFFF, 0.2f * a));
                Gfx.textC(bl, sx + cwid / 2f, cy, Ui.BODY, Gfx.rgba(0xFFFFFF, a), false);
            }
        }
    }

    // ---------------------------------------------------------------- выпадающий список
    private void openDropdown(Row r) {
        ddRow = r;
        ddW = Math.max(r.ctl[2], 120);
        ddX = Math.min(r.ctl[0] + r.ctl[2] - ddW, width - ddW - 6);
        ddH = Math.min(r.names.length * 20 + 10, 200);
        ddY = r.ctl[1] + r.ctl[3] + 4;
        if (ddY + ddH > height - 6) ddY = r.ctl[1] - ddH - 4;
    }

    private void dropdown(int mx, int my, float e, int acc) {
        Row r = ddRow;
        float a = Gfx.ease(ddAnim) * e;
        float y = ddY + (1f - a) * -8;
        Gfx.glow(ddX, y + 4, ddW, ddH, 12, 16, Gfx.rgba(0x000000, 0.5f * a));
        Gfx.rr4(ddX, y, ddW, ddH, 12, Gfx.rgba(0x30285A, 0.98f * a), Gfx.rgba(0x201A42, 0.98f * a), Gfx.rgba(0x181334, 0.98f * a), Gfx.rgba(0x110E26, 0.98f * a));
        Gfx.ring(ddX, y, ddW, ddH, 12, 1f, Gfx.rgba(0xFFFFFF, 0.22f * a));
        int curI = r.iget.getAsInt();
        Gfx.scissor(ddX, y + 2, ddW, ddH - 4);
        for (int i = 0; i < r.names.length; i++) {
            float iy = y + 5 + i * 20;
            boolean hv = in(mx, my, ddX + 4, iy, ddW - 8, 19);
            if (i == curI) Gfx.rrH(ddX + 4, iy, ddW - 8, 19, 9, Gfx.a(acc, 0.45f * a), Gfx.a(acc, 0.12f * a));
            else if (hv) Gfx.rr(ddX + 4, iy, ddW - 8, 19, 9, Gfx.rgba(0xFFFFFF, 0.12f * a));
            Gfx.textMid(Tr.tr(r.names[i]), ddX + 14, iy + 9.5f, Ui.BODY, Gfx.rgba(0xFFFFFF, (i == curI ? 1f : 0.8f) * a), i == curI);
            if (i == curI) Gfx.icon(Gfx.CHECK, ddX + ddW - 15, iy + 9.5f, 9, Gfx.rgba(0xFFFFFF, a));
        }
        Gfx.unscissor();
    }

    // ---------------------------------------------------------------- ввод
    private void applySlider(Row r, double mx) {
        double f = Math.max(0, Math.min(1, (mx - r.ctl[0]) / Math.max(1f, r.ctl[2])));
        double v = r.min + f * (r.max - r.min);
        r.dset.accept(r.isInt ? Math.round(v) : Math.round(v * 100.0) / 100.0);
    }

    private boolean clickRow(Row r, double mx, double my, int btn, boolean popupRow) {
        if (r.type == 0 && !popupRow && r.sub != null && in(mx, my, r.plus[0], r.plus[1], r.plus[2], r.plus[3])) { openSettings(r); return true; }
        if (r.type != 0 && !popupRow && r.sub != null && in(mx, my, r.plus[0], r.plus[1], r.plus[2], r.plus[3])) { openSettings(r); return true; }
        if (btn == 1 && !popupRow && r.sub != null) { openSettings(r); return true; }
        switch (r.type) {
            case 0 -> { if (btn == 0) r.bset.accept(!r.bget.getAsBoolean()); }
            case 1 -> {
                if (btn == 0 && in(mx, my, r.ctl[0], r.ctl[1], r.ctl[2], r.ctl[3])) openDropdown(r);
                else if (btn == 1) r.iset.accept(Math.floorMod(r.iget.getAsInt() - 1, r.names.length));
                else if (btn == 0) r.iset.accept(Math.floorMod(r.iget.getAsInt() + 1, r.names.length));
            }
            case 2 -> {
                if (btn != 0) return true;
                dragging = r;
                applySlider(r, mx);
            }
            default -> { if (btn == 0) r.action.run(); }
        }
        Config.save();
        return true;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        padMode = false;
        if (capturing != null) {
            if (btn >= 2) bindCaptured(com.mojang.blaze3d.platform.InputConstants.Type.MOUSE.getOrCreate(btn));
            else capturing = null;
            return true;
        }
        if (ddRow != null) {
            Row r = ddRow;
            if (in(mx, my, ddX, ddY, ddW, ddH)) {
                int i = (int) ((my - ddY - 5) / 20);
                if (i >= 0 && i < r.names.length) { r.iset.accept(i); Config.save(); }
            }
            ddRow = null;
            return true;
        }
        search.focus = in(mx, my, cx + cw - Math.min(170, cw * 0.42f), py + 17, Math.min(170, cw * 0.42f), 22);
        if (openSub != null) {
            if (in(mx, my, popX + popW - 30, popY + 9, 20, 20) || !in(mx, my, popX, popY, popW, popH)) { closeSettings(); return true; }
            for (Row r : openSub) if (r.drawn && in(mx, my, r.box[0], r.box[1], r.box[2], r.box[3]) && my > popY + 38) return clickRow(r, mx, my, btn, true);
            return true;
        }
        for (int i = 0; i < TABS.length; i++) {
            if (in(mx, my, px + 15, py + 58 + i * 30, SIDE - 12, 27)) { search.set(""); setTab(i); return true; }
        }
        if (in(mx, my, px + 15, py + H - 40, SIDE - 12, 24)) {
            Config.master = !Config.master;
            Config.save();
            return true;
        }
        if (media()) {
            if (MediaUi.mouseDown(mx, my, btn)) return true;
            return super.mouseClicked(mx, my, btn);
        }
        if (my >= rtop && my < rbot) {
            for (Row r : vis) if (in(mx, my, r.box[0], r.box[1], r.box[2], r.box[3])) return clickRow(r, mx, my, btn, false);
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public void mouseMoved(double mx, double my) {
        if (padMode && (Math.abs(mx - mouseX) > 2 || Math.abs(my - mouseY) > 2)) padMode = false;
        super.mouseMoved(mx, my);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) { applySlider(dragging, mx); return true; }
        if (media()) MediaUi.mouseDrag(mx);
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (dragging != null) { dragging = null; Config.save(); }
        MediaUi.mouseUp();
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (openSub != null) { popScrollT -= (float) (sy * 28); return true; }
        if (media() && MediaUi.scroll(mx, my, sy)) return true;
        scrollT -= (float) (sy * 34);
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (capturing != null) return true;
        if (openSub == null && ddRow == null && !media() && !search.focus && c > 32) search.focus = true;
        if (search.focus) {
            boolean r = search.charTyped(c);
            if (r) resetPage();
            return r;
        }
        return super.charTyped(c, mods);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (capturing != null) {
            if (key == 256) capturing = null;
            else if (key == 259 || key == 261) bindCaptured(com.mojang.blaze3d.platform.InputConstants.UNKNOWN);
            else bindCaptured(com.mojang.blaze3d.platform.InputConstants.getKey(key, scan));
            return true;
        }
        if (key == 256) {
            if (ddRow != null) { ddRow = null; return true; }
            if (openSub != null) { closeSettings(); return true; }
            if (search.focus || !search.text.isEmpty()) { search.set(""); search.focus = false; resetPage(); return true; }
        }
        if (search.focus && search.key(key, mods)) { resetPage(); return true; }
        if (tab == MEDIA && openSub == null && ddRow == null && !search.focus) {
            if (key == 32) { MediaPlayer.toggle(); return true; }
            if (key == 262) { MediaPlayer.next(); return true; }
            if (key == 263) { MediaPlayer.prev(); return true; }
        }
        return super.keyPressed(key, scan, mods);
    }

    // ---------------------------------------------------------------- геймпад
    private void padFix() {
        List<Row> rows = cur();
        if (rows.isEmpty()) return;
        sel = Math.max(0, Math.min(rows.size() - 1, sel));
        if (openSub == null) {
            int cols = cw >= 340 ? 2 : 1;
            float rowY = (sel / cols) * 65f, view = rbot - rtop;
            if (rowY < scrollT) scrollT = rowY;
            else if (rowY + 56 > scrollT + view) scrollT = rowY + 56 - view;
        } else {
            float top = 0;
            for (int i = 0; i < sel; i++) top += rows.get(i).type == 2 ? 38 : 30;
            float view = popH - 48;
            if (top < popScrollT) popScrollT = top;
            else if (top + 38 > popScrollT + view) popScrollT = top + 38 - view;
        }
    }

    public void padMove(int d) {
        padMode = true;
        sel += (openSub == null && cw >= 340) ? d : d;
        padFix();
    }

    public void padAdjust(int d) {
        padMode = true;
        List<Row> rows = cur();
        if (sel < 0 || sel >= rows.size()) return;
        Row r = rows.get(sel);
        switch (r.type) {
            case 0 -> r.bset.accept(d > 0);
            case 1 -> r.iset.accept(Math.floorMod(r.iget.getAsInt() + d, r.names.length));
            case 2 -> {
                double step = r.isInt ? 1.0 : (r.max - r.min) / 20.0;
                double v = Math.max(r.min, Math.min(r.max, r.dget.getAsDouble() + d * step));
                r.dset.accept(r.isInt ? Math.round(v) : Math.round(v * 100.0) / 100.0);
            }
            default -> { return; }
        }
        Config.save();
    }

    public void padActivate() {
        padMode = true;
        if (tab == MEDIA && openSub == null) { MediaPlayer.toggle(); return; }
        List<Row> rows = cur();
        if (sel < 0 || sel >= rows.size()) return;
        Row r = rows.get(sel);
        switch (r.type) {
            case 0 -> r.bset.accept(!r.bget.getAsBoolean());
            case 1 -> r.iset.accept(Math.floorMod(r.iget.getAsInt() + 1, r.names.length));
            case 3 -> r.action.run();
            default -> { return; }
        }
        Config.save();
    }

    public void padSub() {
        padMode = true;
        List<Row> rows = cur();
        if (sel >= 0 && sel < rows.size() && rows.get(sel).sub != null) openSettings(rows.get(sel));
    }

    public void padBack() {
        padMode = true;
        if (ddRow != null) ddRow = null;
        else if (openSub != null) closeSettings();
        else onClose();
    }

    public void padTab(int d) {
        padMode = true;
        search.set("");
        setTab(Math.floorMod(tab + d, TABS.length));
    }

    public void padScroll(float amount) {
        if (openSub != null) popScrollT += amount;
        else scrollT += amount;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
