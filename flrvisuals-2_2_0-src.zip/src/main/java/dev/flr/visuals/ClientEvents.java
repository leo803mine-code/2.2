package dev.flr.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.GenericMessageScreen;
import net.minecraft.client.gui.screens.LevelLoadingScreen;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import org.joml.Matrix4f;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

public final class ClientEvents {
    private static int frames;
    private static long windowStart = System.nanoTime();

    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(FlrKeys.MENU);
        e.register(FlrKeys.MASTER);
        e.register(FlrKeys.SOUND);
        e.register(FlrKeys.AUTOSWAP);
        e.register(FlrKeys.ZOOM);
    }

    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        for (PlayerSkin.Model skin : e.getSkins()) {
            var r = e.getSkin(skin);
            if (r instanceof PlayerRenderer pr) pr.addLayer(new CosmeticsLayer(pr));
        }
    }

    public static void gui(RenderGuiEvent.Post e) {
        frames++;
        long now = System.nanoTime();
        if (now - windowStart >= 500_000_000L) {
            Config.fps = (int) (frames * 1_000_000_000.0 / (now - windowStart));
            frames = 0;
            windowStart = now;
        }
        Minecraft mc = Minecraft.getInstance();
        GuiGraphics g0 = e.getGuiGraphics();
        float pt = e.getPartialTick().getGameTimeDeltaPartialTick(false);
        boolean chat = HudLayout.editing();
        if (Config.master && !mc.options.hideGui && (mc.screen == null || chat)) {
            if (mc.screen == null) {
                if (Config.weather > 0) Overlay.HUD.draw(g0, g0.guiWidth(), g0.guiHeight(), Config.weather, (float) Config.weatherAmount, 0.9f);
                if (Config.crosshair > 0) Crosshair.render(g0);
                TargetEsp.render(g0, pt);
            }
            if (Config.coords) { Hud.open(g0, "coords"); coords(g0, mc); Hud.close(g0, 4, 27, 150, 18); }
            Hud.render(g0, pt);
            if (Config.hud) {
                Hud.open(g0, "fps");
                String text = Config.fps + " FPS";
                int w = Ui.w(text) + 34, c = Config.color();
                Hud.mark(4, 4, w, 18);
                Gfx.use(g0);
                Gfx.glow(4, 5, w, 18, 9, 8, Gfx.rgba(0x000000, 0.25f));
                Gfx.rr4(4, 4, w, 18, 9, Gfx.rgba(0x1A1630, 0.94f), Gfx.rgba(0x120F22, 0.94f), Gfx.rgba(0x100D1E, 0.94f), Gfx.rgba(0x0B0916, 0.94f));
                Gfx.ring(4, 4, w, 18, 9, 1f, Gfx.rgba(c, 0.4f));
                Ui.logo(g0, 8f, 6f, 14f, 1f);
                Gfx.use(g0);
                Gfx.textMid(text, 26, 13, Ui.BODY, 0xFF000000 | c, true);
                Hud.close(g0, 4, 4, w, 18);
            }
            if (chat) {
                Gfx.use(g0);
                String hint = Tr.tr("HUD editor: drag widgets with the mouse, right-click to reset");
                float hw = Gfx.textW(hint, Ui.BODY, false) + 24;
                float hx = (g0.guiWidth() - hw) / 2f;
                Gfx.rr(hx, 6, hw, 18, 9, Gfx.rgba(0x0E0B1C, 0.85f));
                Gfx.ring(hx, 6, hw, 18, 9, 1f, Gfx.rgba(Config.color(), 0.5f));
                Gfx.textC(hint, g0.guiWidth() / 2f, 15, Ui.BODY, 0xFFFFFFFF, false);
            }
        }
        Notify.render(g0);
        Gfx.end();
    }

    public static void hudPress(ScreenEvent.MouseButtonPressed.Pre e) {
        if (!Config.master || !HudLayout.editing()) return;
        if (HudLayout.press(e.getMouseX(), e.getMouseY(), e.getButton())) e.setCanceled(true);
    }

    public static void hudDrag(ScreenEvent.MouseDragged.Pre e) {
        if (HudLayout.dragging == null) return;
        Screen sc = e.getScreen();
        if (HudLayout.drag(e.getMouseX(), e.getMouseY(), sc.width, sc.height)) e.setCanceled(true);
    }

    public static void hudRelease(ScreenEvent.MouseButtonReleased.Pre e) {
        if (HudLayout.release()) e.setCanceled(true);
    }

    public static void fogColor(ViewportEvent.ComputeFogColor e) {
        if (!Config.master || Config.fogTint <= 0 || e.getCamera().getFluidInCamera() != FogType.NONE) return;
        int c = Config.color();
        float t = (float) Config.fogTint * 0.6f;
        e.setRed(Mth.lerp(t, e.getRed(), (c >> 16 & 255) / 255f));
        e.setGreen(Mth.lerp(t, e.getGreen(), (c >> 8 & 255) / 255f));
        e.setBlue(Mth.lerp(t, e.getBlue(), (c & 255) / 255f));
    }

    public static void fogRender(ViewportEvent.RenderFog e) {
        if (!Config.master || Config.fogDensity <= 0 || e.getType() != FogType.NONE) return;
        float far = Mth.lerp((float) Config.fogDensity, 220f, 28f);
        e.setNearPlaneDistance(far * 0.1f);
        e.setFarPlaneDistance(far);
        e.setCanceled(true);
    }

    /** Своё главное меню вместо ванильного. */
    public static void screenOpening(ScreenEvent.Opening e) {
        if (Config.menuStyle && e.getNewScreen() != null && e.getNewScreen().getClass() == TitleScreen.class) {
            e.setNewScreen(new FlrTitleScreen());
        } else if (Config.menuStyle && e.getNewScreen() != null && e.getNewScreen().getClass() == JoinMultiplayerScreen.class) {
            e.setNewScreen(new ServerScreen(e.getCurrentScreen()));
        }
    }

    /** Экраны загрузки: чёрный фон с логотипом вместо ванильных надписей. */
    public static void screenPre(ScreenEvent.Render.Pre e) {
        if (!Config.menuStyle) return;
        Screen sc = e.getScreen();
        String load = null;
        if (sc instanceof ConnectScreen) load = "Connecting to server";
        else if (sc instanceof ReceivingLevelScreen || sc instanceof LevelLoadingScreen) load = "Loading terrain";
        else if (sc instanceof ProgressScreen) load = "Loading";
        else if (sc instanceof GenericMessageScreen) {
            load = sc.getTitle().getString();
            for (GuiEventListener c : sc.children()) {
                if (c instanceof AbstractWidget w && !(c instanceof AbstractButton) && !w.getMessage().getString().isBlank()) {
                    load = w.getMessage().getString();
                    break;
                }
            }
        }
        if (load == null) return;
        e.setCanceled(true);
        var g = e.getGuiGraphics();
        Backdrop.draw(g, sc.width, sc.height);
        Backdrop.loading(g, sc.width, sc.height, load);
        Gfx.end();
        for (GuiEventListener c : sc.children()) {
            if (c instanceof AbstractButton r) r.render(g, e.getMouseX(), e.getMouseY(), e.getPartialTick());
        }
    }

    /** Кнопка FLR в меню паузы. */
    public static void pausePost(ScreenEvent.Render.Post e) {
        if (!Config.menuStyle || !(e.getScreen() instanceof PauseScreen)) return;
        int y = e.getScreen().height - 30;
        boolean hv = Ui.in(e.getMouseX(), e.getMouseY(), 10, y, 70, 20);
        var g = e.getGuiGraphics();
        Ui.pill(g, 10, y, 70, 20, "", hv, false, Config.color() & 0xFFFFFF);
        Ui.logo(g, 15, y + 3, 14, 1f);
        Ui.text(g, "FLR", 35, y + 6, 0xFFFFFFFF);
        Gfx.end();
    }

    public static void pauseClick(ScreenEvent.MouseButtonPressed.Pre e) {
        if (!Config.menuStyle || !(e.getScreen() instanceof PauseScreen) || e.getButton() != 0) return;
        if (Ui.in(e.getMouseX(), e.getMouseY(), 10, e.getScreen().height - 30, 70, 20)) {
            Minecraft.getInstance().setScreen(new CosmeticsScreen());
            e.setCanceled(true);
        }
    }

    /** Отключает ванильный прицел, когда выбран свой. */
    public static void layer(RenderGuiLayerEvent.Pre e) {
        if (Config.master && Config.crosshair > 0 && VanillaGuiLayers.CROSSHAIR.equals(e.getName())) e.setCanceled(true);
    }

    /** Цветное небо: полупрозрачный градиентный купол вокруг камеры сразу после ванильного неба. */
    public static void sky(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY || !Config.master || !Config.sky) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        int base = switch (Config.skyMode) {
            case 0 -> Config.color();
            case 1 -> Config.hsb(Config.skyHue, 0.7, 1.0);
            case 3 -> Config.BLACK;
            case 4 -> Config.WHITE;
            default -> Config.hsb((System.currentTimeMillis() % 30000L) / 30000.0, 0.65, 1.0);
        };
        long dt = mc.level.getDayTime() % 24000L;
        float k = (dt > 12600 && dt < 23400) ? 0.3f : 1f;
        float al = (float) Config.skyAlpha * k;
        int top = col(base, 0.9f, al), hor = col(mix(base, 0xFFFFFF, 0.35f), 1f, al * 0.75f), bot = col(base, 0.8f, al * 0.35f);
        Matrix4f m = e.getModelViewMatrix();
        BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        float r = 100f;
        float[][] c = {{-r, -r}, {r, -r}, {r, r}, {-r, r}};
        for (int i = 0; i < 4; i++) {
            float ax = c[i][0], az = c[i][1], bx = c[(i + 1) % 4][0], bz = c[(i + 1) % 4][1];
            bb.addVertex(m, ax, -r, az).setColor(bot); bb.addVertex(m, bx, -r, bz).setColor(bot);
            bb.addVertex(m, bx, 0, bz).setColor(hor); bb.addVertex(m, ax, 0, az).setColor(hor);
            bb.addVertex(m, ax, 0, az).setColor(hor); bb.addVertex(m, bx, 0, bz).setColor(hor);
            bb.addVertex(m, bx, r, bz).setColor(top); bb.addVertex(m, ax, r, az).setColor(top);
        }
        for (float[] p : c) bb.addVertex(m, p[0], r, p[1]).setColor(top);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        BufferUploader.drawWithShader(bb.buildOrThrow());
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16 & 255) * (1 - t)) + ((b >> 16 & 255) * t));
        int g = (int) (((a >> 8 & 255) * (1 - t)) + ((b >> 8 & 255) * t));
        int bl = (int) (((a & 255) * (1 - t)) + ((b & 255) * t));
        return r << 16 | g << 8 | bl;
    }

    private static int col(int rgb, float bri, float alpha) {
        int r = Math.min(255, (int) ((rgb >> 16 & 255) * bri)), g = Math.min(255, (int) ((rgb >> 8 & 255) * bri)), b = Math.min(255, (int) ((rgb & 255) * bri));
        return Math.max(0, Math.min(255, (int) (alpha * 255))) << 24 | r << 16 | g << 8 | b;
    }

    private static float zoom = 1f;

    /** Плавный зум по зажатой клавише. */
    public static void fov(ViewportEvent.ComputeFov e) {
        Minecraft mc = Minecraft.getInstance();
        float target = Config.master && mc.screen == null && FlrKeys.ZOOM.isDown() ? 0.22f : 1f;
        zoom += (target - zoom) * 0.2f;
        if (Math.abs(zoom - 1f) > 0.002f) e.setFOV(e.getFOV() * zoom);
    }

    private static void coords(GuiGraphics g, Minecraft mc) {
        if (mc.player == null) return;
        String dir = switch (mc.player.getDirection()) {
            case NORTH -> "N";
            case SOUTH -> "S";
            case WEST -> "W";
            default -> "E";
        };
        String s = "XYZ " + (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " "
                + (int) Math.floor(mc.player.getZ()) + "  " + dir;
        int w = Ui.w(s) + 22, acc = Config.color();
        Hud.mark(4, 27, w, 18);
        Gfx.use(g);
        Gfx.glow(4, 28, w, 18, 9, 8, Gfx.rgba(0x000000, 0.25f));
        Gfx.rr4(4, 27, w, 18, 9, Gfx.rgba(0x1A1630, 0.94f), Gfx.rgba(0x120F22, 0.94f), Gfx.rgba(0x100D1E, 0.94f), Gfx.rgba(0x0B0916, 0.94f));
        Gfx.ring(4, 27, w, 18, 9, 1f, Gfx.rgba(acc, 0.4f));
        Gfx.textMid(s, 15, 36, Ui.BODY, 0xFFFFFFFF, false);
    }
}
